create function task_filter_by_date(task_date timestamp without time zone, date_val timestamp with time zone) returns boolean
    language plpgsql
as
$$
BEGIN
    RETURN CAST(date_val as date) = CAST(task_date as date);
END; $$;

alter function task_filter_by_date(timestamp, timestamp with time zone) owner to sa;

