create function new_company(title character varying) returns uuid
    language plpgsql
as
$$
declare

    _u uuid = uuid_generate_v4();

begin
    if EXISTS(select 1 from dsp_company where full_name = title)then
        RAISE NOTICE 'Контрагент % уже существует', title;
        return null;
    else
        insert into dsp_company
        (id, full_name, short_name, is_carrier, is_archived)
        values
            (
                _u,
                title,
                title,
                false,
                false
            );
        return _u;
    end if;
end;
$$;

alter function new_company(varchar) owner to sa;

