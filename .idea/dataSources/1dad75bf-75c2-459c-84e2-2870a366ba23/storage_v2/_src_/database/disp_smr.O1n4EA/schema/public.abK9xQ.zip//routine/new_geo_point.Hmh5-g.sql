create function new_geo_point(latitude_ double precision, longitude_ double precision) returns uuid
    language plpgsql
as
$$
declare

    _u uuid = uuid_generate_v4();

begin

    insert into dsp_geo_point ( id, create_ts,created_by,latitude, longitude )
    values ( _u,CURRENT_TIMESTAMP, 'dan.dor', latitude_, longitude_ );

    return _u;

end;
$$;

alter function new_geo_point(double precision, double precision) owner to sa;

