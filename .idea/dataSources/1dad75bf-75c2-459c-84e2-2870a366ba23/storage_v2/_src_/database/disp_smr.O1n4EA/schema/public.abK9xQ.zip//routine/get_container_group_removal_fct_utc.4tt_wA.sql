create function get_container_group_removal_fct_utc(app_tz character varying, removal_date_app_tz_from timestamp without time zone DEFAULT NULL::timestamp without time zone, removal_date_app_tz_to timestamp without time zone DEFAULT NULL::timestamp without time zone)
    returns TABLE(container_group_id uuid, removal_date_app_tz_trunc timestamp without time zone, carrier_id uuid, removal_only_kgo boolean, fact_volume double precision, fact_amount integer, fact_volume_old_fashioned double precision, picked_up double precision, fail_reasons text)
    language sql
as
$$
with removal as (
    select
        coalesce(l.container_group_id, td.container_area_id) as container_group_id,
        date_trunc('day', (coalesce(dr.removal_date, dr.create_ts) at time zone app_tz at time zone 'UTC')) as removal_date_app_tz_trunc,
        t.carrier_id,
        td.removal_only_kgo,
        case
            when f.amount is not null or pickup.amount is not null
                then coalesce(f.amount, 0) + coalesce(pickup.amount, 0)
            end as fact_amount,
        coalesce(ft.volume, 0.0) * coalesce(f.amount, 0) + --fact
        coalesce(pt.volume, 0.0) * coalesce(pickup.amount, 0) --pickup
            as fact_volume,
        coalesce(ct_old_fashioned.volume, 0.0) * coalesce(f.amount, 0) + --fact
        coalesce(pt.volume, 0.0) * coalesce(pickup.amount, 0) --pickup
            as fact_volume_old_fashioned,
        case
            when row_number() over (partition by dr.id order by f.container_group_id) = 1
                then dr.containers_amount_picked_up else 0.0
            end as picked_up,
        fr.name as fail_reason --FIXME\: Due to data design the "fail_reason" will be duplicated for each container group within driver report
    from dsp_report_from_driver as dr
             join dsp_task_detail as td on td.report_id = dr.id
             left join dsp_task as t on t.id = td.task_id
             left join dsp_task_detail_container_group_link as l on l.task_detail_id = td.id
             left join dsp_report_detailing_fact as f on f.report_id = dr.id and f.container_group_id = l.container_group_id
             left join dsp_container_type as ft on ft.id = f.container_type_id
             left join dsp_removal_fail_reason fr on fr.id = dr.garbage_removal_fail_reason_id
             left join dsp_picked_up_recorded_in_container as pickup on pickup.id = dr.picked_up_recorded_in_container_id and pickup.container_group_id = l.container_group_id
             left join dsp_container_type as pt on pt.id = pickup.container_type_id
             left join dsp_container_group cg_old_fashioned on l.container_group_id = cg_old_fashioned.id
             left join dsp_container_type as ct_old_fashioned on cg_old_fashioned.container_type_id = ct_old_fashioned.id
    where date_trunc('day', (coalesce(dr.removal_date, dr.create_ts) at time zone app_tz at time zone 'UTC'))
              between date_trunc('day', removal_date_app_tz_from) and date_trunc('day', removal_date_app_tz_to)
)
select rm.container_group_id,
       rm.removal_date_app_tz_trunc,
       rm.carrier_id,
       rm.removal_only_kgo,
       sum(rm.fact_volume) as fact_volume,
       cast(sum(rm.fact_amount) as integer) as fact_amount,
       sum(rm.fact_volume_old_fashioned) as fact_volume_old_fashioned,
       sum(rm.picked_up) as picked_up,
       string_agg(distinct rm.fail_reason, chr(10) order by rm.fail_reason) as fail_reasons
from removal as rm
group by rm.container_group_id,
         rm.removal_date_app_tz_trunc,
         rm.carrier_id,
         rm.removal_only_kgo;
$$;

alter function get_container_group_removal_fct_utc(varchar, timestamp, timestamp) owner to sa;

