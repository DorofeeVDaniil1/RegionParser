create function update_lk_codes(lk_old character varying, lk_new character varying, address character varying) returns void
    language plpgsql
as
$$
BEGIN
    -- Проверяем, совпадают ли переданные параметры с текущими значениями в таблице
    IF (lk_new!=lk_old) THEN
        UPDATE dsp_container_area
        SET lk_code = lk_new
        WHERE lk_code = lk_old and address_id =(select id from dsp_address where view_ = address);
    else
        raise notice 'Параметры одинаковы';
    END IF;

END;
$$;

alter function update_lk_codes(varchar, varchar, varchar) owner to sa;

