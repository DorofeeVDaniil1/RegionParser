create function new_region(_name character varying, _geo_data_id uuid, on_level integer, parent_name character varying DEFAULT NULL::character varying, color character varying DEFAULT NULL::character varying) returns uuid
    language plpgsql
as
$$
declare
    _exsist_id uuid;
    _u uuid = uuid_generate_v4();
    _colors text[] := ARRAY[
        '#5f6368',
        '#1a73e8',
        '#d93025',
        '#f9ab00',
        '#188038',
        '#d01884',
        '#a142f4',
        '#007b83',
        '#fa903e'
        ];
    _random_color text;


begin
    if color is null then
        _random_color = color;
    else
        _random_color := _colors[1 + floor(random() * array_length(_colors, 1))::int];
    end if;

    select id
    into _exsist_id
    from dsp_region
    where name =_name and level_ = on_level;

    if _exsist_id is null then
        insert into
            dsp_region
        (
            id,
            create_ts,
            level_,
            name,
            created_by,
            fill_color,
            parent_id
        )
        values
            (
                _u,
                now()::timestamp,
                on_level,
                _name,
                'sysadmin',
                _random_color,
                (select id from dsp_region where name=parent_name )
            );

        insert into dsp_region_geo_data_link (geo_data_id, region_id)
        values (_geo_data_id, _u);

        return _u;

    else
        RAISE NOTICE 'Такой регион уже существует, добавляю к нему координаты';
        insert into dsp_region_geo_data_link (geo_data_id, region_id)
        values (_geo_data_id, _exsist_id);

        return _exsist_id;

    end if;



end;
$$;

alter function new_region(varchar, uuid, integer, varchar, varchar) owner to sa;

