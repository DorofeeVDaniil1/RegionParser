create view dsp_container_group_dim_vw
            (id, entity_name, container_area_code, region_id, region_name, parent_region_name, address,
             owner_company_name, amount, volume, schedule, trips_per_day, tariff)
as
SELECT cg.id,
       'dsp_ContainerGroup'::text                                           AS entity_name,
       ca.lk_code                                                           AS container_area_code,
       r.id                                                                 AS region_id,
       string_agg(DISTINCT r.name::text, chr(10) ORDER BY (r.name::text))   AS region_name,
       string_agg(DISTINCT pr.name::text, chr(10) ORDER BY (pr.name::text)) AS parent_region_name,
       a.view_                                                              AS address,
       oc.full_name                                                         AS owner_company_name,
       cg.amount,
       ct.volume,
       sh.name                                                              AS schedule,
       cg.trips_per_day,
       t.name                                                               AS tariff
FROM dsp_container_group cg
         LEFT JOIN dsp_container_area ca ON ca.id = cg.container_area_id
         LEFT JOIN dsp_region_container_area_link rl ON rl.container_area_id = ca.id
         LEFT JOIN dsp_region r ON r.id = rl.region_id
         LEFT JOIN dsp_region pr ON pr.id = r.parent_id
         LEFT JOIN dsp_address a ON a.id = ca.address_id
         LEFT JOIN dsp_container_area_tariff_calculation_method t ON ca.tariff_calculation_method_id = t.id
         LEFT JOIN dsp_company oc ON oc.id = ca.owner_company_id
         LEFT JOIN dsp_container_type ct ON ct.id = cg.container_type_id
         LEFT JOIN dsp_removal_schedule sh ON sh.id = cg.schedule_id
GROUP BY cg.id, ca.id, r.id, a.id, oc.id, ct.id, sh.id, t.id
UNION ALL
SELECT ca.id,
       'dsp_ContainerArea'::text                                            AS entity_name,
       ca.lk_code                                                           AS container_area_code,
       r.id                                                                 AS region_id,
       string_agg(DISTINCT r.name::text, chr(10) ORDER BY (r.name::text))   AS region_name,
       string_agg(DISTINCT pr.name::text, chr(10) ORDER BY (pr.name::text)) AS parent_region_name,
       a.view_                                                              AS address,
       oc.full_name                                                         AS owner_company_name,
       NULL::integer                                                        AS amount,
       NULL::double precision                                               AS volume,
       NULL::character varying                                              AS schedule,
       NULL::integer                                                        AS trips_per_day,
       t.name                                                               AS tariff
FROM dsp_container_area ca
         LEFT JOIN dsp_region_container_area_link rl ON rl.container_area_id = ca.id
         LEFT JOIN dsp_region r ON r.id = rl.region_id
         LEFT JOIN dsp_region pr ON pr.id = r.parent_id
         LEFT JOIN dsp_address a ON a.id = ca.address_id
         LEFT JOIN dsp_container_area_tariff_calculation_method t ON ca.tariff_calculation_method_id = t.id
         LEFT JOIN dsp_company oc ON oc.id = ca.owner_company_id
GROUP BY ca.id, r.id, a.id, oc.id, t.id;

alter table dsp_container_group_dim_vw
    owner to sa;

