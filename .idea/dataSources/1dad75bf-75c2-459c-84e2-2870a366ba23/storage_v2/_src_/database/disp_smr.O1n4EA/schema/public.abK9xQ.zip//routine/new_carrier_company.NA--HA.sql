create function new_carrier_company(_full_name character varying, _short_name character varying) returns uuid
    language plpgsql
as
$$
declare

    _u uuid = uuid_generate_v4();

begin
    if exists(select 1 from dsp_company where full_name = _full_name)then
        RAISE NOTICE 'Перевозчик % уже существет', _full_name;
        return null;
    else
        insert into dsp_company
        ( id, create_ts, created_by, full_name, short_name, is_carrier )
        values
            ( _u, now()::timestamp, 'new_carrier_company()', _full_name, _short_name, true );

        return _u;
    end if;


end;
$$;

alter function new_carrier_company(varchar, varchar) owner to sa;

