create procedure new_vehicle(full_spaces character varying, full_no_spaces character varying, no_reg character varying, no_reg_no_spaces character varying, _assembly_id uuid)
    language sql
as
$$
with _id as (

	insert into dsp_vehicle_number 
		(id, create_ts, created_by, delete_ts, deleted_by, update_ts, updated_by, full_, full_without_spaces, without_region, without_spaces)	
	values 
		( uuid_generate_v4(), now()::timestamp, null, null, null, null, null, full_spaces, full_no_spaces, no_reg, no_reg_no_spaces)
	returning
		id

)  
	insert into dsp_vehicle	
		(id, create_ts, created_by, delete_ts, deleted_by, update_ts, updated_by, enterprise1c_id, assembly_id, gps_device_id, location_id, number_id, owner_id)
	select	
		uuid_generate_v4(), now()::timestamp, null, null, null, null, null, null, _assembly_id, null, null, id, null
	from _id;
$$;

alter procedure new_vehicle(varchar, varchar, varchar, varchar, uuid) owner to sa;

