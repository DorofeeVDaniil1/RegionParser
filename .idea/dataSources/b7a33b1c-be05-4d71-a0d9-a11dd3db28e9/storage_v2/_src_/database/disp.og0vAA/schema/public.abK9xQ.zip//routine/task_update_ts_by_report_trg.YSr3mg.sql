create function task_update_ts_by_report_trg() returns trigger
    language plpgsql
as
$$
begin
    if OLD.task_detail_id is not null and NEW.task_detail_id is not null
        and OLD.id is not distinct from NEW.id
    then
        update dsp_task
        set update_ts  = new.update_ts,
            updated_by = new.updated_by
        where id = (select task_id from dsp_task_detail where id = new.task_detail_id)
           or id = (select task_id from dsp_task_detail where id = old.task_detail_id);
    elsif OLD.task_detail_id is not null then
        update dsp_task
        set update_ts  = old.update_ts,
            updated_by = old.updated_by
        where id = (select task_id from dsp_task_detail where id = old.task_detail_id);
    elsif NEW.task_detail_id is not null then
        update dsp_task
        set update_ts  = new.update_ts,
            updated_by = new.updated_by
        where id = (select task_id from dsp_task_detail where id = new.task_detail_id);
    end if;
    RETURN NEW;
end;
$$;

alter function task_update_ts_by_report_trg() owner to sa;

