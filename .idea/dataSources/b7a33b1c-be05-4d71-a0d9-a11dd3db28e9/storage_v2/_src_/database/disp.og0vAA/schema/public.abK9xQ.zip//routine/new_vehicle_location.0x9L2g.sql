create function new_vehicle_location(title character varying, _geo_data_id uuid, _address_id uuid) returns uuid
    language plpgsql
as
$$
declare

	_u uuid = uuid_generate_v4();
	
begin

	insert into dsp_vehicle_location
	( 
		id, 
		create_ts, created_by, 
		delete_ts, deleted_by, 
		update_ts, updated_by, 
		is_active, 
		name,
		address_id,
		geo_data_id,
		icon_link  
	)
	values
	( 
		_u, 
		now()::timestamp, null,
		null, null, 
		null, null, 
		null, 
		title,
		_address_id,
		_geo_data_id,
		null  	
	);
	return _u;
	
end;
$$;

alter function new_vehicle_location(varchar, uuid, uuid) owner to sa;

