create function dsp_employee_audit_trg() returns trigger
    language plpgsql
as
$$
declare
    entity_name constant varchar = 'dsp_Employee';
    entity_title constant varchar = 'сотрудник';
    entity_gender constant audit.gender = 'M';
begin
    if not audit.is_audit_enabled() then
        return coalesce(NEW, OLD);
    end if;

    if NEW.id is distinct from OLD.id then
        if NEW.id is not null then
            call audit.write_instance_audit(entity_name, NEW.id,
                'CREATE', entity_title, entity_gender,
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.id'),
                old_value => cast(OLD.id as varchar),
                new_value => cast(NEW.id as varchar));
        end if;
        if OLD.id is not null then
            call audit.write_instance_audit(entity_name, OLD.id,
                'DELETE', entity_title, entity_gender,
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.id'),
                old_value => cast(OLD.id as varchar),
                new_value => cast(NEW.id as varchar));
        end if;
    end if;
    if NEW.id is not null then
        if (NEW.delete_ts is not null) is distinct from (OLD.delete_ts is not null) then
            call audit.write_instance_audit(entity_name, NEW.id,
                audit.get_soft_op_type(NEW.delete_ts is not null, OLD.delete_ts is not null),
                entity_title, entity_gender,
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.delete_ts'),
                old_value => cast(OLD.delete_ts as varchar),
                new_value => cast(NEW.delete_ts as varchar));
        end if;
        if NEW.person_id is distinct from OLD.person_id then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.person_id is null, OLD.person_id is null),
                'физлицо', 'N', audit.get_user_str(coalesce(NEW.person_id, OLD.person_id)),
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.person_id'),
                old_value => cast(OLD.person_id as varchar),
                new_value => cast(NEW.person_id as varchar));
        end if;                
        if NEW.email is distinct from OLD.email then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.email is null, OLD.email is null),
                'e-mail', 'M', coalesce(NEW.email, OLD.email),
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.email'),
                old_value => cast(OLD.email as varchar),
                new_value => cast(NEW.email as varchar));
        end if;                
        if NEW.phone_no is distinct from OLD.phone_no then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.phone_no is null, OLD.phone_no is null),
                'телефон', 'M', coalesce(NEW.phone_no, OLD.phone_no),
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.phone_no'),
                old_value => cast(OLD.phone_no as varchar),
                new_value => cast(NEW.phone_no as varchar));
        end if;                
        if NEW.user_id is distinct from OLD.user_id then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.user_id is null, OLD.user_id is null),
                'пользователь', 'M', audit.get_user_str(coalesce(NEW.user_id, OLD.user_id)),
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.user_id'),
                old_value => cast(OLD.user_id as varchar),
                new_value => cast(NEW.user_id as varchar));
        end if;                
        if NEW.work_in_regional_operator is distinct from OLD.work_in_regional_operator then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.work_in_regional_operator is null, OLD.work_in_regional_operator is null),
                'признак регоператора', 'N', audit.get_boolean_str(coalesce(NEW.work_in_regional_operator, OLD.work_in_regional_operator)),
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.work_in_regional_operator'),
                old_value => cast(OLD.work_in_regional_operator as varchar),
                new_value => cast(NEW.work_in_regional_operator as varchar));
        end if;
    end if;

    return coalesce(NEW, OLD);
end;
$$;

alter function dsp_employee_audit_trg() owner to sa;

