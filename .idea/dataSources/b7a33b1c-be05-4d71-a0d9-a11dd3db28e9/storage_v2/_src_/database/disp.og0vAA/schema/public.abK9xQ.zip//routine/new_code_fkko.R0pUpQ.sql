create function new_code_fkko(container_group_id uuid, waste_code_fkko character varying) returns void
    language plpgsql
as
$$
DECLARE
    waste_array text[];
    waste_code character varying;
    waste_id uuid;
BEGIN
    -- Преобразуем строку в массив, разделяя её по запятой
    waste_array := string_to_array(waste_code_fkko, ',');

    -- Проходимся по каждому элементу массива
    FOREACH waste_code IN ARRAY waste_array
        LOOP

            -- Удаляем лишние пробелы и находим id по коду
            SELECT id INTO waste_id
            FROM dsp_waste_material_classifier
            WHERE code = REPLACE(waste_code, ' ', '');

            -- Вставляем запись для каждого элемента массива
            INSERT INTO dsp_container_group_waste_classifier_link
            (group_id, waste_classifier_id)
            VALUES
                (container_group_id, waste_id);
        END LOOP;
END;
$$;

alter function new_code_fkko(uuid, varchar) owner to sa;

