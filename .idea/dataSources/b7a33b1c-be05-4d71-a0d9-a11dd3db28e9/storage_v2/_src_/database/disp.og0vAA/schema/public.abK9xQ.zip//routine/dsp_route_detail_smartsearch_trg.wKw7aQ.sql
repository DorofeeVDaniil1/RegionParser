create function dsp_route_detail_smartsearch_trg() returns trigger
    language plpgsql
as
$$
begin
    if(NEW.route_id is distinct from OLD.route_id or
        NEW.group_id is distinct from OLD.group_id
    ) then
        insert into dsp_smartsearch_queue(context_name, key)
        select distinct
            'dsp_Route(routeDetail.group)',
            concat(
                cast(rd.route_id as varchar), ',',
                cast(rd.group_id as varchar)
            )
        from (values
                (NEW.route_id, NEW.group_id),
                (OLD.route_id, OLD.group_id)
            ) as rd(route_id, group_id)
            join dsp_container_group as cg on rd.group_id = cg.id
            join dsp_container_area as ca on cg.container_area_id = ca.id;
    end if;

    return null;
end;
$$;

alter function dsp_route_detail_smartsearch_trg() owner to sa;

