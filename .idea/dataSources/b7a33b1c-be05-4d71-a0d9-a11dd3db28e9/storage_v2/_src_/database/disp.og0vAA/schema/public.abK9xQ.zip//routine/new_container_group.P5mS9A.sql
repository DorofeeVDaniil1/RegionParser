create function new_container_group(container_area_code character varying, amount_ integer, volume_ double precision, category_ integer) returns uuid
    language plpgsql
as
$$
declare

    _u uuid = uuid_generate_v4();

begin

    insert into dsp_container_group (
        id,
        container_area_id,
        amount,
        container_type_id,
        category
    )

    select
        _u,
        (select id from dsp_container_area where lk_code = container_area_code),
        amount_,
        get_or_create_container_type_tko(volume_),
        category_
    ;

    return _u;

end;
$$;

alter function new_container_group(varchar, integer, double precision, integer) owner to sa;

