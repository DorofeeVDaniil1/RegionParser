create function dsp_carrier_employee_link_audit_trg() returns trigger
    language plpgsql
as
$$
declare
    employee_entity_name constant varchar = 'dsp_Employee';

    carrier_entity_title constant varchar = 'перевозчик';
    carrier_entity_gender constant audit.gender = 'M';
begin
    if not audit.is_audit_enabled() then
        return coalesce(NEW, OLD);
    end if;

    if NEW.employee_id is distinct from OLD.employee_id
        or NEW.carrier_id is distinct from OLD.carrier_id
    then
        --TODO: Get rid of this bloody copy-pastes:
        if OLD.employee_id is not null and OLD.carrier_id is not null then
            call audit.write_instance_audit(employee_entity_name, OLD.employee_id,
                'DELETE', carrier_entity_title, carrier_entity_gender,
                audit.get_company_str(OLD.carrier_id),
                db_op_type => TG_OP,
                db_field_name => cast(array[
                    concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.employee_id'),
                    concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.carrier_id')
                ] as varchar),
                old_value => cast(array[
                    cast(OLD.employee_id as varchar),
                    cast(OLD.carrier_id as varchar)
                ] as varchar),
                new_value => cast(array[
                    cast(NEW.employee_id as varchar),
                    cast(NEW.carrier_id as varchar)
                ] as varchar)
            );
        end if;
        if NEW.employee_id is not null and NEW.carrier_id is not null then
            call audit.write_instance_audit(employee_entity_name, NEW.employee_id,
                'INSERT', carrier_entity_title, carrier_entity_gender,
                audit.get_company_str(NEW.carrier_id),
                db_op_type => TG_OP,
                db_field_name => cast(array[
                    concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.employee_id'),
                    concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.carrier_id')
                ] as varchar),
                old_value => cast(array[
                    cast(OLD.employee_id as varchar),
                    cast(OLD.carrier_id as varchar)
                ] as varchar),
                new_value => cast(array[
                    cast(NEW.employee_id as varchar),
                    cast(NEW.carrier_id as varchar)
                ] as varchar)
            );
        end if;
    end if;

    return coalesce(NEW, OLD);
end;
$$;

alter function dsp_carrier_employee_link_audit_trg() owner to sa;

