create function create_phone_id(phone character varying) returns uuid
    language plpgsql
as
$$
declare
    _u uuid = uuid_generate_v4();
begin
    insert into dsp_contact (id, create_ts, created_by, view_)
    values (
               _u,
               CURRENT_TIMESTAMP,
               'dan.dor',
               phone
           );
    return _u;
end;
$$;

alter function create_phone_id(varchar) owner to sa;

