create function dsp_garbage_unloading_audit_func() returns trigger
    language plpgsql
as
$$
declare
    entity_name constant varchar = 'dsp_GarbageLoadingUnloading';
    entity_title constant varchar = 'весовой отчет о разгрузке';
    entity_gender constant audit.gender = 'M';
begin
    if not audit.is_audit_enabled() then
        return coalesce(NEW, OLD);
    end if;

    if NEW.id is distinct from OLD.id then
        -- When entity just created
        if NEW.id is not null then
            call audit.write_instance_audit(
                    entity_name,
                    NEW.task_id,
                    'CREATE',
                    entity_title,
                    entity_gender,
                    db_op_type => TG_OP,
                    db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.id'),
                    old_value => cast(OLD.id as varchar),
                    new_value => cast(NEW.id as varchar));
        end if;
        -- When entity just deleted
        if OLD.id is not null then
            call audit.write_instance_audit(
                    entity_name,
                    OLD.task_id,
                    'DELETE',
                    audit.get_entity_title_with_create_ts(entity_title, OLD.create_ts),
                    entity_gender,
                    db_op_type => TG_OP,
                    db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.id'),
                    old_value => cast(OLD.id as varchar),
                    new_value => cast(NEW.id as varchar),
                    instance_str => audit.get_garbage_unloading_point_str(NEW.point_id));
        end if;
    end if;

    -- When entity updated
    if NEW.id is not null then
        -- When entity soft deleted
        if (NEW.delete_ts is not null) is distinct from (OLD.delete_ts is not null) then
            call audit.write_instance_audit(
                    entity_name,
                    NEW.task_id,
                    audit.get_soft_op_type(NEW.delete_ts is not null, OLD.delete_ts is not null),
                    audit.get_entity_title_with_create_ts(entity_title, OLD.create_ts),
                    entity_gender,
                    db_op_type => TG_OP,
                    db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.delete_ts'),
                    old_value => cast(OLD.delete_ts as varchar),
                    new_value => cast(NEW.delete_ts as varchar),
                    instance_str => audit.get_garbage_unloading_point_str(NEW.point_id));
        end if;
        -- When point_id attribute changed
        if NEW.point_id is distinct from OLD.point_id then
            call audit.write_attribute_audit(
                    entity_name,
                    NEW.task_id,
                    audit.get_op_type(NEW.point_id is null, OLD.point_id is null),
                    'место разгрузки',
                    'N',
                    audit.get_garbage_unloading_point_str(coalesce(NEW.point_id, OLD.point_id)),
                    text_added_to_event_descr => audit.get_garbage_unloading_update_audit_description_ending(NEW.create_ts, null),
                    db_op_type => TG_OP,
                    db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.point_id'),
                    old_value => cast(OLD.point_id as varchar),
                    new_value => cast(NEW.point_id as varchar));
        end if;

        -- When weight_before or weight_after has been changed
        if ((NEW.weight_before is distinct from OLD.weight_before) OR
           (NEW.weight_after is distinct from OLD.weight_after)) then

            -- When entity just created and weight_before and weight_after equal 0 - do not write attribute audit
            if NOT ((NEW.id is distinct from OLD.id AND NEW.id is not null) AND
                 (NEW.weight_before = 0 AND NEW.weight_after = 0)) then

                -- When weight_before attribute changed
                if NEW.weight_before is distinct from OLD.weight_before then
                    call audit.write_attribute_audit(
                        entity_name,
                        NEW.task_id,
                        audit.get_op_type(NEW.weight_before is null, OLD.weight_before is null),
                        'вес до разгрузки',
                        'M',
                        cast(coalesce(NEW.weight_before, OLD.weight_before) as varchar),
                        text_added_to_event_descr => audit.get_garbage_unloading_update_audit_description_ending(NEW.create_ts, NEW.point_id),
                        db_op_type => TG_OP,
                        db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.weight_before'),
                        old_value => cast(OLD.weight_before as varchar),
                        new_value => cast(NEW.weight_before as varchar));
                end if;
                -- When weight_after attribute changed
                if NEW.weight_after is distinct from OLD.weight_after then
                    call audit.write_attribute_audit(
                        entity_name,
                        NEW.task_id,
                        audit.get_op_type(NEW.weight_after is null, OLD.weight_after is null),
                        'вес после разгрузки',
                        'M',
                        cast(coalesce(NEW.weight_after, OLD.weight_after) as varchar),
                        text_added_to_event_descr => audit.get_garbage_unloading_update_audit_description_ending(NEW.create_ts, NEW.point_id),
                        db_op_type => TG_OP,
                        db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.weight_after'),
                        old_value => cast(OLD.weight_after as varchar),
                        new_value => cast(NEW.weight_after as varchar));
                end if;
                -- When weight_difference attribute changed
                if NEW.weight_difference is distinct from OLD.weight_difference then
                    call audit.write_attribute_audit(
                        entity_name,
                        NEW.task_id,
                        audit.get_op_type(NEW.weight_difference is null, OLD.weight_difference is null),
                        'вес ТКО',
                        'M',
                        cast(coalesce(NEW.weight_difference, OLD.weight_difference) as varchar),
                        text_added_to_event_descr => audit.get_garbage_unloading_update_audit_description_ending(NEW.create_ts, NEW.point_id),
                        db_op_type => TG_OP,
                        db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.weight_difference'),
                        old_value => cast(OLD.weight_difference as varchar),
                        new_value => cast(NEW.weight_difference as varchar));
                end if;
            end if;
        end if;
    end if;

    return coalesce(NEW, OLD);
end;
$$;

alter function dsp_garbage_unloading_audit_func() owner to sa;

