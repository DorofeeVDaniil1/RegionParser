create procedure link_vehicle_to_container_area(code character varying, num character varying)
    language plpgsql
as
$$
begin
 
update dsp_container_group set route_id = 

	(
		select id from dsp_route
		where name like '%' || num || '%'
		limit 1
	) 

	from dsp_container_area
	
	where dsp_container_area.id = dsp_container_group.container_area_id
	
	and lk_code = code;
	
end;
$$;

alter procedure link_vehicle_to_container_area(varchar, varchar) owner to sa;

