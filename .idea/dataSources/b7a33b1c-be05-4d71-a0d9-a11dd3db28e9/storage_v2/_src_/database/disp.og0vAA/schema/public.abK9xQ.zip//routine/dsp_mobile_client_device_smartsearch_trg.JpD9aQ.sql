create function dsp_mobile_client_device_smartsearch_trg() returns trigger
    language plpgsql
as
$$
begin
    if(NEW.id is distinct from OLD.id or
        NEW.delete_ts is distinct from OLD.delete_ts or
        NEW.dev_uuid is distinct from OLD.dev_uuid
    ) then
        insert into dsp_smartsearch_queue(context_name, key)
        select distinct
            'dsp_MobileClientDevice',
            cast(md.id as varchar)
        from (values
                (NEW.id),
                (OLD.id)
            ) as md(id)
        where md.id is not null;
    end if;

    return null;
end;
$$;

alter function dsp_mobile_client_device_smartsearch_trg() owner to sa;

