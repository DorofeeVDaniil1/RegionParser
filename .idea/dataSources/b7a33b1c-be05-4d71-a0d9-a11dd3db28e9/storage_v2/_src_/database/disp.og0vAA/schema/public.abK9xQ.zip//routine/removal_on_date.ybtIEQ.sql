create function removal_on_date(target_group_id uuid, target_date date) returns boolean
    language plpgsql
as
$$
BEGIN
    return exists(

            select *
            from dsp_container_area
                     join dsp_container_group ON dsp_container_group.container_area_id = dsp_container_area.id
                     join dsp_removal_schedule ON dsp_removal_schedule.id = dsp_container_group.schedule_id
                     join dsp_removal_schedule_record ON dsp_removal_schedule_record.schedule_id = dsp_removal_schedule.id
                     join dsp_removal_interval i ON i.id = dsp_removal_schedule_record.interval_id

            where (
                    (i.type_ = 'EVERYDAY')
                    or
                    (i.type_ = 'DAY_OF_WEEK' and extract(dow from target_date::timestamp) = i.value_)
                    or
                    (i.type_ = 'DAY_OF_WEEK' and extract(dow from target_date::timestamp) = 0 and i.value_ = 7)
                    or
                    (i.type_ = 'DAY_OF_MONTH' and extract(day from target_date::timestamp) = i.value_)
                    or
                    (
                                i.type_ = 'EVERY_N_WEEK_DAY_IN_MONTH' and
                                i.value_ = extract(dow from target_date::timestamp) and
                                i.order_in_month = to_char(target_date::timestamp, 'W')::int
                        )
                    or
                    (
                                i.type_ = 'EVERY_N_DAY_IN_M' and
                                target_date::date >= dsp_removal_schedule.start_date::date and
                                (target_date::date - dsp_removal_schedule.start_date::date) % (i.value_ + i.order_in_month) < i.value_
                        )
                )
              and is_archived is not true
              and deleted_from_lk_ts is null
              and dsp_container_group.id = target_group_id

        );

END;
$$;

alter function removal_on_date(uuid, date) owner to sa;

