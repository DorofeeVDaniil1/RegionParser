create function dsp_container_group_smartsearch_trg() returns trigger
    language plpgsql
as
$$
begin
    if(NEW.id is distinct from OLD.id or
        NEW.delete_ts is distinct from OLD.delete_ts or
        NEW.deleted_from_lk_ts is distinct from OLD.deleted_from_lk_ts or
        NEW.container_area_id is distinct from OLD.container_area_id or
        NEW.container_type_id is distinct from OLD.container_type_id or
        NEW.amount is distinct from OLD.amount
    ) then
        insert into dsp_smartsearch_queue(context_name, key)
        select distinct
            'dsp_ContainerGroup',
            cast(cg.id as varchar)
        from (values
                (NEW.id),
                (OLD.id)
            ) as cg(id)
        where cg.id is not null;

        insert into dsp_smartsearch_queue(context_name, key)
        select distinct
            'dsp_ContainerGroup(taskDetail.task.vehicle)',
            concat(
                cast(l.container_group_id as varchar), ',',
                cast(t.vehicle_id as varchar)
            )
        from dsp_task_detail_container_group_link as l
            join dsp_task_detail as td on l.task_detail_id = td.id
            join dsp_task as t on td.task_id = t.id
        where l.container_group_id in (NEW.id, OLD.id);
    end if;

    if(NEW.id is distinct from OLD.id or
        NEW.container_area_id is distinct from OLD.container_area_id or
        NEW.container_type_id is distinct from OLD.container_type_id or
        NEW.amount is distinct from OLD.amount
    ) then
        insert into dsp_smartsearch_queue(context_name, key)
        select distinct
            'dsp_Route(routeDetail.group)',
            concat(
                cast(rd.route_id as varchar), ',',
                cast(rd.group_id as varchar)
            )
        from dsp_route_detail as rd
        where rd.group_id in (NEW.id, OLD.id);
    end if;

    return null;
end;
$$;

alter function dsp_container_group_smartsearch_trg() owner to sa;

