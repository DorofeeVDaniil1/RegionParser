create function get_container_group_removal_fct(app_tz character varying, removal_date_app_tz_from timestamp without time zone DEFAULT NULL::timestamp without time zone)
    returns TABLE(container_group_id uuid, removal_date_app_tz_trunc timestamp without time zone, carrier_id uuid, removal_only_kgo boolean, fact_amount integer, picked_up double precision, fail_reasons text)
    language sql
as
$$
    with removal as (
        select coalesce(l.container_group_id, td.container_area_id) as container_group_id,
            date_trunc('day', (coalesce(dr.removal_date, dr.create_ts) at time zone 'UTC' at time zone app_tz)) as removal_date_app_tz_trunc,
            t.carrier_id,
            td.removal_only_kgo,
            case when f.amount is not null or pickup.amount is not null
                    then coalesce(f.amount, 0) + coalesce(pickup.amount, 0)
                end as fact_amount,
            case when row_number() over (partition by dr.id order by f.container_group_id) = 1
                    then dr.containers_amount_picked_up else 0.0
                end as picked_up,
            fr.name as fail_reason --FIXME: Due to data design the "fail_reason" will be duplicated for each container group within driver report
        from dsp_report_from_driver as dr
            join dsp_task_detail as td on td.report_id = dr.id
            left join dsp_task as t on t.id = td.task_id
            left join dsp_task_detail_container_group_link as l on l.task_detail_id = td.id
            left join dsp_report_detailing_fact as f on f.report_id = dr.id and f.container_group_id = l.container_group_id
            left join dsp_removal_fail_reason fr on fr.id = dr.garbage_removal_fail_reason_id
            left join dsp_picked_up_recorded_in_container as pickup on pickup.id = dr.picked_up_recorded_in_container_id and pickup.container_group_id = l.container_group_id
            /* the wrong approach is commented out below and to be removed later, the right approach see just one line above
            left join (
                select drfd.id as report_id,
                    dpuric.container_group_id as group_id,
                    sum(amount) as amount
                from dsp_report_from_driver drfd
                    join dsp_picked_up_recorded_in_container dpuric on drfd.id = dpuric.report_id
                group by drfd.id,
                    dpuric.container_group_id
            ) pickup on pickup.report_id = dr.id and pickup.group_id = l.container_group_id*/
    )
    select rm.container_group_id,
        rm.removal_date_app_tz_trunc,
        rm.carrier_id,
        rm.removal_only_kgo,
        cast(sum(rm.fact_amount) as integer) as fact_amount,
        sum(rm.picked_up) as picked_up,
        string_agg(distinct rm.fail_reason, chr(10) order by rm.fail_reason) as fail_reasons
    from removal as rm
    where rm.removal_date_app_tz_trunc >= coalesce(date_trunc('day', removal_date_app_tz_from), rm.removal_date_app_tz_trunc)
    group by rm.container_group_id,
        rm.removal_date_app_tz_trunc,
        rm.carrier_id,
        rm.removal_only_kgo;
$$;

alter function get_container_group_removal_fct(varchar, timestamp) owner to sa;

