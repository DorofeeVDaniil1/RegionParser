create function get_tariff_type(tarrif_type character varying) returns character varying
    language plpgsql
as
$$
DECLARE
    result character varying;
BEGIN
    CASE upper(tarrif_type)
        WHEN 'ПО КОЛИЧЕСТВУ ЛОДОК' THEN result := 'VOLUME';
        WHEN 'ПО ОБЪЕМУ' THEN result := 'WEIGHT';
        WHEN 'ПО ВЕСУ И КОЛИЧЕСТВУ ЛОДОК' THEN result := 'VOLUME_AND_WEIGHT';
        WHEN 'ПО ВРЕМЕНИ' THEN result := 'TIME';
        WHEN 'ПО ЧИСЛУ РЕЙСОВ' THEN result := 'TRIPS';
        WHEN 'ПО ЧИСЛУ КОНТЕЙНЕРОВ' THEN result := 'CONTAINERS_AMOUNT';
        WHEN 'ПО ВЕСУ И ВРЕМЕНИ РАБОТЫ' THEN result := 'WEIGHT_AND_TIME';
        WHEN 'ПО ВЕСУ И ЧИСЛУ РЕЙСОВ' THEN result := 'WEIGHT_AND_TRIPS';
        ELSE RAISE EXCEPTION 'Invalid tarrif  type in get_tarrif_type';
        END CASE;

    RETURN result;
END;
$$;

alter function get_tariff_type(varchar) owner to sa;

