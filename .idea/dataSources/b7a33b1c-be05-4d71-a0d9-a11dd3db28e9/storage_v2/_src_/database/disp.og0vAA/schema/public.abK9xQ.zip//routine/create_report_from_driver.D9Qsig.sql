create function create_report_from_driver(_task_detail_id uuid) returns uuid
    language plpgsql
as
$$
declare _id uuid = uuid_generate_v4();
begin

    insert into dsp_report_from_driver(
        id, create_ts, task_detail_id, vehicle_id, containers_amount_plan
    )
    select
        _id,
        now(),
        _task_detail_id,
        dv.id,
        0
    from dsp_task_detail dtd
             join dsp_task dt on dtd.task_id = dt.id
             join dsp_vehicle dv on dt.vehicle_id = dv.id
    where dtd.id = _task_detail_id;

    update dsp_task_detail d set report_id = _id where d.id = _task_detail_id;

    return _id;
end;
$$;

alter function create_report_from_driver(uuid) owner to sa;

