create procedure link_vehicle_to_owner(full_number character varying, company_name character varying)
    language plpgsql
as
$$
begin 
 
update 
	dsp_vehicle 
set 
	owner_id = dsp_company.id
from 
	dsp_company 
where
	full_name like '%' || company_name || '%'
	and
	dsp_vehicle.id = ( 
		select dsp_vehicle.id from dsp_vehicle 
		join dsp_vehicle_number on dsp_vehicle.number_id = dsp_vehicle_number.id
		where full_ like '%' || full_number || '%'
	);
end;
$$;

alter procedure link_vehicle_to_owner(varchar, varchar) owner to sa;

