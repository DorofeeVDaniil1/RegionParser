create function new_brand(_name character varying) returns uuid
    language plpgsql
as
$$
declare

	_u uuid = uuid_generate_v4();
	
begin

	insert into dsp_vehicle_brand
	( id, create_ts, created_by, delete_ts, deleted_by, update_ts, updated_by, name )
	values
	( _u, now()::timestamp, null, null, null, null, null, _name );

	return _u;
	
end;
$$;

alter function new_brand(varchar) owner to sa;

