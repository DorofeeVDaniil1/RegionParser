create function get_or_create_availability_schedule_id(schedule character varying) returns uuid
    language plpgsql
as
$$
BEGIN
    RETURN (
        SELECT COALESCE (
                       (SELECT id FROM dsp_removal_schedule WHERE name = schedule LIMIT 1),
                       new_schedule(schedule)
               )
    );
END;
$$;

alter function get_or_create_availability_schedule_id(varchar) owner to sa;

