create function new_verification(latti double precision, longi double precision, address character varying, area_owner character varying, lk_code_ character varying) returns uuid
    language plpgsql
as
$$
declare
    _u_area uuid = uuid_generate_v4();
    _u_verif uuid = uuid_generate_v4();
begin
    update dsp_container_area set is_verified = false,is_temporary = true,is_archived = true,start_work_date='2024-10-20'where lk_code =lk_code_;
    --         insert into dsp_visit_place(id, visit_place_address, latitude, longitude)
--         values (_u_area,address,latti,longi);
--         insert into dsp_container_area (id,is_verified,address_id,  geo_data_id,  is_archived, is_temporary, start_work_date)
--         values (_u_area,
--                 false,
--                 (select get_or_create_address(address)),
--                 (select get_or_create_geo_data(latti,longi)),
--                 true,
--                 true,
--                 '2024-10-21'
--                 );
    insert into dsp_container_area_verification_request (id, create_ts, created_by,  address_view, company_name, require_area_availability_description, require_groups_condition, require_groups_description, require_photos, require_san_pin, area_id, geo_data_id, order_)
    VALUES(_u_verif,
           current_timestamp,
           'dan.dor',
           address,
           area_owner,
           true,
           true,
           true,
           true,
           true,
           (select id from dsp_container_area where lk_code =lk_code_),
           (select get_or_create_geo_data(latti,longi)),
           0
          );
    return _u_verif;
end;
$$;

alter function new_verification(double precision, double precision, varchar, varchar, varchar) owner to sa;

