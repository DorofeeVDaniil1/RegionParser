create function get_boolean_from_yes_or_no(bool_string character varying) returns boolean
    language plpgsql
as
$$
DECLARE
    result boolean;
BEGIN
    IF bool_string IS NULL THEN
        RETURN NULL;
    END IF;

    CASE upper(bool_string)
        WHEN NULL THEN return NULL;
        WHEN 'ДА' THEN result := true;
        WHEN 'YES' THEN result := true;
        WHEN 'TRUE' THEN result := true;
        WHEN 'ИСТИНА' THEN result := true;
        WHEN 'ЛОЖЬ' THEN result := false;
        WHEN '' THEN result := false;
        WHEN 'NO' THEN result := false;
        WHEN 'НЕТ' THEN result := false;
        WHEN 'FALSE' THEN result := false;
        ELSE RAISE EXCEPTION 'Invalid status';
        END CASE;

    RETURN result;
END;
$$;

alter function get_boolean_from_yes_or_no(varchar) owner to sa;

