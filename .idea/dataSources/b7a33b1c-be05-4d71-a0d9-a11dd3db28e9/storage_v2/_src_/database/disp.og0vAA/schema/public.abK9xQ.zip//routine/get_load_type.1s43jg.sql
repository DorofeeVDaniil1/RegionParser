create function get_load_type(keyword character varying) returns uuid
    language plpgsql
as
$$
begin 

	return

		id from dsp_garbage_load_type
		where upper(name) like upper( concat('%',keyword,'%') ) limit 1;

end;
$$;

alter function get_load_type(varchar) owner to sa;

