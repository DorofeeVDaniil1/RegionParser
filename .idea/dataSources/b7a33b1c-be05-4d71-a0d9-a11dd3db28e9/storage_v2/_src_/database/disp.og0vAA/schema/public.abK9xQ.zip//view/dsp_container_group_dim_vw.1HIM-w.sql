create view dsp_container_group_dim_vw
            (id, entity_name, container_area_code, region_id, region_name, parent_region_name, address,
             owner_company_name, amount, volume, schedule, trips_per_day, tariff)
as
SELECT NULL::uuid                    AS id,
       NULL::text                    AS entity_name,
       NULL::character varying(36)   AS container_area_code,
       NULL::uuid                    AS region_id,
       NULL::text                    AS region_name,
       NULL::text                    AS parent_region_name,
       NULL::character varying(1024) AS address,
       NULL::character varying(500)  AS owner_company_name,
       NULL::integer                 AS amount,
       NULL::double precision        AS volume,
       NULL::character varying       AS schedule,
       NULL::integer                 AS trips_per_day,
       NULL::character varying(255)  AS tariff;

alter table dsp_container_group_dim_vw
    owner to sa;

