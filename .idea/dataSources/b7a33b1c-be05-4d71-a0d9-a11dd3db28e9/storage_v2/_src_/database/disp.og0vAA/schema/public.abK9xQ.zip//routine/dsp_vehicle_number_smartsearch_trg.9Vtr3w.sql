create function dsp_vehicle_number_smartsearch_trg() returns trigger
    language plpgsql
as
$$
begin
    if(NEW.id is distinct from OLD.id or
        NEW.without_region is distinct from OLD.without_region
    ) then
        insert into dsp_smartsearch_queue(context_name, key)
        select distinct
            'dsp_Vehicle',
            cast(v.id as varchar)
        from dsp_vehicle as v
        where v.number_id in (NEW.id, OLD.id);

        insert into dsp_smartsearch_queue(context_name, key)
        select distinct
            'dsp_Task',
            cast(t.id as varchar)
        from dsp_task as t
            join dsp_vehicle as v on t.vehicle_id = v.id
        where v.number_id in (NEW.id, OLD.id);

        insert into dsp_smartsearch_queue(context_name, key)
        select distinct
            'dsp_ContainerArea(taskDetail.task.vehicle)-verification',
            concat(
                cast(td.container_area_id as varchar), ',',
                cast(t.vehicle_id as varchar)
            )
        from dsp_task_detail as td
            join dsp_task as t on td.task_id = t.id
            join dsp_vehicle as v on t.vehicle_id = v.id
        where v.number_id in (NEW.id, OLD.id)
            and td.verification_request_id is not null;

        insert into dsp_smartsearch_queue(context_name, key)
        select distinct
            'dsp_ContainerGroup(taskDetail.task.vehicle)',
            concat(
                cast(l.container_group_id as varchar), ',',
                cast(t.vehicle_id as varchar)
            )
        from dsp_task_detail_container_group_link as l
            join dsp_task_detail as td on l.task_detail_id = td.id
            join dsp_task as t on td.task_id = t.id
            join dsp_vehicle as v on t.vehicle_id = v.id
        where v.number_id in (NEW.id, OLD.id);
    end if;

    return null;
end;
$$;

alter function dsp_vehicle_number_smartsearch_trg() owner to sa;

