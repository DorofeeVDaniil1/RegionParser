create function new_full_params_container_area(lk_code_ character varying, address character varying, lat double precision, long double precision, category_ character varying, company character varying, tariff character varying, amount_ integer, volume_ double precision, category_group character varying, type_container_area character varying DEFAULT NULL::character varying, shedule_name character varying DEFAULT NULL::character varying, carrier character varying DEFAULT NULL::character varying, vehicle_size character varying DEFAULT NULL::character varying, externalcode character varying DEFAULT NULL::character varying, access_in_weekend character varying DEFAULT NULL::character varying, photo_forbid character varying DEFAULT NULL::character varying, is_secure character varying DEFAULT NULL::character varying, is_for_kgo character varying DEFAULT NULL::character varying, phone_number character varying DEFAULT NULL::character varying, comment_for_drivers character varying DEFAULT NULL::character varying, note_ character varying DEFAULT NULL::character varying) returns uuid
    language plpgsql
as
$$
DECLARE
    _u       uuid;
    _u_group uuid;
BEGIN
    -- Проверка на валидность данных
    IF (lk_code_ = '' OR lk_code_ IS NULL) THEN
        RAISE EXCEPTION 'LK_CODE не должен быть пустым';
    END IF;

    IF (tariff = '' OR tariff IS NULL) THEN
        RAISE EXCEPTION 'Тариф не должен быть пустым';
    END IF;

    address = trim(address);

    -- Проверка существования записи в dsp_visit_place
    SELECT id INTO _u
    FROM dsp_visit_place
    WHERE visit_place_address = address
      AND latitude = lat
      AND longitude = long
      AND deleted_by IS NULL
      AND delete_ts IS NULL
    LIMIT 1;

    IF _u IS NULL THEN
        -- Вставляем новую запись в dsp_visit_place
        _u := uuid_generate_v4();
        INSERT INTO dsp_visit_place (id, create_ts, created_by, visit_place_address, latitude, longitude, vp_type)
        VALUES (_u, CURRENT_TIMESTAMP, 'dan.dor', address, lat, long, 'VP_CA');
        RAISE NOTICE 'Visit_Place c адрессом: % создано',address;
    ELSE
        RAISE NOTICE 'Visit_Place с адрессом % уже существует.',address;
    END IF;

    -- Проверка существования dsp_container_area
    IF exists(select 1 from dsp_container_area where id =(select id from dsp_visit_place where  visit_place_address = address
                                                                                           AND latitude = lat
                                                                                           AND longitude = long
                                                                                           AND deleted_by IS NULL
                                                                                           AND delete_ts IS NULL)) THEN
        RAISE NOTICE 'КП с адрессом: % уже существует',address;

        -- Вставка новой контейнерной группы
        _u_group = uuid_generate_v4();

        INSERT INTO dsp_container_group (id, container_area_id, amount, container_type_id, category, carrier_id,schedule_id)
        values (_u_group,
                (SELECT id FROM dsp_container_area where id =(select id from dsp_visit_place where  visit_place_address = address
                                                                                               AND latitude = lat
                                                                                               AND longitude = long
                                                                                               AND deleted_by IS NULL
                                                                                               AND delete_ts IS NULL)),
                amount_,
                get_or_create_container_type_tko(volume_),
                get_int_cont_group_category_from_string(category_group),
                (SELECT id FROM dsp_company WHERE full_name = carrier AND is_carrier = TRUE ),
                (select id from dsp_removal_schedule where name = shedule_name limit 1));
        RAISE NOTICE 'Добавлена новая КГ с amount % , volume: %, schedule %', amount_,volume_,shedule_name;

        RETURN _u_group;
    ELSE
        -- Вставляем новую запись в dsp_container_area
        INSERT INTO dsp_container_area (id, create_ts, created_by, lk_code, note, comment_for_driver, address_id, carrier_id, contact_id, geo_data_id, owner_company_id, tariff_calculation_method_id, type_id, vehicle_size_id, container_area_category_id, is_kgo, is_removal_in_only_working_days, photo_forbidden, secured_territory, external_code)
        VALUES (_u, CURRENT_TIMESTAMP, 'dan.dor', lk_code_, note_, comment_for_drivers, get_or_create_address(address),
                (SELECT id FROM dsp_company WHERE full_name = carrier AND is_carrier = TRUE LIMIT 1),
                create_phone_id(phone_number), new_geo_data_point(lat, long),
                (SELECT id FROM dsp_company WHERE full_name = company LIMIT 1),
                (SELECT id FROM dsp_container_area_tariff_calculation_method WHERE name = tariff),
                (SELECT id FROM dsp_container_area_type WHERE name = type_container_area),
                (SELECT id FROM dsp_vehicle_size WHERE name = vehicle_size),
                (SELECT id FROM dsp_container_area_category WHERE name = category_),
                get_boolean_from_yes_or_no(is_for_kgo),
                get_boolean_from_yes_or_no(access_in_weekend),
                get_boolean_from_yes_or_no(photo_forbid),
                get_boolean_from_yes_or_no(is_secure),
                get_boolean_from_yes_or_no(externalcode));
        RAISE NOTICE 'Новая КП с адрессом: % добавлена',address;

        -- Вставка новой контейнерной группы
        _u_group = uuid_generate_v4();

        INSERT INTO dsp_container_group (id, container_area_id, amount, container_type_id, category, carrier_id,schedule_id)
        values (_u_group,
                (SELECT id FROM dsp_container_area where id =(select id from dsp_visit_place where  visit_place_address = address
                                                                                               AND latitude = lat
                                                                                               AND longitude = long
                                                                                               AND deleted_by IS NULL
                                                                                               AND delete_ts IS NULL)),
                amount_,
                get_or_create_container_type_tko(volume_),
                get_int_cont_group_category_from_string(category_group),
                (SELECT id FROM dsp_company WHERE full_name = carrier AND is_carrier = TRUE ),
                (select id from dsp_removal_schedule where name = shedule_name limit 1));
        RAISE NOTICE 'Добавлена новая КГ с amount % , volume: %, schedule %', amount_,volume_,shedule_name;


        RETURN _u_group;
    END IF;
END;
$$;

alter function new_full_params_container_area(varchar, varchar, double precision, double precision, varchar, varchar, varchar, integer, double precision, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar) owner to sa;

