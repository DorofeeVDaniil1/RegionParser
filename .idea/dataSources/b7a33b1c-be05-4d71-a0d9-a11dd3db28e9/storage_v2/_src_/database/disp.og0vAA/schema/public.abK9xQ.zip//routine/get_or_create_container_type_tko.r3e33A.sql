create function get_or_create_container_type_tko(volume_ double precision) returns uuid
    language plpgsql
as
$$
begin
    return (
        select
            coalesce (
                    (select id from dsp_container_type where volume = volume_ limit 1),
                    new_container_type_tko(volume_)
            )
    );
end;
$$;

alter function get_or_create_container_type_tko(double precision) owner to sa;

