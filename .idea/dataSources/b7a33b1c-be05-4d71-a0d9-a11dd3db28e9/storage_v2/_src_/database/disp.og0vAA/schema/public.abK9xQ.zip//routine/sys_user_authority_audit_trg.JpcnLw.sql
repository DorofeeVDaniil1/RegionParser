create function sys_user_authority_audit_trg() returns trigger
    language plpgsql
as
$$
declare
    user_entity_name constant varchar = 'sys_user';

    employee_entity_name constant varchar = 'dsp_Employee';

    attribute_title constant varchar = 'роль';
    attribute_gender constant audit.gender = 'F';

    new_employee_id uuid;
    old_employee_id uuid;
begin
    if not audit.is_audit_enabled() then
        return coalesce(NEW, OLD);
    end if;

    if NEW.user_id is not null then
        select e.id into new_employee_id
        from dsp_employee as e where e.user_id = NEW.user_id;
    end if;
    if OLD.user_id is not null then
        select e.id into old_employee_id
        from dsp_employee as e where e.user_id = OLD.user_id;
    end if;

    if NEW.user_id is distinct from OLD.user_id
        or NEW.authority_name is distinct from OLD.authority_name
    then
        --TODO: Get rid of this bloody copy-pastes:
        if OLD.user_id is not null and OLD.authority_name is not null then
            call audit.write_instance_audit(user_entity_name, OLD.user_id,
                'DELETE', attribute_title, attribute_gender, OLD.authority_name,
                db_op_type => TG_OP,
                db_field_name => cast(array[
                    concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.user_id'),
                    concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.authority_name')
                ] as varchar),
                old_value => cast(array[
                    cast(OLD.user_id as varchar),
                    cast(OLD.authority_name as varchar)
                ] as varchar),
                new_value => cast(array[
                    cast(NEW.user_id as varchar),
                    cast(NEW.authority_name as varchar)
                ] as varchar)
            );

            select e.id into old_employee_id
            from dsp_employee as e where e.user_id = OLD.user_id;

            if old_employee_id is not null then
                call audit.write_instance_audit(employee_entity_name, old_employee_id,
                    'DELETE', attribute_title, attribute_gender, OLD.authority_name,
                    db_op_type => TG_OP,
                    db_field_name => cast(array[
                        concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.user_id'),
                        concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.authority_name')
                    ] as varchar),
                    old_value => cast(array[
                        cast(OLD.user_id as varchar),
                        cast(OLD.authority_name as varchar)
                    ] as varchar),
                    new_value => cast(array[
                        cast(NEW.user_id as varchar),
                        cast(NEW.authority_name as varchar)
                    ] as varchar)
                );
            end if;
        end if;
        if NEW.user_id is not null and NEW.authority_name is not null then
            call audit.write_instance_audit(user_entity_name, NEW.user_id,
                'INSERT', attribute_title, attribute_gender, NEW.authority_name,
                db_op_type => TG_OP,
                db_field_name => cast(array[
                    concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.user_id'),
                    concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.authority_name')
                ] as varchar),
                old_value => cast(array[
                    cast(OLD.user_id as varchar),
                    cast(OLD.authority_name as varchar)
                ] as varchar),
                new_value => cast(array[
                    cast(NEW.user_id as varchar),
                    cast(NEW.authority_name as varchar)
                ] as varchar)
            );

            select e.id into new_employee_id
            from dsp_employee as e where e.user_id = NEW.user_id;

            if new_employee_id is not null then
                call audit.write_instance_audit(employee_entity_name, new_employee_id,
                    'INSERT', attribute_title, attribute_gender, NEW.authority_name,
                    db_op_type => TG_OP,
                    db_field_name => cast(array[
                        concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.user_id'),
                        concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.authority_name')
                    ] as varchar),
                    old_value => cast(array[
                        cast(OLD.user_id as varchar),
                        cast(OLD.authority_name as varchar)
                    ] as varchar),
                    new_value => cast(array[
                        cast(NEW.user_id as varchar),
                        cast(NEW.authority_name as varchar)
                    ] as varchar)
                );
            end if;
        end if;
    end if;

    return coalesce(NEW, OLD);
end;
$$;

alter function sys_user_authority_audit_trg() owner to sa;

