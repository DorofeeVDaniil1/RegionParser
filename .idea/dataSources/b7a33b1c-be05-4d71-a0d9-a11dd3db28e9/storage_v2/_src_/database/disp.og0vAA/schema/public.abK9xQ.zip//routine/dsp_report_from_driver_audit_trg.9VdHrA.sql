create function dsp_report_from_driver_audit_trg() returns trigger
    language plpgsql
as
$$
declare
    entity_name constant varchar = 'dsp_ReportFromDriver';
    entity_title constant varchar = 'отчет водителя';
    entity_gender constant audit.gender = 'M';
begin
    if not audit.is_audit_enabled() then
        return coalesce(NEW, OLD);
    end if;

    if NEW.id is distinct from OLD.id then
        if NEW.id is not null then
            call audit.write_instance_audit(entity_name, NEW.id,
                'CREATE', entity_title, entity_gender,
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.id'),
                old_value => cast(OLD.id as varchar),
                new_value => cast(NEW.id as varchar));
        end if;
        if OLD.id is not null then
            call audit.write_instance_audit(entity_name, OLD.id,
                'DELETE', entity_title, entity_gender,
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.id'),
                old_value => cast(OLD.id as varchar),
                new_value => cast(NEW.id as varchar));
        end if;
    end if;
    if NEW.id is not null then
        if (NEW.delete_ts is not null) is distinct from (OLD.delete_ts is not null) then
            call audit.write_instance_audit(entity_name, NEW.id,
                audit.get_soft_op_type(NEW.delete_ts is not null, OLD.delete_ts is not null),
                entity_title, entity_gender,
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.delete_ts'),
                old_value => cast(OLD.delete_ts as varchar),
                new_value => cast(NEW.delete_ts as varchar));
        end if;
        if NEW.task_detail_id is distinct from OLD.task_detail_id then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.task_detail_id is null, OLD.task_detail_id is null),
                'деталь ПЗ', 'F', audit.get_task_detail_str(coalesce(NEW.task_detail_id, OLD.task_detail_id)),
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.task_detail_id'),
                old_value => cast(OLD.task_detail_id as varchar),
                new_value => cast(NEW.task_detail_id as varchar));
        end if;
        if NEW.vehicle_id is distinct from OLD.vehicle_id then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.vehicle_id is null, OLD.vehicle_id is null),
                'ТС', 'N', audit.get_vehicle_str(coalesce(NEW.vehicle_id, OLD.vehicle_id)),
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.vehicle_id'),
                old_value => cast(OLD.vehicle_id as varchar),
                new_value => cast(NEW.vehicle_id as varchar));
        end if;
        if NEW.driver_id is distinct from OLD.driver_id then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.driver_id is null, OLD.driver_id is null),
                'водитель', 'M', audit.get_employee_str(coalesce(NEW.driver_id, OLD.driver_id)),
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.driver_id'),
                old_value => cast(OLD.driver_id as varchar),
                new_value => cast(NEW.driver_id as varchar));
        end if;
        if NEW.containers_amount_picked_up is distinct from OLD.containers_amount_picked_up then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.containers_amount_picked_up is null, OLD.containers_amount_picked_up is null),
                'подбор', 'M', audit.get_double_str(coalesce(NEW.containers_amount_picked_up, OLD.containers_amount_picked_up)),
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.containers_amount_picked_up'),
                old_value => cast(OLD.containers_amount_picked_up as varchar),
                new_value => cast(NEW.containers_amount_picked_up as varchar));
        end if;
        if NEW.garbage_removal_fail_reason_id is distinct from OLD.garbage_removal_fail_reason_id then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.garbage_removal_fail_reason_id is null, OLD.garbage_removal_fail_reason_id is null),
                'причина невывоза', 'F', audit.get_removal_fail_reason_str(coalesce(NEW.garbage_removal_fail_reason_id, OLD.garbage_removal_fail_reason_id)),
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.garbage_removal_fail_reason_id'),
                old_value => cast(OLD.garbage_removal_fail_reason_id as varchar),
                new_value => cast(NEW.garbage_removal_fail_reason_id as varchar));
        end if;
        if NEW.removal_problem_id is distinct from OLD.removal_problem_id then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.removal_problem_id is null, OLD.removal_problem_id is null),
                'проблема КП', 'F', audit.get_removal_fail_reason_str(coalesce(NEW.removal_problem_id, OLD.removal_problem_id)),
                db_op_type => TG_OP, db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.removal_problem_id'),
                old_value => cast(OLD.removal_problem_id as varchar),
                new_value => cast(NEW.removal_problem_id as varchar));
        end if;
        if NEW.comment_from_driver is distinct from OLD.comment_from_driver then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.comment_from_driver is null, OLD.comment_from_driver is null),
                'комментарий водителя', 'M', coalesce(NEW.comment_from_driver, OLD.comment_from_driver),
                db_op_type => TG_OP, db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.comment_from_driver'),
                old_value => cast(OLD.comment_from_driver as varchar),
                new_value => cast(NEW.comment_from_driver as varchar));
        end if;
        if NEW.removal_date is distinct from OLD.removal_date then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.removal_date is null, OLD.removal_date is null),
                'дата вывоза', 'F', audit.get_datetime_str(coalesce(NEW.removal_date, OLD.removal_date)),
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.removal_date'),
                old_value => cast(OLD.removal_date as varchar),
                new_value => cast(NEW.removal_date as varchar));
        end if;
        -- добавлено для отладки:
        if NEW.update_ts is distinct from OLD.update_ts then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.update_ts is null, OLD.update_ts is null),
                'дата изменения', 'F', audit.get_datetime_str(coalesce(NEW.update_ts, OLD.update_ts)),
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.update_ts'),
                old_value => cast(OLD.update_ts as varchar),
                new_value => cast(NEW.update_ts as varchar));
        end if;
        if NEW.export_ts is distinct from OLD.export_ts then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.export_ts is null, OLD.export_ts is null),
                'дата экспорта', 'F', audit.get_datetime_str(coalesce(NEW.export_ts, OLD.update_ts)),
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.export_ts'),
                old_value => cast(OLD.export_ts as varchar),
                new_value => cast(NEW.export_ts as varchar));
        end if;
    end if;

    return coalesce(NEW, OLD);
end;
$$;

alter function dsp_report_from_driver_audit_trg() owner to sa;

