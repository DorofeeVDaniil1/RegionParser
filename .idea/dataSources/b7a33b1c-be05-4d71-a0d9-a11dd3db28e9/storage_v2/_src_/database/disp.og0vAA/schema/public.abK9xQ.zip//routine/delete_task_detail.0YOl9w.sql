create procedure delete_task_detail(_id uuid)
    language plpgsql
as
$$
begin

		delete from dsp_task_detail_container_group_link where task_detail_id = _id;
		
			update dsp_task_detail set report_id = null where id = _id;
			delete from dsp_report_from_driver_container where report_id in ( select id from dsp_report_from_driver where task_detail_id = _id );
			delete from dsp_removal_report_from_driver_photo_file_descriptor_link where garbage_removal_report_from_driver_id in ( select id from dsp_report_from_driver where task_detail_id = _id );
			delete from dsp_not_removed_container_group where report_id in ( select id from dsp_report_from_driver where task_detail_id = _id );
		
		delete from dsp_report_from_driver where task_detail_id = _id;
		delete from dsp_task_detail_move_event where task_detail_id = _id;
		delete from dsp_container_area_geo_zone_event where task_detail_id = _id;
		
			update dsp_task_detail set event_id = null where id = _id;
		
		delete from dsp_task_detail_event where task_detail_id = _id;

	delete from dsp_task_detail where id = _id;

	
end;
$$;

alter procedure delete_task_detail(uuid) owner to sa;

