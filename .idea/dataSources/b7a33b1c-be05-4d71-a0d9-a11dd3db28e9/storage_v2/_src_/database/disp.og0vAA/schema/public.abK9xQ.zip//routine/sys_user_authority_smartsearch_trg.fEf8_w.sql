create function sys_user_authority_smartsearch_trg() returns trigger
    language plpgsql
as
$$
begin
    if(NEW.user_id is distinct from OLD.user_id or
        NEW.authority_name is distinct from OLD.authority_name
    ) then
        insert into dsp_smartsearch_queue(context_name, key)
        select distinct
            'dsp_Employee',
            cast(e.id as varchar)
        from dsp_employee as e
        where e.user_id in (NEW.user_id, OLD.user_id);
    end if;

    return null;
end;
$$;

alter function sys_user_authority_smartsearch_trg() owner to sa;

