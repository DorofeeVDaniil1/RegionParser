create function find_vehicle_linked_to_container_area(_lk_code character varying)
    returns TABLE(vehicle character varying)
    language plpgsql
as
$$
begin   
return query 

	select dsp_route.name as route 
	from dsp_container_group
	join dsp_container_area ON dsp_container_area.id = dsp_container_group.container_area_id
	join dsp_route ON dsp_route.id = dsp_container_group.route_id

	where lk_code = _lk_code
	;
	
end;
$$;

alter function find_vehicle_linked_to_container_area(varchar) owner to sa;

