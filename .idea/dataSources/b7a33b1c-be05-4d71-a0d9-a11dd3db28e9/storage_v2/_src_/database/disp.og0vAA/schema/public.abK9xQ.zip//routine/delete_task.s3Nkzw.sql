create procedure delete_task(_id uuid)
    language plpgsql
as
$$
begin
 

		delete from dsp_schedule_violation_not_removed_container_group_link where schedule_violation_id in (
		
			select id from dsp_schedule_violation 
			where 
			dsp_schedule_violation.failed_task_detail_id in (select id from dsp_task_detail where task_id = _id or source_task_id = _id)
			or
			dsp_schedule_violation.planned_task_detail_id in (select id from dsp_task_detail where task_id = _id or source_task_id = _id)
		
		);

		delete from dsp_schedule_violation_container_group_link where schedule_violation_id in (
		
			select id from dsp_schedule_violation 
			where 
			dsp_schedule_violation.failed_task_detail_id in (select id from dsp_task_detail where task_id = _id or source_task_id = _id)
			or
			dsp_schedule_violation.planned_task_detail_id in (select id from dsp_task_detail where task_id = _id or source_task_id = _id)
			
		);

		delete from dsp_schedule_violation where dsp_schedule_violation.failed_task_detail_id in (select id from dsp_task_detail where task_id = _id or source_task_id = _id);
		delete from dsp_schedule_violation where dsp_schedule_violation.planned_task_detail_id in (select id from dsp_task_detail where task_id = _id or source_task_id = _id);

		delete from dsp_task_detail_container_group_link where task_detail_id in (select id from dsp_task_detail where task_id = _id or source_task_id = _id);
		
			update dsp_task_detail set report_id = null where task_id = _id or source_task_id = _id;
			delete from dsp_report_from_driver_container where report_id in ( select id from dsp_report_from_driver where task_detail_id in (select id from dsp_task_detail where task_id = _id or source_task_id = _id) );
			delete from dsp_removal_report_from_driver_photo_file_descriptor_link where garbage_removal_report_from_driver_id in ( select id from dsp_report_from_driver where task_detail_id in (select id from dsp_task_detail where task_id = _id or source_task_id = _id) );
			delete from dsp_not_removed_container_group where report_id in ( select id from dsp_report_from_driver where task_detail_id in (select id from dsp_task_detail where task_id = _id or source_task_id = _id) );
		
		delete from dsp_report_from_driver where task_detail_id in (select id from dsp_task_detail where task_id = _id or source_task_id = _id);
		delete from dsp_task_detail_move_event where task_detail_id in (select id from dsp_task_detail where task_id = _id or source_task_id = _id);
		delete from dsp_container_area_geo_zone_event where task_detail_id in (select id from dsp_task_detail where task_id = _id or source_task_id = _id);
		
			update dsp_task_detail set event_id = null where task_id = _id or source_task_id = _id;
		
		delete from dsp_task_detail_event where task_detail_id in (select id from dsp_task_detail where task_id = _id or source_task_id = _id);

	delete from dsp_task_detail	where task_id = _id or source_task_id = _id;	
	delete from dsp_vehicle_location_geo_zone_event	where task_id = _id;
	delete from dsp_waste_dump_geo_zone_event where task_id = _id;
	delete from dsp_task_detail_move_event where source_task_id = _id;
	delete from dsp_task_performers where task_id = _id;

delete from dsp_task where id = _id;
	
end;
$$;

alter procedure delete_task(uuid) owner to sa;

