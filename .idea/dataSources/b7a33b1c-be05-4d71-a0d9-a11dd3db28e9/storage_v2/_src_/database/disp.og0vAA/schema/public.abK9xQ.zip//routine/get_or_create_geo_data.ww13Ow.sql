create function get_or_create_geo_data(lati double precision, longi double precision) returns uuid
    language plpgsql
as
$$
begin
    return (
        select
            coalesce (
                    (select id from dsp_geo_data where center_id =(select id from dsp_geo_point where latitude =lati and longitude = longi limit 1)limit 1),
                    new_geo_data_point(lati,longi)
            )
    );
end;
$$;

alter function get_or_create_geo_data(double precision, double precision) owner to sa;

