create function dsp_route_detail_audit_trg() returns trigger
    language plpgsql
as
$$
declare
    route_entity_name constant varchar = 'dsp_Route';
    route_entity_title constant varchar = 'маршрут';
    route_entity_gender constant audit.gender = 'M';

    cg_entity_name constant varchar = 'dsp_ContainerGroup';
    cg_entity_title constant varchar = 'КГ';
    cg_entity_gender constant audit.gender = 'F';

    ca_entity_name constant varchar = 'dsp_ContainerArea';

    new_ca_id uuid;
    old_ca_id uuid;
begin
    if not audit.is_audit_enabled() then
        return coalesce(NEW, OLD);
    end if;

    --TODO: implement soft-delete/soft-restore processing

    if NEW.group_id is not null then
        select cg.container_area_id into new_ca_id
        from dsp_container_group as cg where cg.id = NEW.group_id;
    end if;
    if OLD.group_id is not null then
        select cg.container_area_id into old_ca_id
        from dsp_container_group as cg where cg.id = OLD.group_id;
    end if;

    if NEW.route_id is distinct from OLD.route_id
        or NEW.group_id is distinct from OLD.group_id
    then
        --TODO: Get rid of this bloody copy-pastes:
        if OLD.route_id is not null and OLD.group_id is not null then
            call audit.write_instance_audit(route_entity_name, OLD.route_id,
                'DELETE', cg_entity_title, cg_entity_gender,
                audit.get_container_group_str(OLD.group_id),
                db_op_type => TG_OP,
                db_field_name => cast(array[
                    concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.route_id'),
                    concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.group_id')
                ] as varchar),
                old_value => cast(array[
                    cast(OLD.route_id as varchar),
                    cast(OLD.group_id as varchar)
                ] as varchar),
                new_value => cast(array[
                    cast(NEW.route_id as varchar),
                    cast(NEW.group_id as varchar)
                ] as varchar)
            );
            call audit.write_instance_audit(cg_entity_name, OLD.group_id,
                'DELETE', route_entity_title, route_entity_gender,
                audit.get_route_str(OLD.route_id),
                db_op_type => TG_OP,
                db_field_name => cast(array[
                    concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.route_id'),
                    concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.group_id')
                ] as varchar),
                old_value => cast(array[
                    cast(OLD.route_id as varchar),
                    cast(OLD.group_id as varchar)
                ] as varchar),
                new_value => cast(array[
                    cast(NEW.route_id as varchar),
                    cast(NEW.group_id as varchar)
                ] as varchar)
            );
        end if;
        if NEW.route_id is not null and NEW.group_id is not null then
            call audit.write_instance_audit(route_entity_name, NEW.route_id,
                'INSERT', cg_entity_title, cg_entity_gender,
                audit.get_container_group_str(NEW.group_id),
                db_op_type => TG_OP,
                db_field_name => cast(array[
                    concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.route_id'),
                    concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.group_id')
                ] as varchar),
                old_value => cast(array[
                    cast(OLD.route_id as varchar),
                    cast(OLD.group_id as varchar)
                ] as varchar),
                new_value => cast(array[
                    cast(NEW.route_id as varchar),
                    cast(NEW.group_id as varchar)
                ] as varchar)
            );
            call audit.write_instance_audit(cg_entity_name, NEW.group_id,
                'INSERT', route_entity_title, route_entity_gender,
                audit.get_route_str(NEW.route_id),
                db_op_type => TG_OP,
                db_field_name => cast(array[
                    concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.route_id'),
                    concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.group_id')
                ] as varchar),
                old_value => cast(array[
                    cast(OLD.route_id as varchar),
                    cast(OLD.group_id as varchar)
                ] as varchar),
                new_value => cast(array[
                    cast(NEW.route_id as varchar),
                    cast(NEW.group_id as varchar)
                ] as varchar)
            );
        end if;
    end if;

    --TODO: Extend audit API for one-to-many linked entities and then review the code below:
    --TODO: Do I need to audit changes below for the dsp_ContainerGroup entity itself?
    if NEW.route_id is distinct from OLD.route_id
        or new_ca_id is distinct from old_ca_id
    then
        --TODO: Get rid of this bloody copy-pastes:
        if OLD.route_id is not null and old_ca_id is not null then
            call audit.write_audit(
                ca_entity_name,
                old_ca_id,
                audit.capitalize(
                    concat_ws(' ',
                        audit.get_op_str('DELETE', route_entity_gender),
                        route_entity_title,
                        concat('"', audit.get_route_str(OLD.route_id), '"'),
                        'для', cg_entity_title,
                        audit.get_container_group_short_str(OLD.group_id)
                    )
                ),
                'DELETE',
                db_op_type => TG_OP,
                db_field_name => cast(array[
                    -- group_id influences implicitly on (old|new)_ca_id:
                    concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.route_id'),
                    concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.group_id')
                ] as varchar),
                old_value => cast(array[
                    cast(OLD.route_id as varchar),
                    cast(OLD.group_id as varchar)
                ] as varchar),
                new_value => cast(array[
                    cast(NEW.route_id as varchar),
                    cast(NEW.group_id as varchar)
                ] as varchar)
            );
        end if;
        if NEW.route_id is not null and new_ca_id is not null then
            call audit.write_audit(
                ca_entity_name,
                new_ca_id,
                audit.capitalize(
                    concat_ws(' ',
                        audit.get_op_str('INSERT', route_entity_gender),
                        route_entity_title,
                        concat('"', audit.get_route_str(NEW.route_id), '"'),
                        'для', cg_entity_title,
                        audit.get_container_group_short_str(NEW.group_id)
                    )
                ),
                'INSERT',
                db_op_type => TG_OP,
                db_field_name => cast(array[
                    -- group_id influences implicitly on (old|new)_ca_id:
                    concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.route_id'),
                    concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.group_id')
                ] as varchar),
                old_value => cast(array[
                    cast(OLD.route_id as varchar),
                    cast(OLD.group_id as varchar)
                ] as varchar),
                new_value => cast(array[
                    cast(NEW.route_id as varchar),
                    cast(NEW.group_id as varchar)
                ] as varchar)
            );
        end if;
    end if;

    if new_ca_id is not null then
        if NEW.schedule_id is distinct from OLD.schedule_id then
            call audit.write_audit(
                ca_entity_name,
                new_ca_id,
                concat_ws(' ',
                    concat('<strong>', audit.capitalize('график маршрута'), '</strong>,'),
                    audit.get_op_str(audit.get_op_type(NEW.schedule_id is null, OLD.schedule_id is null), 'M'),
                    concat('"', audit.get_removal_schedule_str(coalesce(NEW.schedule_id, OLD.schedule_id)), '"'),
                    'для', cg_entity_title, audit.get_container_group_short_str(NEW.group_id),
                    --FIXME: Take in account that the NEW.route_id value may be null here:
                    'в маршруте', audit.get_route_str(NEW.route_id)
                ),
                --TODO: Get rid of copy-paste (get_op_type function call below adopted from couple rows above):
                op_type => cast(audit.get_op_type(NEW.schedule_id is null, OLD.schedule_id is null) as varchar),
                db_op_type => TG_OP,
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.schedule_id'),
                old_value => cast(OLD.schedule_id as varchar),
                new_value => cast(NEW.schedule_id as varchar)
            );
        end if;
    end if;

    return coalesce(NEW, OLD);
end;
$$;

alter function dsp_route_detail_audit_trg() owner to sa;

