create function create_picked_up_recorded_in_container(_report_id uuid, _container_group_id uuid, _picked_up integer) returns uuid
    language plpgsql
as
$$
declare _id uuid = uuid_generate_v4();
begin
    insert into dsp_picked_up_recorded_in_container(
        id, create_ts, amount, volume, container_type_id, container_group_id, report_id
    )
    select
        _id,
        now(),
        _picked_up,
        dct.volume,
        dct.id,
        dcg.id,
        _report_id
    from dsp_container_group dcg
             join dsp_container_type dct on dcg.container_type_id = dct.id
    where dcg.id = _container_group_id;
    return _id;
end;
$$;

alter function create_picked_up_recorded_in_container(uuid, uuid, integer) owner to sa;

