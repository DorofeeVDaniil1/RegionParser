create function find_reports_on_date(target_container_group_id uuid, target_date date, server_timezone character varying)
    returns TABLE(id uuid)
    language plpgsql
as
$$
begin
    return query
    select drfd.id
    from dsp_container_area dca
             join dsp_container_group dcg on dca.id = dcg.container_area_id
             join dsp_container_type dct on dcg.container_type_id = dct.id
             join dsp_task_detail_container_group_link l on dcg.id = l.container_group_id
             join dsp_task_detail dtd on l.task_detail_id = dtd.id
             join dsp_report_from_driver drfd on dtd.id = drfd.task_detail_id
             join dsp_removal_schedule drs on dcg.schedule_id = drs.id
             left join dsp_report_detailing_fact f on drfd.id = f.report_id and f.container_group_id = dcg.id
             left join dsp_report_detailing_empty e on drfd.id = e.report_id and e.container_group_id = dcg.id
             left join dsp_report_detailing_not_removed n on drfd.id = n.report_id and n.container_group_id = dcg.id
             left join dsp_picked_up_recorded_in_container p on drfd.id = p.report_id
    where (coalesce(drfd.removal_date, drfd.create_ts) at time zone 'UTC' at time zone server_timezone)::date = target_date
      and target_container_group_id = dcg.id;
end;
$$;

alter function find_reports_on_date(uuid, date, varchar) owner to sa;

