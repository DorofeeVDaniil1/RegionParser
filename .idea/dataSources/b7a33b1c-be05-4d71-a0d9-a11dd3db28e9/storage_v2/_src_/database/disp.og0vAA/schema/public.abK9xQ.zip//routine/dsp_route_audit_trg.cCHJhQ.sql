create function dsp_route_audit_trg() returns trigger
    language plpgsql
as
$$
declare
    entity_name constant varchar = 'dsp_Route';
    entity_title constant varchar = 'маршрут';
    entity_gender constant audit.gender = 'M';
begin
    if not audit.is_audit_enabled() then
        return coalesce(NEW, OLD);
    end if;

    if NEW.id is distinct from OLD.id then
        if NEW.id is not null then
            call audit.write_instance_audit(entity_name, NEW.id,
                'CREATE', entity_title, entity_gender,
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.id'),
                old_value => cast(OLD.id as varchar),
                new_value => cast(NEW.id as varchar));
        end if;
        if OLD.id is not null then
            call audit.write_instance_audit(entity_name, OLD.id,
                'DELETE', entity_title, entity_gender,
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.id'),
                old_value => cast(OLD.id as varchar),
                new_value => cast(NEW.id as varchar));
        end if;
    end if;
    if NEW.id is not null then
        if (NEW.delete_ts is not null) is distinct from (OLD.delete_ts is not null) then
            call audit.write_instance_audit(entity_name, NEW.id,
                audit.get_soft_op_type(NEW.delete_ts is not null, OLD.delete_ts is not null),
                entity_title, entity_gender,
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.delete_ts'),
                old_value => cast(OLD.delete_ts as varchar),
                new_value => cast(NEW.delete_ts as varchar));
        end if;
        if NEW.name is distinct from OLD.name then
            call audit.write_attribute_audit(entity_name, NEW.id, 
                audit.get_op_type(NEW.name is null, OLD.name is null),
                'наименование', 'N', coalesce(NEW.name, OLD.name),
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.name'),
                old_value => cast(OLD.name as varchar),
                new_value => cast(NEW.name as varchar));
        end if;
        if NEW.carrier_id is distinct from OLD.carrier_id then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.carrier_id is null, OLD.carrier_id is null),
                'перевозчик', 'M', audit.get_company_str(coalesce(NEW.carrier_id, OLD.carrier_id)),
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.carrier_id'),
                old_value => cast(OLD.carrier_id as varchar),
                new_value => cast(NEW.carrier_id as varchar));
        end if;                
        if NEW.region_id is distinct from OLD.region_id then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.region_id is null, OLD.region_id is null),
                'район', 'M', audit.get_region_str(coalesce(NEW.region_id, OLD.region_id)),
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.region_id'),
                old_value => cast(OLD.region_id as varchar),
                new_value => cast(NEW.region_id as varchar));
        end if;
    end if;

    return coalesce(NEW, OLD);
end;
$$;

alter function dsp_route_audit_trg() owner to sa;

