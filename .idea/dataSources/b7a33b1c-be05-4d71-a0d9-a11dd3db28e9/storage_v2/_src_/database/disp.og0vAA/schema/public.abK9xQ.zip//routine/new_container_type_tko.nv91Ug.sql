create function new_container_type_tko(volume_ double precision) returns uuid
    language plpgsql
as
$$
declare

    _u uuid = uuid_generate_v4();

begin
    if ( volume_ is null ) THEN
        insert into dsp_container_type (
            id,
            code,
            name,
            volume,
            material_id,
            is_active,
            is_editable
        )

        select
            _u,
            'container_kgo',
            'КГО',
            0,
            null,
            true,
            true
        ;

        return _u;
    ELSE
        insert into dsp_container_type (
            id,
            code,
            name,
            volume,
            material_id,
            is_active,
            is_editable
        )

        select
            _u,
            'container_'||replace(volume_::varchar, '.', '_'),
            'Контейнер ' || volume_ || ' м3',
            volume_,
            (select id from dsp_material where upper(code) = 'TKO'),
            true,
            true
        ;

        return _u;
    end if;



end;
$$;

alter function new_container_type_tko(double precision) owner to sa;

