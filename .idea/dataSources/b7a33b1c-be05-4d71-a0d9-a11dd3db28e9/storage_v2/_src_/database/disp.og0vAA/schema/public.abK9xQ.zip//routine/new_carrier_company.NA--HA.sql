create function new_carrier_company(_full_name character varying, _short_name character varying) returns uuid
    language plpgsql
as
$$
declare 
  
	_u uuid = uuid_generate_v4();
	
begin

	insert into dsp_company
	( id, create_ts, created_by, full_name, short_name, is_carrier,type )
	values
	( _u, now()::timestamp, 'new_carrier_company()', _full_name, _short_name, true,'CARRIER' );

	return _u;
	
end;
$$;

alter function new_carrier_company(varchar, varchar) owner to sa;

