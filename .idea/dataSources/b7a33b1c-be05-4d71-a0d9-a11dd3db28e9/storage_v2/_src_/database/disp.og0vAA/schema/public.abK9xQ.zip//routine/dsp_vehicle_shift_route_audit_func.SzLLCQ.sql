create function dsp_vehicle_shift_route_audit_func() returns trigger
    language plpgsql
as
$$
declare
    entity_name constant varchar = 'dsp_Vehicle';
    route_entity_name constant varchar = 'маршрут';
    route_entity_gender constant audit.gender = 'M';

    vehicle dsp_vehicle;
    vehicle_shift dsp_vehicle_shift;
    vehicle_shift_route dsp_route;
begin
    if not audit.is_audit_enabled() then
        return coalesce(NEW, OLD);
    end if;

    -- Getting referenced vehicle entity
    select * into vehicle from dsp_vehicle
    where id = (select dvs.vehicle_id from dsp_vehicle_shift dvs
                where dvs.id = coalesce(NEW.dsp_vehicle_shift_id, OLD.dsp_vehicle_shift_id));

    -- Getting referenced vehicle shift entity
    select * into vehicle_shift from dsp_vehicle_shift
    where id = coalesce(NEW.dsp_vehicle_shift_id, OLD.dsp_vehicle_shift_id);

    -- Getting referenced vehicle shift route entity
    select * into vehicle_shift_route from dsp_route
    where id = coalesce(NEW.route_id, OLD.route_id);

    -- If vehicle shift is non-auditable do not write audit
    if audit.is_auditable_vehicle_shift(vehicle_shift) is false then
        return coalesce(NEW, OLD);
    end if;

    -- When new link between route and vehicle shift just created
    if TG_OP = 'INSERT' then

        call audit.write_attribute_audit(
            entity_name,
            vehicle.id,
            cast('INSERT' as audit.op_type),
            audit.get_vehicle_shift_str(vehicle_shift.number),
            route_entity_gender,
            text_added_to_event_descr => concat(route_entity_name, ' "', audit.prettify_route_str(audit.get_route_str(vehicle_shift_route.id)), '"'),
            db_op_type => TG_OP,
            db_field_name => cast(array[
                concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.dsp_vehicle_shift_id'),
                concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.route_id')
                ] as varchar),
            old_value =>  cast(array[
                cast(OLD.dsp_vehicle_shift_id as varchar),
                cast(OLD.route_id as varchar)
                ] as varchar),
            new_value => cast(array[
                cast(NEW.dsp_vehicle_shift_id as varchar),
                cast(NEW.route_id as varchar)
                ] as varchar)
            );
    end if;

    -- When existing link between route and vehicle shift just deleted
    if TG_OP = 'DELETE' then

        call audit.write_attribute_audit(
            entity_name,
            vehicle.id,
            cast('DELETE' as audit.op_type),
            audit.get_vehicle_shift_str(vehicle_shift.number),
            route_entity_gender,
            text_added_to_event_descr => concat(route_entity_name, ' "', audit.prettify_route_str(audit.get_route_str(vehicle_shift_route.id)), '"'),
            db_op_type => TG_OP,
            db_field_name => cast(array[
                concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.dsp_vehicle_shift_id'),
                concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.route_id')
                ] as varchar),
            old_value =>  cast(array[
                cast(OLD.dsp_vehicle_shift_id as varchar),
                cast(OLD.route_id as varchar)
                ] as varchar),
            new_value => cast(array[
                cast(NEW.dsp_vehicle_shift_id as varchar),
                cast(NEW.route_id as varchar)
                ] as varchar)
            );
    end if;

    return coalesce(NEW, OLD);
end
$$;

alter function dsp_vehicle_shift_route_audit_func() owner to sa;

