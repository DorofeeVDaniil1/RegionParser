create function new_person_by_full_name(full_name character varying) returns uuid
    language plpgsql
as
$$
    declare
        correct_full_name text := (select regexp_replace(full_name, E'[\r\n]+', ' ', 'g'));
        f_name text := (select split_part(correct_full_name,' ',2));
        l_name text := (select split_part(correct_full_name,' ',1));
        _u uuid:= uuid_generate_v4();
    begin
        insert into dsp_person (id, create_ts, created_by, first_name,
                                full_name, last_name)
        values (
                _u,
                CURRENT_TIMESTAMP,
                'system',
                f_name,
                correct_full_name,
                l_name
               );
    end;


$$;

alter function new_person_by_full_name(varchar) owner to sa;

