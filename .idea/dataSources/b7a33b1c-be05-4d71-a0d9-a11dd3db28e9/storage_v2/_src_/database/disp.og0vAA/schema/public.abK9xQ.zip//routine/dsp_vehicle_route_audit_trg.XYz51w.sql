create function dsp_vehicle_route_audit_trg() returns trigger
    language plpgsql
as
$$
declare
    vehicle_entity_name constant varchar = 'dsp_Vehicle';

    route_entity_title constant varchar = 'маршрут';
    route_entity_gender constant audit.gender = 'M';
begin
    if not audit.is_audit_enabled() then
        return coalesce(NEW, OLD);
    end if;

    --TODO: implement soft-delete/soft-restore processing

    if NEW.vehicle_id is distinct from OLD.vehicle_id
        or NEW.route_id is distinct from OLD.route_id
    then
        --TODO: Get rid of this bloody copy-pastes:
        if OLD.vehicle_id is not null and OLD.route_id is not null then
            call audit.write_instance_audit(vehicle_entity_name, OLD.vehicle_id,
                'DELETE', route_entity_title, route_entity_gender,
                audit.get_route_str(OLD.route_id),
                db_op_type => TG_OP,
                db_field_name => cast(array[
                    concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.vehicle_id'),
                    concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.route_id')
                ] as varchar),
                old_value => cast(array[
                    cast(OLD.vehicle_id as varchar),
                    cast(OLD.route_id as varchar)
                ] as varchar),
                new_value => cast(array[
                    cast(NEW.vehicle_id as varchar),
                    cast(NEW.route_id as varchar)
                ] as varchar)
            );
        end if;
        if NEW.vehicle_id is not null and NEW.route_id is not null then
            call audit.write_instance_audit(vehicle_entity_name, NEW.vehicle_id,
                'INSERT', route_entity_title, route_entity_gender,
                audit.get_route_str(NEW.route_id),
                db_op_type => TG_OP,
                db_field_name => cast(array[
                    concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.vehicle_id'),
                    concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.route_id')
                ] as varchar),
                old_value => cast(array[
                    cast(OLD.vehicle_id as varchar),
                    cast(OLD.route_id as varchar)
                ] as varchar),
                new_value => cast(array[
                    cast(NEW.vehicle_id as varchar),
                    cast(NEW.route_id as varchar)
                ] as varchar)
            );
        end if;
    end if;

    return coalesce(NEW, OLD);
end;
$$;

alter function dsp_vehicle_route_audit_trg() owner to sa;

