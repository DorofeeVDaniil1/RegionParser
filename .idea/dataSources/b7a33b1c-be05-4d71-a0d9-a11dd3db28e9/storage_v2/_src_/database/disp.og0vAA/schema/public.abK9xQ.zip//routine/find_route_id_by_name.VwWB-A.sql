create function find_route_id_by_name(_name character varying) returns uuid
    language plpgsql
as
$$
begin 
	
 	 return (select id from dsp_route where name = _name);

end;
$$;

alter function find_route_id_by_name(varchar) owner to sa;

