create function update_route_from_tasks(_vehicle_id uuid, _route_id uuid, _from date, _to date) returns void
    language plpgsql
as
$$
begin

 	 update dsp_container_group
	 
	 set route_id = _route_id
	 
	 where id in (
	 
		select dsp_container_group.id

		from dsp_container_group
		join dsp_task_detail_container_group_link ON dsp_task_detail_container_group_link.container_group_id = dsp_container_group.id
		join dsp_task_detail ON dsp_task_detail.id = dsp_task_detail_container_group_link.task_detail_id
		join dsp_task x ON x.id = dsp_task_detail.task_id
		join dsp_vehicle ON dsp_vehicle.id = x.vehicle_id
		join dsp_vehicle_number ON dsp_vehicle_number.id = dsp_vehicle.number_id

		where start_date between _from and _to and dsp_vehicle.id = _vehicle_id
		 
		and not exists (
			select dsp_container_group.id

			from dsp_container_group
			join dsp_task_detail_container_group_link ON dsp_task_detail_container_group_link.container_group_id = dsp_container_group.id
			join dsp_task_detail ON dsp_task_detail.id = dsp_task_detail_container_group_link.task_detail_id
			join dsp_task ON dsp_task.id = dsp_task_detail.task_id
			join dsp_vehicle ON dsp_vehicle.id = dsp_task.vehicle_id
			join dsp_vehicle_number ON dsp_vehicle_number.id = dsp_vehicle.number_id

			where start_date between _from and _to and dsp_vehicle.id != _vehicle_id and start_date > x.start_date
		)
	 
	 );

end;
$$;

alter function update_route_from_tasks(uuid, uuid, date, date) owner to sa;

