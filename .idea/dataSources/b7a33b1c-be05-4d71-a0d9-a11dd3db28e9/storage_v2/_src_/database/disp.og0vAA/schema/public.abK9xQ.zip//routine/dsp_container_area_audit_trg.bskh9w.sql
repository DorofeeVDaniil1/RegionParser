create function dsp_container_area_audit_trg() returns trigger
    language plpgsql
as
$$
declare
    entity_name   constant varchar      = 'dsp_ContainerArea';
    entity_title  constant varchar      = 'КП';
    entity_gender constant audit.gender = 'F';
begin
    if not audit.is_audit_enabled() then
        return coalesce(NEW, OLD);
    end if;

    if NEW.id is distinct from OLD.id then
        if NEW.id is not null then
            call audit.write_instance_audit(entity_name, NEW.id,
                                            'CREATE', entity_title, entity_gender,
                                            db_op_type => TG_OP,
                                            db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.id'),
                                            old_value => cast(OLD.id as varchar),
                                            new_value => cast(NEW.id as varchar));
        end if;
        if OLD.id is not null then
            call audit.write_instance_audit(entity_name, OLD.id,
                                            'DELETE', entity_title, entity_gender,
                                            db_op_type => TG_OP,
                                            db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.id'),
                                            old_value => cast(OLD.id as varchar),
                                            new_value => cast(NEW.id as varchar));
        end if;
    end if;
    if NEW.id is not null then
        if (NEW.delete_ts is not null) is distinct from (OLD.delete_ts is not null) then
            call audit.write_instance_audit(entity_name, NEW.id,
                                            audit.get_soft_op_type(NEW.delete_ts is not null,
                                                                   OLD.delete_ts is not null),
                                            entity_title, entity_gender,
                                            db_op_type => TG_OP,
                                            db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.delete_ts'),
                                            old_value => cast(OLD.delete_ts as varchar),
                                            new_value => cast(NEW.delete_ts as varchar));
        end if;
        if NEW.lk_code is distinct from OLD.lk_code then
            call audit.write_attribute_audit(entity_name, NEW.id,
                                             audit.get_op_type(NEW.lk_code is null, OLD.lk_code is null),
                                             'код КП', 'M', coalesce(NEW.lk_code, OLD.lk_code),
                                             db_op_type => TG_OP,
                                             db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.lk_code'),
                                             old_value => cast(OLD.lk_code as varchar),
                                             new_value => cast(NEW.lk_code as varchar));
        end if;
        if NEW.address_id is distinct from OLD.address_id then
            call audit.write_attribute_audit(entity_name, NEW.id,
                                             audit.get_op_type(NEW.address_id is null, OLD.address_id is null),
                                             'адрес', 'M',
                                             audit.get_address_str(coalesce(NEW.address_id, OLD.address_id)),
                                             db_op_type => TG_OP,
                                             db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.address_id'),
                                             old_value => cast(OLD.address_id as varchar),
                                             new_value => cast(NEW.address_id as varchar));
        end if;
        if NEW.owner_company_id is distinct from OLD.owner_company_id then
            call audit.write_attribute_audit(entity_name, NEW.id,
                                             audit.get_op_type(NEW.owner_company_id is null,
                                                               OLD.owner_company_id is null),
                                             'контрагент', 'M',
                                             audit.get_company_str(coalesce(NEW.owner_company_id, OLD.owner_company_id)),
                                             db_op_type => TG_OP,
                                             db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.owner_company_id'),
                                             old_value => cast(OLD.owner_company_id as varchar),
                                             new_value => cast(NEW.owner_company_id as varchar));
        end if;
        if NEW.carrier_id is distinct from OLD.carrier_id then
            call audit.write_attribute_audit(entity_name, NEW.id,
                                             audit.get_op_type(NEW.carrier_id is null, OLD.carrier_id is null),
                                             'перевозчик', 'M',
                                             audit.get_company_str(coalesce(NEW.carrier_id, OLD.carrier_id)),
                                             db_op_type => TG_OP,
                                             db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.carrier_id'),
                                             old_value => cast(OLD.carrier_id as varchar),
                                             new_value => cast(NEW.carrier_id as varchar));
        end if;
        if NEW.contact_id is distinct from OLD.contact_id then
            call audit.write_attribute_audit(entity_name, NEW.id,
                                             audit.get_op_type(NEW.contact_id is null, OLD.contact_id is null),
                                             'контакт', 'M',
                                             audit.get_contact_str(coalesce(NEW.contact_id, OLD.contact_id)),
                                             db_op_type => TG_OP,
                                             db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.contact_id'),
                                             old_value => cast(OLD.contact_id as varchar),
                                             new_value => cast(NEW.contact_id as varchar));
        end if;
        if NEW.geo_data_id is distinct from OLD.geo_data_id then
            call audit.write_attribute_audit(entity_name, NEW.id,
                                             audit.get_op_type(NEW.geo_data_id is null, OLD.geo_data_id is null),
                                             'координаты', 'N',
                                             audit.get_geo_data_str(coalesce(NEW.geo_data_id, OLD.geo_data_id)),
                                             db_op_type => TG_OP,
                                             db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.geo_data_id'),
                                             old_value => cast(OLD.geo_data_id as varchar),
                                             new_value => cast(NEW.geo_data_id as varchar));
        end if;
        if NEW.tariff_calculation_method_id is distinct from OLD.tariff_calculation_method_id then
            call audit.write_attribute_audit(entity_name, NEW.id,
                                             audit.get_op_type(NEW.tariff_calculation_method_id is null,
                                                               OLD.tariff_calculation_method_id is null),
                                             'расчет тарифа', 'M',
                                             audit.get_container_area_tariff_calculation_method_str(coalesce(
                                                 NEW.tariff_calculation_method_id, OLD.tariff_calculation_method_id)),
                                             db_op_type => TG_OP,
                                             db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME,
                                                                     '.tariff_calculation_method_id'),
                                             old_value => cast(OLD.tariff_calculation_method_id as varchar),
                                             new_value => cast(NEW.tariff_calculation_method_id as varchar));
        end if;
        if NEW.type_id is distinct from OLD.type_id then
            call audit.write_attribute_audit(entity_name, NEW.id,
                                             audit.get_op_type(NEW.type_id is null, OLD.type_id is null),
                                             'тип КП', 'M',
                                             audit.get_container_area_type_str(coalesce(NEW.type_id, OLD.type_id)),
                                             db_op_type => TG_OP,
                                             db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.type_id'),
                                             old_value => cast(OLD.type_id as varchar),
                                             new_value => cast(NEW.type_id as varchar));
        end if;
        if NEW.vehicle_size_id is distinct from OLD.vehicle_size_id then
            call audit.write_attribute_audit(entity_name, NEW.id,
                                             audit.get_op_type(NEW.vehicle_size_id is null,
                                                               OLD.vehicle_size_id is null),
                                             'габарит ТС', 'M',
                                             audit.get_vehicle_size_str(coalesce(NEW.vehicle_size_id, OLD.vehicle_size_id)),
                                             db_op_type => TG_OP,
                                             db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.vehicle_size_id'),
                                             old_value => cast(OLD.vehicle_size_id as varchar),
                                             new_value => cast(NEW.vehicle_size_id as varchar));
        end if;
        if NEW.container_area_category_id is distinct from OLD.container_area_category_id then
            call audit.write_attribute_audit(entity_name, NEW.id,
                                             audit.get_op_type(NEW.container_area_category_id is null,
                                                               OLD.container_area_category_id is null),
                                             'категория КП', 'F', audit.get_container_area_category_str(coalesce(
                    NEW.container_area_category_id, OLD.container_area_category_id)),
                                             db_op_type => TG_OP,
                                             db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME,
                                                                     '.container_area_category_id'),
                                             old_value => cast(OLD.container_area_category_id as varchar),
                                             new_value => cast(NEW.container_area_category_id as varchar));
        end if;
        if NEW.comment_for_driver is distinct from OLD.comment_for_driver then
            call audit.write_attribute_audit(entity_name, NEW.id,
                                             audit.get_op_type(NEW.comment_for_driver is null,
                                                               OLD.comment_for_driver is null),
                                             'комментарий для водителя', 'M',
                                             coalesce(NEW.comment_for_driver, OLD.comment_for_driver),
                                             db_op_type => TG_OP,
                                             db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.comment_for_driver'),
                                             old_value => cast(OLD.comment_for_driver as varchar),
                                             new_value => cast(NEW.comment_for_driver as varchar));
        end if;
        if NEW.note is distinct from OLD.note then
            call audit.write_attribute_audit(entity_name, NEW.id,
                                             audit.get_op_type(NEW.note is null, OLD.note is null),
                                             'примечание', 'N', coalesce(NEW.note, OLD.note),
                                             db_op_type => TG_OP,
                                             db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.note'),
                                             old_value => cast(OLD.note as varchar),
                                             new_value => cast(NEW.note as varchar));
        end if;
        if NEW.is_packet is distinct from OLD.is_packet then
            call audit.write_attribute_audit(entity_name, NEW.id,
                                             audit.get_op_type(NEW.is_packet is null, OLD.is_packet is null),
                                             'возможен помешочный сбор', 'N',
                                             audit.get_boolean_str(coalesce(NEW.is_packet, OLD.is_packet)),
                                             db_op_type => TG_OP,
                                             db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.is_packet'),
                                             old_value => cast(OLD.is_packet as varchar),
                                             new_value => cast(NEW.is_packet as varchar));
        end if;
        if NEW.is_verified is distinct from OLD.is_verified then
            call audit.write_attribute_audit(entity_name, NEW.id,
                                             audit.get_op_type(NEW.is_verified is null, OLD.is_verified is null),
                                             'КП верифицирована', 'N',
                                             audit.get_boolean_str(coalesce(NEW.is_verified, OLD.is_verified)),
                                             db_op_type => TG_OP,
                                             db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.is_verified'),
                                             old_value => cast(OLD.is_verified as varchar),
                                             new_value => cast(NEW.is_verified as varchar));
        end if;
        if NEW.is_kgo is distinct from OLD.is_kgo then
            call audit.write_attribute_audit(entity_name, NEW.id,
                                             audit.get_op_type(NEW.is_kgo is null, OLD.is_kgo is null),
                                             'площадка под КГО', 'N',
                                             audit.get_boolean_str(coalesce(NEW.is_kgo, OLD.is_kgo)),
                                             db_op_type => TG_OP,
                                             db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.is_kgo'),
                                             old_value => cast(OLD.is_kgo as varchar),
                                             new_value => cast(NEW.is_kgo as varchar));
        end if;
        if NEW.is_removal_in_only_working_days is distinct from OLD.is_removal_in_only_working_days then
            call audit.write_attribute_audit(entity_name, NEW.id,
                                             audit.get_op_type(NEW.is_removal_in_only_working_days is null,
                                                               OLD.is_removal_in_only_working_days is null),
                                             'вывоз только по будням', 'N',
                                             audit.get_boolean_str(coalesce(NEW.is_removal_in_only_working_days,
                                                                            OLD.is_removal_in_only_working_days)),
                                             db_op_type => TG_OP,
                                             db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME,
                                                                     '.is_removal_in_only_working_days'),
                                             old_value => cast(OLD.is_removal_in_only_working_days as varchar),
                                             new_value => cast(NEW.is_removal_in_only_working_days as varchar));
        end if;
        if NEW.photo_forbidden is distinct from OLD.photo_forbidden then
            call audit.write_attribute_audit(entity_name, NEW.id,
                                             audit.get_op_type(NEW.photo_forbidden is null,
                                                               OLD.photo_forbidden is null),
                                             'запрет фото', 'N',
                                             audit.get_boolean_str(coalesce(NEW.photo_forbidden, OLD.photo_forbidden)),
                                             db_op_type => TG_OP,
                                             db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.photo_forbidden'),
                                             old_value => cast(OLD.photo_forbidden as varchar),
                                             new_value => cast(NEW.photo_forbidden as varchar));
        end if;
        if NEW.secured_territory is distinct from OLD.secured_territory then
            call audit.write_attribute_audit(entity_name, NEW.id,
                                             audit.get_op_type(NEW.secured_territory is null,
                                                               OLD.secured_territory is null),
                                             'режимный объект', 'N',
                                             audit.get_boolean_str(coalesce(NEW.secured_territory, OLD.secured_territory)),
                                             db_op_type => TG_OP,
                                             db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.secured_territory'),
                                             old_value => cast(OLD.secured_territory as varchar),
                                             new_value => cast(NEW.secured_territory as varchar));
        end if;
        if NEW.availability_schedule_id is distinct from OLD.availability_schedule_id then
            call audit.write_attribute_audit(entity_name, NEW.id,
                                             audit.get_op_type(NEW.availability_schedule_id is null,
                                                               OLD.availability_schedule_id is null),
                                             'доступ по дням', 'M',
                                             audit.get_removal_schedule_str(coalesce(NEW.availability_schedule_id, OLD.availability_schedule_id)),
                                             db_op_type => TG_OP,
                                             db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME,
                                                                     '.availability_schedule_id'),
                                             old_value => cast(OLD.availability_schedule_id as varchar),
                                             new_value => cast(NEW.availability_schedule_id as varchar));
        end if;
        if NEW.is_archived is distinct from OLD.is_archived then
            call audit.write_attribute_audit(entity_name, NEW.id,
                                             audit.get_op_type(NEW.is_archived is null, OLD.is_archived is null),
                                             'КП перенесена в архив', 'N',
                                             audit.get_boolean_str(coalesce(NEW.is_archived, OLD.is_archived)),
                                             db_op_type => TG_OP,
                                             db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.is_archived'),
                                             old_value => cast(OLD.is_archived as varchar),
                                             new_value => cast(NEW.is_archived as varchar));
        end if;
        if NEW.lot_id is distinct from OLD.lot_id then
            call audit.write_attribute_audit(entity_name, NEW.id,
                                             audit.get_op_type(NEW.lot_id is null, OLD.lot_id is null),
                                             'лот', 'M',audit.get_lot_name(coalesce(NEW.lot_id,OLD.lot_id)),
                                             db_op_type => TG_OP,
                                             db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.lot_id'),
                                             old_value => cast(OLD.lot_id as varchar),
                                             new_value => cast(NEW.lot_id as varchar));
        end if;
    end if;

    return coalesce(NEW, OLD);
end;
$$;

alter function dsp_container_area_audit_trg() owner to sa;

