create function find_vehicle(num character varying)
    returns TABLE(id uuid, created timestamp without time zone, assembly character varying, n1 character varying, n2 character varying, n3 character varying, n4 character varying, container character varying, compression double precision, volume double precision, vol_compressed double precision, load_type character varying, model character varying, carrying double precision, fuel_tank double precision, garbage_max double precision, garbage_min double precision, fuel_consumption double precision, brand character varying)
    language plpgsql
as
$$
begin 
return query 

	select

	dsp_vehicle.id, 
	dsp_vehicle.create_ts as created,
	
	dsp_vehicle_assembly.name as assembly,
	
	dsp_vehicle_number.full_ as n1, 
	dsp_vehicle_number.full_without_spaces as n2, 
	dsp_vehicle_number.without_region as n3, 
	dsp_vehicle_number.without_spaces as n4,
	
	dsp_vehicle_garbage_container.name as container, 
	dsp_vehicle_garbage_container.compression_coefficient as compression, 
	dsp_vehicle_garbage_container.volume as volume, 
	dsp_vehicle_garbage_container.volume_compressed as vol_compressed,
	
	dsp_garbage_load_type.name as load_type,
	
	dsp_vehicle_model.name model, 
	dsp_vehicle_model.carrying as carrying, 
	dsp_vehicle_model.fuel_tank_volume as fuel_tank, 
	dsp_vehicle_model.garbage_volume_max as garbage_max, 
	dsp_vehicle_model.garbage_volume_min as garbage_min, 
	dsp_vehicle_model.standard_fuel_consumption as fuel_consumption,
	
	dsp_vehicle_brand.name as brand

from dsp_vehicle 

join dsp_vehicle_assembly on dsp_vehicle_assembly.id = dsp_vehicle.assembly_id
join dsp_vehicle_number on  dsp_vehicle_number.id = dsp_vehicle.number_id
join dsp_vehicle_garbage_container on dsp_vehicle_garbage_container.id = dsp_vehicle_assembly.container_id
join dsp_garbage_load_type on dsp_garbage_load_type.id = dsp_vehicle_garbage_container.load_type_id
join dsp_vehicle_model on dsp_vehicle_model.id = dsp_vehicle_assembly.model_id
join dsp_vehicle_brand on dsp_vehicle_brand.id = dsp_vehicle_model.brand_id

where dsp_vehicle_number.full_ like '%' || num || '%';
end;
$$;

alter function find_vehicle(varchar) owner to sa;

