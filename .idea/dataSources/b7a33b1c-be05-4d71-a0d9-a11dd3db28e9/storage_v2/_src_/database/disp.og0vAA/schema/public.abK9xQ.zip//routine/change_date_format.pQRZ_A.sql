create function change_date_format(input_date text) returns timestamp without time zone
    language plpgsql
as
$$
DECLARE
    formatted_date TIMESTAMP;
BEGIN
    -- Преобразуем строку в тип TIMESTAMP с указанием исходного формата
    formatted_date := TO_TIMESTAMP(input_date, 'DD.MM.YYYY HH24:MI:SS.US');

    -- Преобразуем TIMESTAMP в строку в нужном формате
    RETURN TO_CHAR(formatted_date, 'YYYY-MM-DD HH24:MI:SS.US');
END;
$$;

alter function change_date_format(text) owner to sa;

