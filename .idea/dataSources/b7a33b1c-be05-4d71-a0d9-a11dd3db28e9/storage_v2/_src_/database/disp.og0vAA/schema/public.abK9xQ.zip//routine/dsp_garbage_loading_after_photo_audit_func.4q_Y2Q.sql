create function dsp_garbage_loading_after_photo_audit_func() returns trigger
    language plpgsql
as
$$
declare
    entity_name constant varchar = 'dsp_GarbageLoadingUnloading';
    attribute_title constant varchar = 'фото после загрузки';
    attribute_gender constant audit.gender = 'N';
    db_field_name constant varchar = '.file_descriptor_id';
    loading_record dsp_garbage_loading;
begin
    if not audit.is_audit_enabled() then
        return coalesce(NEW, OLD);
    end if;

    select * into loading_record from dsp_garbage_loading
    where id = coalesce(NEW.garbage_loading_id, OLD.garbage_loading_id);

    if TG_OP IN ('CREATE', 'INSERT', 'UPDATE') then
        call audit.write_attribute_audit(
            entity_name,
            loading_record.task_id,
            cast('INSERT' as audit.op_type),
            attribute_title,
            attribute_gender,
            value_str => null,
            text_added_to_event_descr => audit.get_garbage_unloading_update_audit_description_ending(loading_record.create_ts, loading_record.point_id),
            db_op_type => TG_OP,
            db_field_name => cast(array[
                concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.garbage_loading_id'),
                concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.file_descriptor_id')
                ] as varchar),
            old_value =>  cast(array[
                cast(OLD.garbage_loading_id as varchar),
                cast(OLD.file_descriptor_id as varchar)
                ] as varchar),
            new_value => cast(array[
                cast(NEW.garbage_loading_id as varchar),
                cast(NEW.file_descriptor_id as varchar)
                ] as varchar)
            );
    end if;

    if TG_OP = 'DELETE' then
        call audit.write_attribute_audit(
            entity_name,
            loading_record.task_id,
            cast('DELETE'  as audit.op_type),
            attribute_title,
            attribute_gender,
            value_str => null,
            text_added_to_event_descr => audit.get_garbage_unloading_update_audit_description_ending(loading_record.create_ts, loading_record.point_id),
            db_op_type => TG_OP,
            db_field_name => cast(array[
                concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.garbage_loading_id'),
                concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.file_descriptor_id')
                ] as varchar),
            old_value =>  cast(array[
                cast(OLD.garbage_loading_id as varchar),
                cast(OLD.file_descriptor_id as varchar)
                ] as varchar),
            new_value => cast(array[
                cast(NEW.garbage_loading_id as varchar),
                cast(NEW.file_descriptor_id as varchar)
                ] as varchar)
            );
    end if;

    return coalesce(NEW, OLD);
end;
$$;

alter function dsp_garbage_loading_after_photo_audit_func() owner to sa;

