create function new_region(_name character varying, _geo_data_id uuid, on_level integer) returns uuid
    language plpgsql
as
$$
declare

    _u uuid = uuid_generate_v4();

begin

    insert into
        dsp_region
    (
        id,
        create_ts,
        level_,
        name
    )
    values
        (
            _u,
            now()::timestamp,
            on_level,
            _name
        );

    insert into dsp_region_geo_data_link (geo_data_id, region_id)
    values (_geo_data_id, _u);

    return _u;

end;
$$;

alter function new_region(varchar, uuid, integer) owner to sa;

