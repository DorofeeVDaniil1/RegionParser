create function new_schedule(schedule character varying) returns uuid
    language plpgsql
as
$$
DECLARE
    _u uuid := uuid_generate_v4();
BEGIN
    INSERT INTO dsp_removal_schedule (
        id,
        create_ts, created_by,
        delete_ts, deleted_by,
        update_ts, updated_by,
        name
    )
    VALUES (
               _u,
               NOW(), 'system',
               NULL, NULL,
               NULL, NULL,
               substring(schedule from 1 for 255)
           );

    RETURN _u;
END;
$$;

alter function new_schedule(varchar) owner to sa;

