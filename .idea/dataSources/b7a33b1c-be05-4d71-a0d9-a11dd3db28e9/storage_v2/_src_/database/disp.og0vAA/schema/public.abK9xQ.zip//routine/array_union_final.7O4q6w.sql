create function array_union_final(s anyarray) returns anyarray
    immutable
    leakproof
    parallel safe
    language sql
as
$$
SELECT array_agg(i ORDER BY i)
FROM (SELECT DISTINCT UNNEST(x) AS i
      FROM (VALUES (s)) AS v(x)) AS w
WHERE i IS NOT NULL;
$$;

alter function array_union_final(anyarray) owner to sa;

