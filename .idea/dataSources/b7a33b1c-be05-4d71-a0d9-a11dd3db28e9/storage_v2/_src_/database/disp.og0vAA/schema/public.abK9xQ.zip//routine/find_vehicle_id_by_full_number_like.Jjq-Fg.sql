create function find_vehicle_id_by_full_number_like(_full_like character varying) returns uuid
    language plpgsql
as
$$
begin 
	
 	 return (
	 	select dsp_vehicle.id
		from dsp_vehicle
		join dsp_vehicle_number ON dsp_vehicle_number.id = dsp_vehicle.number_id
		where full_ like '%'||_full_like||'%'
	 );

end;
$$;

alter function find_vehicle_id_by_full_number_like(varchar) owner to sa;

