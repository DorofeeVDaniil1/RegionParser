create function random_hex_color() returns character varying
    language plpgsql
as
$$
begin

    return(
        SELECT concat('#',lpad(to_hex(round(random() * 10000000)::int4),6,'0'))
    );

end;
$$;

alter function random_hex_color() owner to sa;

