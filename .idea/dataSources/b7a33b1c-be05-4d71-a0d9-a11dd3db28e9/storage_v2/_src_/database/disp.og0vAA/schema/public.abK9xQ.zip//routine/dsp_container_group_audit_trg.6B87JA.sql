create function dsp_container_group_audit_trg() returns trigger
    language plpgsql
as
$$
declare
    entity_name constant varchar = 'dsp_ContainerGroup';
    entity_title constant varchar = 'КГ';
    entity_gender constant audit.gender = 'F';

    ca_entity_name constant varchar = 'dsp_ContainerArea';
    ca_entity_title constant varchar = 'КП';
    ca_entity_gender constant audit.gender = 'F';
begin
    if not audit.is_audit_enabled() then
        return coalesce(NEW, OLD);
    end if;

    if NEW.id is distinct from OLD.id then
        if OLD.id is not null then
            call audit.write_instance_audit(entity_name, OLD.id,
                'DELETE', entity_title, entity_gender,
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.id'),
                old_value => cast(OLD.id as varchar),
                new_value => cast(NEW.id as varchar));

            if OLD.container_area_id is not null then
                call audit.write_instance_audit(ca_entity_name, OLD.container_area_id,
                    'DELETE', entity_title, entity_gender, audit.get_container_group_short_str(OLD.id),
                  db_op_type => TG_OP, 
                  db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.id'),
                  old_value => cast(OLD.id as varchar),
                  new_value => cast(NEW.id as varchar));
            end if;
        end if;
        if NEW.id is not null then
            call audit.write_instance_audit(entity_name, NEW.id,
                'CREATE', entity_title, entity_gender,
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.id'),
                old_value => cast(OLD.id as varchar),
                new_value => cast(NEW.id as varchar));

            if NEW.container_area_id is not null then
                call audit.write_instance_audit(ca_entity_name, NEW.container_area_id,
                    'CREATE', entity_title, entity_gender, audit.get_container_group_short_str(NEW.id),
                    db_op_type => TG_OP, 
                    db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.id'),
                    old_value => cast(OLD.id as varchar),
                    new_value => cast(NEW.id as varchar));
            end if;
        end if;
    end if;
    if NEW.id is not null then
        if (NEW.delete_ts is not null) is distinct from (OLD.delete_ts is not null) then
            call audit.write_instance_audit(entity_name, NEW.id,
                audit.get_soft_op_type(NEW.delete_ts is not null, OLD.delete_ts is not null),
                entity_title, entity_gender,
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.delete_ts'),
                old_value => cast(OLD.delete_ts as varchar),
                new_value => cast(NEW.delete_ts as varchar));

            if NEW.container_area_id is not null then
                call audit.write_instance_audit(ca_entity_name, NEW.container_area_id,
                    audit.get_soft_op_type(NEW.delete_ts is not null, OLD.delete_ts is not null),
                    entity_title, entity_gender, audit.get_container_group_short_str(NEW.id),
                    db_op_type => TG_OP, 
                    db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.delete-ts'),
                    old_value => cast(OLD.delete_ts as varchar),
                    new_value => cast(NEW.delete_ts as varchar));
            end if;
        end if;
        if NEW.container_area_id is distinct from OLD.container_area_id then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.container_area_id is null, OLD.container_area_id is null),
                'КП', 'F', audit.get_container_area_str(coalesce(NEW.container_area_id, OLD.container_area_id)),
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.container_area_id'),
                old_value => cast(OLD.container_area_id as varchar),
                new_value => cast(NEW.container_area_id as varchar));
        end if;                
        if NEW.container_type_id is distinct from OLD.container_type_id then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.container_type_id is null, OLD.container_type_id is null),
                'тип контейнера', 'M', audit.get_container_type_str(coalesce(NEW.container_type_id, OLD.container_type_id)),
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.container_type_id'),
                old_value => cast(OLD.container_type_id as varchar),
                new_value => cast(NEW.container_type_id as varchar));
        end if;                
        if NEW.amount is distinct from OLD.amount then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.amount is null, OLD.amount is null),
                'кол-во контейнеров', 'N', audit.get_integer_str(coalesce(NEW.amount, OLD.amount)),
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.amount'),
                old_value => cast(OLD.amount as varchar),
                new_value => cast(NEW.amount as varchar));
        end if;                
        if NEW.carrier_id is distinct from OLD.carrier_id then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.carrier_id is null, OLD.carrier_id is null),
                'перевозчик', 'M', audit.get_company_str(coalesce(NEW.carrier_id, OLD.carrier_id)),
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.carrier_id'),
                old_value => cast(OLD.carrier_id as varchar),
                new_value => cast(NEW.carrier_id as varchar));
        end if;                
        if NEW.schedule_id is distinct from OLD.schedule_id then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.schedule_id is null, OLD.schedule_id is null),
                'график вывоза', 'M', audit.get_removal_schedule_str(coalesce(NEW.schedule_id, OLD.schedule_id)),
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.schedule_id'),
                old_value => cast(OLD.schedule_id as varchar),
                new_value => cast(NEW.schedule_id as varchar));
        end if;
        if NEW.trips_per_day is distinct from OLD.trips_per_day then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.trips_per_day is null, OLD.trips_per_day is null),
                'рейсов в день', 'N', audit.get_integer_str(coalesce(NEW.trips_per_day, OLD.trips_per_day)),
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.trips_per_day'),
                old_value => cast(OLD.trips_per_day as varchar),
                new_value => cast(NEW.trips_per_day as varchar));
        end if;                

        --TODO: Extend audit API for many-to-one linked entities and then review the code below:
        if NEW.container_area_id is not null then
            if NEW.container_type_id is distinct from OLD.container_type_id then
                call audit.write_audit(
                    ca_entity_name,
                    NEW.container_area_id,
                    concat_ws(' ',
                        concat('<strong>', audit.capitalize('тип контейнера'), '</strong>,'),
                        audit.get_op_str(audit.get_op_type(NEW.container_type_id is null, OLD.container_type_id is null), 'M'),
                        concat('"', audit.get_container_type_str(coalesce(NEW.container_type_id, OLD.container_type_id)), '"'),
                        --TODO: Test if NEW.id is valid for get_container_group_short_str within trigger when state is intermediate
                        'для', entity_title, audit.get_container_group_short_str(NEW.id)
                    ),
                    --TODO: Get rid of copy-paste (get_op_type function call below adopted from couple rows above):
                    op_type => cast(audit.get_op_type(NEW.container_type_id is null, OLD.container_type_id is null) as varchar),
                    db_op_type => TG_OP,
                    db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.container_type_id'),
                    old_value => cast(OLD.container_type_id as varchar),
                    new_value => cast(NEW.container_type_id as varchar)
                );
            end if;                
            if NEW.amount is distinct from OLD.amount then
                call audit.write_audit(
                    ca_entity_name, 
                    NEW.container_area_id,
                    concat_ws(' ',
                        concat('<strong>', audit.capitalize('кол-во контейнеров'), '</strong>,'),
                        audit.get_op_str(audit.get_op_type(NEW.amount is null, OLD.amount is null), 'N'),
                        concat('"', audit.get_integer_str(coalesce(NEW.amount, OLD.amount)), '"'),
                        --TODO: Test if NEW.id is valid for get_container_group_short_str within trigger when state is intermediate
                        'для', entity_title, audit.get_container_group_short_str(NEW.id)
                    ),
                    --TODO: Get rid of copy-paste (get_op_type function call below adopted from couple rows above):
                    op_type => cast(audit.get_op_type(NEW.amount is null, OLD.amount is null) as varchar),
                    db_op_type => TG_OP,
                    db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.amount'),
                    old_value => cast(OLD.amount as varchar),
                    new_value => cast(NEW.amount as varchar)
                );
            end if;                
            if NEW.carrier_id is distinct from OLD.carrier_id then
                call audit.write_audit(
                    ca_entity_name,
                    NEW.container_area_id,
                    concat_ws(' ',
                        concat('<strong>', audit.capitalize('перевозчик'), '</strong>,'),
                        audit.get_op_str(audit.get_op_type(NEW.carrier_id is null, OLD.carrier_id is null), 'M'),
                        concat('"', audit.get_company_str(coalesce(NEW.carrier_id, OLD.carrier_id)), '"'),
                        --TODO: Test if NEW.id is valid for get_container_group_short_str within trigger when state is intermediate
                        'для', entity_title, audit.get_container_group_short_str(NEW.id)
                    ),
                    --TODO: Get rid of copy-paste (get_op_type function call below adopted from couple rows above):
                    op_type => cast(audit.get_op_type(NEW.carrier_id is null, OLD.carrier_id is null) as varchar),
                    db_op_type => TG_OP,
                    db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.carrier_id'),
                    old_value => cast(OLD.carrier_id as varchar),
                    new_value => cast(NEW.carrier_id as varchar)
                );
            end if;                
            if NEW.schedule_id is distinct from OLD.schedule_id then
                call audit.write_audit(
                    ca_entity_name,
                    NEW.container_area_id,
                    concat_ws(' ',
                        concat('<strong>', audit.capitalize('график вывоза'), '</strong>,'),
                        audit.get_op_str(audit.get_op_type(NEW.schedule_id is null, OLD.schedule_id is null), 'M'),
                        concat('"', audit.get_removal_schedule_str(coalesce(NEW.schedule_id, OLD.schedule_id)), '"'),
                        --TODO: Test if NEW.id is valid for get_container_group_short_str within trigger when state is intermediate
                        'для', entity_title, audit.get_container_group_short_str(NEW.id)
                    ),
                    --TODO: Get rid of copy-paste (get_op_type function call below adopted from couple rows above):
                    op_type => cast(audit.get_op_type(NEW.schedule_id is null, OLD.schedule_id is null) as varchar),
                    db_op_type => TG_OP,
                    db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.schedule_id'),
                    old_value => cast(OLD.schedule_id as varchar),
                    new_value => cast(NEW.schedule_id as varchar)
                );
            end if;
            if NEW.trips_per_day is distinct from OLD.trips_per_day then
                call audit.write_audit(
                    ca_entity_name,
                    NEW.container_area_id,
                    concat_ws(' ',
                        concat('<strong>', audit.capitalize('рейсов в день'), '</strong>,'),
                        audit.get_op_str(audit.get_op_type(NEW.trips_per_day is null, OLD.trips_per_day is null), 'N'),
                        concat('"', audit.get_integer_str(coalesce(NEW.trips_per_day, OLD.trips_per_day)), '"'),
                        --TODO: Test if NEW.id is valid for get_container_group_short_str within trigger when state is intermediate
                        'для', entity_title, audit.get_container_group_short_str(NEW.id)
                    ),
                    --TODO: Get rid of copy-paste (get_op_type function call below adopted from couple rows above):
                    op_type => cast(audit.get_op_type(NEW.trips_per_day is null, OLD.trips_per_day is null) as varchar),
                    db_op_type => TG_OP,
                    db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.trips_per_day'),
                    old_value => cast(OLD.trips_per_day as varchar),
                    new_value => cast(NEW.trips_per_day as varchar)
                );
            end if;                
        end if;                
    end if;

    return coalesce(NEW, OLD);
end;
$$;

alter function dsp_container_group_audit_trg() owner to sa;

