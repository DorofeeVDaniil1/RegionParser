create function get_or_create_contact_id(name character varying) returns uuid
    language plpgsql
as
$$
BEGIN
    RETURN (
        SELECT COALESCE (
                       (SELECT id FROM dsp_contact WHERE view_ = name),
                       new_contact(name)
               )
    );
END;
$$;

alter function get_or_create_contact_id(varchar) owner to sa;

