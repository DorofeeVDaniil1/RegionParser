create function dsp_inventorization_smartsearch_trg() returns trigger
    language plpgsql
as
$$
begin
    if(NEW.id is distinct from OLD.id) then
        insert into dsp_smartsearch_queue(context_name, key)
        select distinct
            'dsp_Verification',
            cast(d.verification_id as varchar)
        from dsp_inventorization_detail as d
        where d.inventorization_id in (NEW.id, OLD.id);
    end if;

    return null;
end;
$$;

alter function dsp_inventorization_smartsearch_trg() owner to sa;

