create function pg_stat_collector() returns void
    language plpgsql
as
$$
begin
    -- Создать таблицу для хранения слепков статистки
    CREATE TABLE if not exists summary_pg_stat_statements (
                                                              date timestamp,
                                                              user_id varchar(255),
                                                              db_id varchar(255),
                                                              query_id varchar(255),
                                                              query text,
                                                              calls bigint,
                                                              total_time float4,
                                                              min_time float4,
                                                              max_time float4,
                                                              mean_time float4,
                                                              stdev_time float4,
                                                              rows bigint
    );

-- Снять слепок текущей статистики
    insert into summary_pg_stat_statements (date, user_id, db_id, query_id, query, calls, total_time, min_time, max_time, mean_time, stdev_time, rows)
    select current_timestamp, userid, dbid, queryid, query, calls, total_time, min_time, max_time, mean_time, stddev_time, rows
    from pg_stat_statements s;

-- Очистить слепки старее недели
    delete from summary_pg_stat_statements
    where date < NOW() - INTERVAL '1 week';

-- Очистить статистику запросов
    perform pg_stat_statements_reset();
end;
$$;

alter function pg_stat_collector() owner to sa;

