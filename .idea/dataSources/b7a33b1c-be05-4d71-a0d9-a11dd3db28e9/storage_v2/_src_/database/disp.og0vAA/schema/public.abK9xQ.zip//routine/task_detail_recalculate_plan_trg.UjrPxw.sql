create function task_detail_recalculate_plan_trg() returns trigger
    language plpgsql
as
$$
declare
    instance_ids cursor (group_id uuid) for
        select td.id as td_id
        from dsp_task_detail td
                 join dsp_task t on td.task_id = t.id
                 join dsp_task_detail_container_group_link cgl on td.id = cgl.task_detail_id
        where t.start_date > now()
          and cgl.container_group_id = group_id;
begin
    if (tg_op = 'UPDATE' and
        (old.amount is distinct from new.amount or old.container_type_id is distinct from new.container_type_id)) then
        for r in instance_ids(new.id)
            loop
                with cgs as (select sum(cg.amount) as amount_plan, sum(ct.volume * cg.amount) as volume_plan
                             from dsp_task_detail td
                                      join dsp_task_detail_container_group_link cgl on td.id = cgl.task_detail_id
                                      join dsp_container_group cg on cgl.container_group_id = cg.id
                                      join dsp_container_type ct on cg.container_type_id = ct.id
                             where td.id = r.td_id)
                update dsp_task_detail td
                set update_ts              = now(),
                    updated_by             = 'task_detail_recalculate_plan_trg',
                    containers_amount_plan = cgs.amount_plan,
                    containers_volume_plan = cgs.volume_plan
                from cgs
                where td.id = r.td_id;

                update dsp_task_detail_detailing_plan
                set update_ts         = now(),
                    updated_by        = 'task_detail_recalculate_plan_trg',
                    amount            = new.amount,
                    container_type_id = new.container_type_id,
                    volume            = (select ct.volume
                                         from dsp_container_type ct
                                         where ct.id = new.container_type_id)
                where container_group_id = new.id
                  and task_detail_id = r.td_id;
            end loop;
    end if;
    RETURN NEW;
end;
$$;

alter function task_detail_recalculate_plan_trg() owner to sa;

