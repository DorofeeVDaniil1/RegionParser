create function new_contact(name character varying) returns uuid
    language plpgsql
as
$$
DECLARE
    _u uuid = uuid_generate_v4();
BEGIN
    INSERT INTO dsp_contact (
        id,
        create_ts, created_by,
        delete_ts, deleted_by,
        update_ts, updated_by,
        view_

    )
    VALUES (
               _u,
               NOW(), 'system',
               NULL, NULL,
               NULL, NULL,
               name
           );
    RETURN _u;
END;
$$;

alter function new_contact(varchar) owner to sa;

