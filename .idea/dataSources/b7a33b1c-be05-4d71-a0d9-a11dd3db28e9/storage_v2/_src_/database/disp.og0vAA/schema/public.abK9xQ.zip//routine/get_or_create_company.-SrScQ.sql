create function get_or_create_company(title character varying) returns uuid
    language plpgsql
as
$$
begin
    return (
        select
            coalesce (
                    (select id from dsp_company where full_name = title),
                    new_company(title)
                )
    );
end;
$$;

alter function get_or_create_company(varchar) owner to sa;

