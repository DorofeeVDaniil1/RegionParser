create function new_company(title character varying) returns uuid
    language plpgsql
as
$$
declare

    _u uuid = uuid_generate_v4();

begin

    insert into dsp_company
    (id, full_name, short_name, is_carrier, is_archived)
    values
        (
            _u,
            title,
            title,
            false,
            false
        );
    return _u;

end;
$$;

alter function new_company(varchar) owner to sa;

