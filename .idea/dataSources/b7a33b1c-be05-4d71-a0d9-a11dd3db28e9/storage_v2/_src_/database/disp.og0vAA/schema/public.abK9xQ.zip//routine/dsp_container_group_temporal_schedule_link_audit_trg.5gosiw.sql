create function dsp_container_group_temporal_schedule_link_audit_trg() returns trigger
    language plpgsql
as
$$
declare
    entity_name   constant  varchar      = 'dsp_ContainerArea';
    entity_title  constant  varchar      = 'Врем. график вывоза';
    entity_gender constant  audit.gender = 'M';
    new_container_area_id   uuid         = (select container_area_id
                                            from dsp_container_group
                                            where id = NEW.group_id);
    old_w_container_area_id uuid         = (select container_area_id
                                            from dsp_container_group
                                            where id = OLD.group_id);
    audit_str               varchar;

begin
    if TG_OP = 'INSERT' then
        if NEW.temporal_schedule_id is not null then
            audit_str = audit.get_temporal_removal_schedule_str(NEW.temporal_schedule_id);
            call audit.write_instance_audit(entity_name, new_container_area_id, 'INSERT',entity_title, entity_gender,
                                            audit_str,
                                            db_op_type => TG_OP,
                                            db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.temporal_schedule_id'),
                                            old_value => cast(OLD.temporal_schedule_id as varchar),
                                            new_value => cast(NEW.temporal_schedule_id as varchar));
        end if;
    end if;

    if TG_OP = 'DELETE' then
        if OLD.temporal_schedule_id is not null then
            audit_str = audit.get_temporal_removal_schedule_str(OLD.temporal_schedule_id);
            call audit.write_instance_audit(entity_name, old_w_container_area_id, 'DELETE',entity_title, entity_gender,
                                            audit_str,
                                            db_op_type => TG_OP,
                                            db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.temporal_schedule_id'),
                                            old_value => cast(OLD.temporal_schedule_id as varchar),
                                            new_value => cast(NEW.temporal_schedule_id as varchar));
            end if;
    end if;

    return null;
end;
$$;

alter function dsp_container_group_temporal_schedule_link_audit_trg() owner to sa;

