create function dsp_task_detail_container_group_link_smartsearch_trg() returns trigger
    language plpgsql
as
$$
begin
    if(NEW.container_group_id is distinct from OLD.container_group_id or
        NEW.task_detail_id is distinct from OLD.task_detail_id
    ) then
        -- detail and cluster cleanup
        with d as (
            delete from dsp_container_group_task
            where (container_group_id, task_detail_id) = (OLD.container_group_id, OLD.task_detail_id)
            returning container_group_id, vehicle_id
        )
        delete from dsp_container_group_vehicle
        where (container_group_id, vehicle_id) in (select * from d);

        -- detail upsert
        insert into dsp_container_group_task(
            container_group_id, task_detail_id, task_id, vehicle_id, start_date)
        select
            l.container_group_id,
            l.task_detail_id,
            td.task_id,
            t.vehicle_id,
            t.start_date
        from (values
                (NEW.container_group_id, NEW.task_detail_id)
            ) as l(container_group_id, task_detail_id)
            join dsp_task_detail as td on l.task_detail_id = td.id
            join dsp_task as t on td.task_id = t.id
        on conflict (container_group_id, task_detail_id, task_id) do
            update set vehicle_id = excluded.vehicle_id,
                start_date = excluded.start_date;

        -- cluster upsert
        insert into dsp_container_group_vehicle(
            container_group_id, vehicle_id, start_dates)
        select
            container_group_id, vehicle_id,
            string_agg(distinct to_char(start_date, 'YYYY-MM-DD'), ','
                       order by to_char(start_date, 'YYYY-MM-DD') desc) as start_dates
        from dsp_container_group_task
        where (container_group_id, vehicle_id) in (
            select container_group_id, vehicle_id
            from dsp_container_group_task
            where (container_group_id, task_detail_id) in (
                (NEW.container_group_id, NEW.task_detail_id),
                (OLD.container_group_id, OLD.task_detail_id)
            )
        )
        group by container_group_id, vehicle_id
        on conflict (container_group_id, vehicle_id) do
            update set start_dates = excluded.start_dates;

        insert into dsp_smartsearch_queue(context_name, key)
        select distinct
            'dsp_ContainerGroup(taskDetail.task.vehicle)',
            concat(
                cast(l.container_group_id as varchar), ',',
                cast(t.vehicle_id as varchar)
            )
        from (values
                (NEW.container_group_id, NEW.task_detail_id),
                (OLD.container_group_id, OLD.task_detail_id)
            ) as l(container_group_id, task_detail_id)
            join dsp_task_detail as td on l.task_detail_id = td.id
            join dsp_task as t on td.task_id = t.id;
    end if;

    return null;
end;
$$;

alter function dsp_task_detail_container_group_link_smartsearch_trg() owner to sa;

