create procedure delete_region(_id uuid)
    language plpgsql
as
$$
begin
update dsp_region 
	set parent_id = null
	where parent_id = 
	(select id from dsp_region where id = _id);

delete from dsp_inventorization_detail
	where inventorization_id in
	(
		select id from dsp_inventorization
		where region_id = 
		(
			select id from dsp_region where id = _id
		) 
	);

delete from dsp_inventorization 
	where region_id = 
	(select id from dsp_region where id = _id);

delete from dsp_task_detail_move_event 
	where task_detail_id in
	(
		select id from dsp_task_detail 
		
		where task_id in
		(
			select id from dsp_task
			where region_id = 
			(
				select id from dsp_region where id = _id
			)
		)
		or report_id in
		(
			select id from dsp_report_from_driver
				where task_detail_id in
				(
					select id from dsp_task_detail 
					where task_id in
					(
						select id from dsp_task
						where region_id = 
						(
							select id from dsp_region where id = _id
						)
					)
				)
		)
		or source_task_id in
		(
			select id from dsp_task
			where region_id = 
			(
				select id from dsp_region where id = _id
			)
		)
		
	);

delete from dsp_task_detail_container_group_link
	where task_detail_id in
	(
		select id from dsp_task_detail 
		
		where task_id in
		(
			select id from dsp_task
			where region_id = 
			(
				select id from dsp_region where id = _id
			)
		)
		or report_id in
		(
			select id from dsp_report_from_driver
				where task_detail_id in
				(
					select id from dsp_task_detail 
					where task_id in
					(
						select id from dsp_task
						where region_id = 
						(
							select id from dsp_region where id = _id
						)
					)
				)
		)
		or source_task_id in
		(
			select id from dsp_task
			where region_id = 
			(
				select id from dsp_region where id = _id
			)
		)
		
	);

update dsp_task_detail 
	set report_id = null 
	where report_id in
	(
		select id from dsp_report_from_driver
			where task_detail_id in
			(
				select id from dsp_task_detail 
				where task_id in
				(
					select id from dsp_task
					where region_id = 
					(
						select id from dsp_region where id = _id
					)
				)
			)
	);

delete from dsp_report_from_driver
	where task_detail_id in
	(
		select id from dsp_task_detail 
		where task_id in
		(
			select id from dsp_task
			where region_id = 
			(
				select id from dsp_region where id = _id
			)
		)
	);
	
delete from dsp_task_detail 
	where source_task_id in
	(
		select id from dsp_task
		where region_id = 
		(
			select id from dsp_region where id = _id
		)
	);

delete from dsp_task_detail 
	where task_id in
	(
		select id from dsp_task
		where region_id = 
		(
			select id from dsp_region where id = _id
		)
	);

delete from dsp_task 
	where region_id = 
	(select id from dsp_region where id = _id);

delete from dsp_region_vehicle_link 
	where region_id = 
	(select id from dsp_region where id = _id);

delete from dsp_region_employee_link 
	where region_id = 
	(select id from dsp_region where id = _id);

delete from dsp_region_container_area_link 
	where region_id = 
	(select id from dsp_region where id = _id);

delete from dsp_region 
	where id = 
	(select id from dsp_region where id = _id);
end;
$$;

alter procedure delete_region(uuid) owner to sa;

