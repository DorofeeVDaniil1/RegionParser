create function add_new_weights(date character varying, number character varying, place character varying, before integer, after integer) returns text
    language plpgsql
as
$$
DECLARE
    formatted_date TIMESTAMP;
    _u1 uuid;
    _u2 uuid;

BEGIN
    _u1 = uuid_generate_v4();
    _u2 = uuid_generate_v4();
    formatted_date = (select change_date_format(date));

    insert into dsp_garbage_unloading (id, create_ts, created_by,round_order,  unloading_ts, weight_after, weight_before, weight_difference, geo_data_id, place_id, task_id, point_id,is_stat_collected)
    values
        (_u1,now(),'dorofeev.d',0,formatted_date,
         after,
         before,
         before-after,
         (select geo_data_id from  dsp_garbage_unloading_place where name =place),
         (select id from dsp_garbage_unloading_place where name =place),

         (SELECT dsp_task.id
          FROM dsp_task
          WHERE vehicle_id = (
              SELECT id
              FROM dsp_vehicle
              WHERE number_id = (
                  SELECT id
                  FROM dsp_vehicle_number
                  WHERE full_without_spaces = number
              )
          )
            AND start_date <= formatted_date
          ORDER BY create_ts DESC
          limit 1),

         (select id from dsp_garbage_unloading_point where name = place),
         false
        );


    insert into dsp_task_weight_detail (id, create_ts, created_by, task_id, point_id, type, garbage_unloading_id, order_, auto_generated)
    VALUES
        (_u2 ,
         now(),
         'dorofeev.d',

         (SELECT dsp_task.id
          FROM dsp_task
          WHERE vehicle_id = (
              SELECT id
              FROM dsp_vehicle
              WHERE number_id = (
                  SELECT id
                  FROM dsp_vehicle_number
                  WHERE full_without_spaces = number
              )
          )
            AND start_date <= formatted_date
          ORDER BY create_ts DESC
          limit 1),

         (select id from dsp_garbage_unloading_point where name = place),
         'GARBAGE_UNLOADING',
         _u1,
         1000,
         true
        );

   

    RETURN _u2;

END;
$$;

alter function add_new_weights(varchar, varchar, varchar, integer, integer) owner to sa;

