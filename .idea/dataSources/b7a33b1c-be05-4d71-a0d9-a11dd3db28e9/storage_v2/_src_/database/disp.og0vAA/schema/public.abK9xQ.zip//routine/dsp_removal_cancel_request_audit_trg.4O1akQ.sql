create function dsp_removal_cancel_request_audit_trg() returns trigger
    language plpgsql
as
$$
declare
    entity_name    constant varchar      = 'dsp_RemovalCancelRequest';
    entity_title   constant varchar      = 'отмена вывоза';
    entity_gender  constant audit.gender = 'F';
    ca_entity_name constant varchar      = 'dsp_ContainerArea';
begin
    if not audit.is_audit_enabled() then
        return coalesce(NEW, OLD);
    end if;

    if TG_OP = 'INSERT' then
        if NEW.container_area_id is not null and NEW.status = 'ACCEPTED' then
            call audit.write_instance_audit(ca_entity_name, NEW.container_area_id,
                                            'INSERT', entity_title, entity_gender,
                                            NEW.number,
                                            db_op_type => TG_OP,
                                            db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.id'),
                                            old_value => cast(OLD.id as varchar),
                                            new_value => cast(NEW.id as varchar));
        end if;
    end if;

    if TG_OP = 'UPDATE' then
        if NEW.status = 'ACCEPTED' and NEW.status != OLD.status then
            call audit.write_instance_audit(ca_entity_name, NEW.container_area_id,
                                            'INSERT', entity_title, entity_gender,
                                            NEW.number,
                                            db_op_type => TG_OP,
                                            db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.id'),
                                            old_value => cast(OLD.id as varchar),
                                            new_value => cast(NEW.id as varchar));
        end if;
    end if;

    return coalesce(NEW, OLD);
end;
$$;

alter function dsp_removal_cancel_request_audit_trg() owner to sa;

