create function dsp_address_search_entity_trg() returns trigger
    language plpgsql
as
$$
declare
    entity_name varchar = 'ContainerArea';
    attribute_name_1 varchar = 'code';
    attribute_name_2 varchar = 'address';

    instance_ids cursor (changed_id uuid) for
        select ca.id as instance_id 
        from dsp_container_area ca
        where ca.address_id = changed_id;
begin
    if(TG_OP = 'INSERT' or (TG_OP = 'UPDATE' and (
        NEW.id is distinct from OLD.id or
        NEW.delete_ts is distinct from OLD.delete_ts or
        NEW.view_ is distinct from OLD.view_
    ))) then
        for r in instance_ids(NEW.id) loop
            insert into dsp_search_entity_index_refresh_request(id, instance_id, entity_name, attribute_name)
            values (uuid_generate_v4(), r.instance_id, entity_name, attribute_name_1);

            insert into dsp_search_entity_index_refresh_request(id, instance_id, entity_name, attribute_name)
            values (uuid_generate_v4(), r.instance_id, entity_name, attribute_name_2);
        end loop;    
    end if;

    if(TG_OP = 'DELETE' or (TG_OP = 'UPDATE' and (
        NEW.id is distinct from OLD.id
    ))) then
        for r in instance_ids(OLD.id) loop
            insert into dsp_search_entity_index_refresh_request(id, instance_id, entity_name, attribute_name)
            values (uuid_generate_v4(), r.instance_id, entity_name, attribute_name_1);

            insert into dsp_search_entity_index_refresh_request(id, instance_id, entity_name, attribute_name)
            values (uuid_generate_v4(), r.instance_id, entity_name, attribute_name_2);
        end loop;    
    end if;
    return null;
end;
$$;

alter function dsp_address_search_entity_trg() owner to sa;

