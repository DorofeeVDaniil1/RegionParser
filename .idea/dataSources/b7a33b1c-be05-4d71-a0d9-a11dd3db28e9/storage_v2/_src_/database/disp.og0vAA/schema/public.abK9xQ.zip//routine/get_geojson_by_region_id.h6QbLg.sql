create function get_geojson_by_region_id(_region_id uuid) returns character varying
    language plpgsql
as
$$
begin
    return (
        with region_info as (
            select
                dr.name, dgd.id as geo_id, latitude, longitude, order_
            from dsp_region dr
                     join dsp_region_geo_data_link drgdl on dr.id = drgdl.region_id
                     join dsp_geo_data dgd on dgd.id = drgdl.geo_data_id
                     left join dsp_geo_point dgp on dgd.id = dgp.geo_data_id
            where dr.id = _region_id
        ), region_info_geojson as (
            select name, geo_id, latitude, longitude, order_
            from region_info
            union all
            select
                        first_value(name) over (order by order_) as name,
                        first_value(geo_id) over (order by order_) as geo_id,
                        first_value(latitude) over (order by order_) as latitude,
                        first_value(longitude) over (order by order_) as longitude,
                        999999999999999999999999
            from region_info
        )
        select
                                                                                                            '{' || chr(10) ||
                                                                                                            '    "type": "Feature",' || chr(10) ||
                                                                                                            '    "properties": { "name": "' || name || '", "geo_data_id":"'|| geo_id ||'" },' || chr(10) ||
                                                                                                            '    "geometry": {' || chr(10) ||
                                                                                                            '        "coordinates": [' ||  chr(10) ||
                                                                                                            '             [[' || string_agg( longitude|| ', ' || latitude, '], ['  order by order_) || ']]' ||  chr(10) ||
                                                                                                            '         ],' ||  chr(10) ||
                                                                                                            '        "type": "Polygon"' ||  chr(10) ||
                                                                                                            '    }' ||  chr(10) ||
                                                                                                            '}'
                as geojson
        from region_info_geojson
        group by name, geo_id
    );
end;
$$;

alter function get_geojson_by_region_id(uuid) owner to sa;

