create function select_task_from_date(date text) returns uuid
    language plpgsql
as
$$
DECLARE
    v_date TIMESTAMP without time zone:= change_date_format(date);
    v_found BOOLEAN := FALSE;
    rec RECORD;
BEGIN
    WHILE NOT v_found LOOP
            SELECT *
            INTO rec
            FROM dsp_task
            WHERE vehicle_id = (
                SELECT id
                FROM dsp_vehicle
                WHERE number_id = (
                    SELECT id
                    FROM dsp_vehicle_number
                    WHERE full_without_spaces = 'У664НХ138'
                )
            )
              AND create_ts >= v_date
            LIMIT 1;

            IF rec IS NOT NULL THEN
                v_found := TRUE;
                -- Ваши действия с найденной записью
                RAISE NOTICE 'Record found: %', rec;
            ELSE
                v_date := v_date - INTERVAL '1 day';
            END IF;

            -- Для предотвращения бесконечного цикла добавим проверку минимальной даты
            IF v_date < '2000-01-01 00:00:00.0000' THEN
                RAISE NOTICE 'No records found after exhausting date range.';
                EXIT;
            END IF;
        END LOOP;
END $$;

alter function select_task_from_date(text) owner to sa;

