create function find_removal_schedule(schedule_string character varying) returns uuid
    language plpgsql
as
$$
begin

	return

		dsp_removal_schedule.id
		from dsp_removal_schedule
		join dsp_removal_schedule_record ON dsp_removal_schedule_record.schedule_id = dsp_removal_schedule.id
		join dsp_removal_interval ON dsp_removal_interval.id = dsp_removal_schedule_record.interval_id
		group by dsp_removal_schedule.id, dsp_removal_schedule.name
		having 
		array_agg(upper(dsp_removal_interval.name) order by dsp_removal_interval.name)::varchar = 
		(select array_agg(x) from (SELECT unnest(string_to_array(upper(schedule_string), ', ')) AS x ORDER BY x) y)::varchar
		
		limit 1;

end;
$$;

alter function find_removal_schedule(varchar) owner to sa;

