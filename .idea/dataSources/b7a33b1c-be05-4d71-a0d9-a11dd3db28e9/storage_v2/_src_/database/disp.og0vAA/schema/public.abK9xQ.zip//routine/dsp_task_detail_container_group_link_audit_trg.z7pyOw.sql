create function dsp_task_detail_container_group_link_audit_trg() returns trigger
    language plpgsql
as
$$
declare
    task_entity_name constant varchar = 'dsp_Task';
    task_entity_title constant varchar = 'ПЗ';
    task_entity_gender constant audit.gender = 'N';

    cg_entity_name constant varchar = 'dsp_ContainerGroup';
    cg_entity_title constant varchar = 'КГ';
    cg_entity_gender constant audit.gender = 'F';

    new_task_id uuid;
    old_task_id uuid;
begin
    if not audit.is_audit_enabled() then
        return coalesce(NEW, OLD);
    end if;

    if NEW.task_detail_id is not null then
        select td.task_id into new_task_id
        from dsp_task_detail as td where td.id = NEW.task_detail_id;
    end if;
    if OLD.task_detail_id is not null then
        select td.task_id into old_task_id
        from dsp_task_detail as td where td.id = OLD.task_detail_id;
    end if;

    if new_task_id is distinct from old_task_id
        or NEW.container_group_id is distinct from OLD.container_group_id
    then
        --TODO: Get rid of this bloody copy-pastes:
        if old_task_id is not null and OLD.container_group_id is not null then
            call audit.write_instance_audit(task_entity_name, old_task_id,
                'DELETE', cg_entity_title, cg_entity_gender,
                audit.get_container_group_str(OLD.container_group_id),
                db_op_type => TG_OP,
                db_field_name => cast(array[
                    -- task_detail_id influences implicitly on (old|new)_task_id:
                    concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.task_detail_id'),
                    concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.container_group_id')
                ] as varchar),
                old_value => cast(array[
                    cast(OLD.task_detail_id as varchar),
                    cast(OLD.container_group_id as varchar)
                ] as varchar),
                new_value => cast(array[
                    cast(NEW.task_detail_id as varchar),
                    cast(NEW.container_group_id as varchar)
                ] as varchar)
            );
            call audit.write_instance_audit(cg_entity_name, OLD.container_group_id,
                'DELETE', task_entity_title, task_entity_gender,
                audit.get_task_str(old_task_id),
                db_op_type => TG_OP,
                db_field_name => cast(array[
                    -- task_detail_id influences implicitly on (old|new)_task_id:
                    concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.task_detail_id'),
                    concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.container_group_id')
                ] as varchar),
                old_value => cast(array[
                    cast(OLD.task_detail_id as varchar),
                    cast(OLD.container_group_id as varchar)
                ] as varchar),
                new_value => cast(array[
                    cast(NEW.task_detail_id as varchar),
                    cast(NEW.container_group_id as varchar)
                ] as varchar)
            );
        end if;
        if new_task_id is not null and NEW.container_group_id is not null then
            call audit.write_instance_audit(task_entity_name, new_task_id,
                'INSERT', cg_entity_title, cg_entity_gender,
                audit.get_container_group_str(NEW.container_group_id),
                db_op_type => TG_OP,
                db_field_name => cast(array[
                    -- task_detail_id influences implicitly on (old|new)_task_id:
                    concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.task_detail_id'),
                    concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.container_group_id')
                ] as varchar),
                old_value => cast(array[
                    cast(OLD.task_detail_id as varchar),
                    cast(OLD.container_group_id as varchar)
                ] as varchar),
                new_value => cast(array[
                    cast(NEW.task_detail_id as varchar),
                    cast(NEW.container_group_id as varchar)
                ] as varchar)
            );
            call audit.write_instance_audit(cg_entity_name, NEW.container_group_id,
                'INSERT', task_entity_title, task_entity_gender,
                audit.get_task_str(new_task_id),
                db_op_type => TG_OP,
                db_field_name => cast(array[
                    -- task_detail_id influences implicitly on (old|new)_task_id:
                    concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.task_detail_id'),
                    concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.container_group_id')
                ] as varchar),
                old_value => cast(array[
                    cast(OLD.task_detail_id as varchar),
                    cast(OLD.container_group_id as varchar)
                ] as varchar),
                new_value => cast(array[
                    cast(NEW.task_detail_id as varchar),
                    cast(NEW.container_group_id as varchar)
                ] as varchar)
            );
        end if;
    end if;

    return coalesce(NEW, OLD);
end;
$$;

alter function dsp_task_detail_container_group_link_audit_trg() owner to sa;

