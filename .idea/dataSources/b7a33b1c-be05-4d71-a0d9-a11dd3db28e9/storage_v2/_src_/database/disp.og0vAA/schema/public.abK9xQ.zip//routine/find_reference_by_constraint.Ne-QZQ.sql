create function find_reference_by_constraint(constraint_name_ name)
    returns TABLE(table_ name, reference_table information_schema.sql_identifier, referenced_column information_schema.sql_identifier)
    language plpgsql
as
$$
begin
return query  

select rel.relname as table_, ccu.table_name as reference_table, ccu.column_name as referenced_column

	from pg_catalog.pg_constraint con
	join pg_catalog.pg_class rel on rel.oid = con.conrelid
	left join information_schema.constraint_column_usage ccu on con.conname = ccu.constraint_name
	
	where con.conname = constraint_name_;

end;
$$;

alter function find_reference_by_constraint(name) owner to sa;

