create function new_child_region(_name character varying, _geo_data_id uuid, _parent_id uuid) returns uuid
    language plpgsql
as
$$
declare

	_u uuid = uuid_generate_v4();
	
begin

	insert into
	dsp_region
	(
		id, 
		create_ts, created_by,
		delete_ts, deleted_by,
		update_ts, updated_by,
		level_,
		name,
		parent_id,
		geo_data_id
	)
	values
	(
		_u, 
		now()::timestamp, null,
		null, null,
		null, null,
		0,
		_name,
		_parent_id,
		_geo_data_id
	);

	return _u;
	
end;
$$;

alter function new_child_region(varchar, uuid, uuid) owner to sa;

