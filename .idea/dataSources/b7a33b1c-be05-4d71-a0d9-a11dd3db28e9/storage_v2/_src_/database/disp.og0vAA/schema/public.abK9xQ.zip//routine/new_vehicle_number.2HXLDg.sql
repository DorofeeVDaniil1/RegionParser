create function new_vehicle_number(_reg character varying, _no_reg character varying) returns uuid
    language plpgsql
as
$$
declare 

	_u uuid = uuid_generate_v4();
	
begin

	insert into dsp_vehicle_number
	( id, create_ts, created_by, delete_ts, deleted_by, update_ts, updated_by, 
	 full_, full_without_spaces, without_region, without_spaces )
	values
	( 
		_u, now()::timestamp, null, null, null, null, null,
	 	_reg, replace(_reg, ' ', ''), _no_reg, replace(_no_reg, ' ', '') 
	);
	return _u;
	
end;
$$;

alter function new_vehicle_number(varchar, varchar) owner to sa;

