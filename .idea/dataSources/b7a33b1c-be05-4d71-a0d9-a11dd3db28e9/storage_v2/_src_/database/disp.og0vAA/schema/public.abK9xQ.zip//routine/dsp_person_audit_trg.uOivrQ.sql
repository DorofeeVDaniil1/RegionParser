create function dsp_person_audit_trg() returns trigger
    language plpgsql
as
$$
declare
    entity_name constant varchar = 'dsp_Person';
    entity_title constant varchar = 'физлицо';
    entity_gender constant audit.gender = 'N';

    employee_entity_name constant varchar = 'dsp_Employee';
    employee_entity_title constant varchar = 'сотрудник';
    employee_entity_gender constant audit.gender = 'M';

    --The dsp_employee table has unique constraint on person_id and FK on dsp_person table, so neither array nor OLD value necessary
    new_employee_id uuid;
begin
    if not audit.is_audit_enabled() then
        return coalesce(NEW, OLD);
    end if;

    if NEW.id is distinct from OLD.id then
        if NEW.id is not null then
            call audit.write_instance_audit(entity_name, NEW.id,
                'CREATE', entity_title, entity_gender,
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.id'),
                old_value => cast(OLD.id as varchar),
                new_value => cast(NEW.id as varchar));
        end if;
        if OLD.id is not null then
            call audit.write_instance_audit(entity_name, OLD.id,
                'DELETE', entity_title, entity_gender,
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.id'),
                old_value => cast(OLD.id as varchar),
                new_value => cast(NEW.id as varchar));
        end if;
    end if;
    if NEW.id is not null then
        if (NEW.delete_ts is not null) is distinct from (OLD.delete_ts is not null) then
            call audit.write_instance_audit(entity_name, NEW.id,
                audit.get_soft_op_type(NEW.delete_ts is not null, OLD.delete_ts is not null),
                entity_title, entity_gender,
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.delete_ts'),
                old_value => cast(OLD.delete_ts as varchar),
                new_value => cast(NEW.delete_ts as varchar));
        end if;
        if NEW.full_name is distinct from OLD.full_name then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.full_name is null, OLD.full_name is null),
                'ФИО', 'N', coalesce(NEW.full_name, OLD.full_name),
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.full_name'),
                old_value => cast(OLD.full_name as varchar),
                new_value => cast(NEW.full_name as varchar));
        end if;                
        if NEW.first_name is distinct from OLD.first_name then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.first_name is null, OLD.first_name is null),
                'фамилия', 'N', coalesce(NEW.first_name, OLD.first_name),
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.first_name'),
                old_value => cast(OLD.first_name as varchar),
                new_value => cast(NEW.first_name as varchar));
        end if;                
        if NEW.last_name is distinct from OLD.last_name then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.last_name is null, OLD.last_name is null),
                'имя', 'F', coalesce(NEW.last_name, OLD.last_name),
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.last_name'),
                old_value => cast(OLD.last_name as varchar),
                new_value => cast(NEW.last_name as varchar));
        end if;                
        if NEW.patronymic is distinct from OLD.patronymic then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.patronymic is null, OLD.patronymic is null),
                'отчество', 'N', coalesce(NEW.patronymic, OLD.patronymic),
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.patronymic'),
                old_value => cast(OLD.patronymic as varchar),
                new_value => cast(NEW.patronymic as varchar));
        end if;                

        select e.id into new_employee_id
        from dsp_employee as e where e.person_id = NEW.id;

	if new_employee_id is not null then
            if NEW.full_name is distinct from OLD.full_name then
                call audit.write_attribute_audit(employee_entity_name, new_employee_id,
                    audit.get_op_type(NEW.full_name is null, OLD.full_name is null),
                    'ФИО', 'N', coalesce(NEW.full_name, OLD.full_name),
                    db_op_type => TG_OP, 
                    db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.full_name'),
                    old_value => cast(OLD.full_name as varchar),
                    new_value => cast(NEW.full_name as varchar));
            end if;                
            if NEW.first_name is distinct from OLD.first_name then
                call audit.write_attribute_audit(employee_entity_name, new_employee_id,
                    audit.get_op_type(NEW.first_name is null, OLD.first_name is null),
                   'фамилия', 'N', coalesce(NEW.first_name, OLD.first_name),
                    db_op_type => TG_OP, 
                    db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.first_name'),
                    old_value => cast(OLD.first_name as varchar),
                    new_value => cast(NEW.first_name as varchar));
            end if;                
            if NEW.last_name is distinct from OLD.last_name then
                call audit.write_attribute_audit(employee_entity_name, new_employee_id,
                    audit.get_op_type(NEW.last_name is null, OLD.last_name is null),
                    'имя', 'F', coalesce(NEW.last_name, OLD.last_name),
                    db_op_type => TG_OP, 
                    db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.last_name'),
                    old_value => cast(OLD.last_name as varchar),
                    new_value => cast(NEW.last_name as varchar));
            end if;                
            if NEW.patronymic is distinct from OLD.patronymic then
                call audit.write_attribute_audit(employee_entity_name, new_employee_id,
                    audit.get_op_type(NEW.patronymic is null, OLD.patronymic is null),
                    'отчество', 'N', coalesce(NEW.patronymic, OLD.patronymic),
                    db_op_type => TG_OP, 
                    db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.patronymic'),
                    old_value => cast(OLD.patronymic as varchar),
                    new_value => cast(NEW.patronymic as varchar));
            end if;                
        end if;
    end if;

    return coalesce(NEW, OLD);
end;
$$;

alter function dsp_person_audit_trg() owner to sa;

