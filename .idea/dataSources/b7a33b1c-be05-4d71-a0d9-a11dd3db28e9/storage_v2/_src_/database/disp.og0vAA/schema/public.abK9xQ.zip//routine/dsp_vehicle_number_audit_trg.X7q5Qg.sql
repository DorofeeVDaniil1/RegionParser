create function dsp_vehicle_number_audit_trg() returns trigger
    language plpgsql
as
$$
declare
    entity_name constant varchar = 'dsp_Vehicle';

    attribute_title constant varchar = 'госномер';
    attribute_gender constant audit.gender = 'M';

    --The dsp_vehicle table has FK on dsp_vehicle_number table, so no OLD values necessary
    new_vehicle_ids uuid[];
    vehicle_id uuid;
begin
    if not audit.is_audit_enabled() then
        return coalesce(NEW, OLD);
    end if;

    select coalesce(array_agg(v.id), '{}')
    into new_vehicle_ids
    from dsp_vehicle as v
    where v.number_id = NEW.id;

    --TODO: Extend audit API with endpoints accepting arrays of instance ids, not only single ids

    foreach vehicle_id in array new_vehicle_ids loop
        if (NEW.delete_ts is not null) is distinct from (OLD.delete_ts is not null) then
            call audit.write_attribute_audit(entity_name, vehicle_id,
                audit.get_soft_op_type(NEW.delete_ts is not null, OLD.delete_ts is not null),
                attribute_title, attribute_gender, OLD.full_,
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.delete_ts'),
                old_value => cast(OLD.delete_ts as varchar),
                new_value => cast(NEW.delete_ts as varchar));
        end if;
        if NEW.full_ is distinct from OLD.full_ then
            call audit.write_attribute_audit(entity_name, vehicle_id,
                audit.get_op_type(NEW.full_ is null, OLD.full_ is null),
                attribute_title, attribute_gender, coalesce(NEW.full_, OLD.full_),
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.full_'),
                old_value => cast(OLD.full_ as varchar),
                new_value => cast(NEW.full_ as varchar));
        end if;                
    end loop;

    return coalesce(NEW, OLD);
end;
$$;

alter function dsp_vehicle_number_audit_trg() owner to sa;

