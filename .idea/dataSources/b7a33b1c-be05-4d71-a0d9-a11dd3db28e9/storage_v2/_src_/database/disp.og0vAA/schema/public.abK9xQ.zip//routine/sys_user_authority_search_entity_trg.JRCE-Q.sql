create function sys_user_authority_search_entity_trg() returns trigger
    language plpgsql
as
$$
declare
    entity_name varchar = 'Driver';
    attribute_name varchar = 'name';

    instance_ids cursor (changed_id uuid) for
        select e.id as instance_id 
        from dsp_employee e
        where e.user_id = changed_id;
begin
    if(TG_OP = 'INSERT' or (TG_OP = 'UPDATE' and (
        NEW.user_id is distinct from OLD.user_id or
        NEW.authority_name is distinct from OLD.authority_name
    ))) then
        for r in instance_ids(NEW.user_id) loop
            insert into dsp_search_entity_index_refresh_request(id, instance_id, entity_name, attribute_name)
            values (uuid_generate_v4(), r.instance_id, entity_name, attribute_name);
        end loop;    
    end if;

    if(TG_OP = 'DELETE' or (TG_OP = 'UPDATE' and (
        NEW.user_id is distinct from OLD.user_id
    ))) then
        for r in instance_ids(OLD.user_id) loop
            insert into dsp_search_entity_index_refresh_request(id, instance_id, entity_name, attribute_name)
            values (uuid_generate_v4(), r.instance_id, entity_name, attribute_name);
        end loop;    
    end if;
    return null;
end;
$$;

alter function sys_user_authority_search_entity_trg() owner to sa;

