create function new_model(_carrying double precision, _fuel_tank_volume double precision, _garb_vol_max double precision, _garb_vol_min double precision, _name character varying, _fuel_cons double precision, _brand_id uuid) returns uuid
    language plpgsql
as
$$
declare
 
	_u uuid = uuid_generate_v4();
	
begin

	insert into dsp_vehicle_model
	( id, create_ts, created_by, delete_ts, deleted_by, update_ts, updated_by, 
	 	carrying, fuel_tank_volume, garbage_volume_max, garbage_volume_min, name, standard_fuel_consumption, brand_id )
	values
	( _u, now()::timestamp, null, null, null, null, null, 
	 	_carrying, _fuel_tank_volume, _garb_vol_max, _garb_vol_min, _name, _fuel_cons, _brand_id );

	return _u;
	
end;
$$;

alter function new_model(double precision, double precision, double precision, double precision, varchar, double precision, uuid) owner to sa;

