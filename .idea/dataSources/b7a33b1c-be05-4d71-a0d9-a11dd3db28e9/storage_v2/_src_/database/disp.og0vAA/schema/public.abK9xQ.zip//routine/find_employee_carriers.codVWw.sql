create function find_employee_carriers(login_or_full_name_like character varying)
    returns TABLE(login character varying, person character varying, carrier character varying)
    language plpgsql
as
$$
begin  
return query 

	select sys_user.login, dsp_person.full_name as person, dsp_company.full_name as carrier from dsp_carrier_employee_link

	join dsp_employee on dsp_employee.id = dsp_carrier_employee_link.employee_id
	join sys_user ON sys_user.id = dsp_employee.user_id
	join dsp_company on dsp_company.id = dsp_carrier_employee_link.carrier_id
	join dsp_person ON dsp_person.id = dsp_employee.person_id

	where 
		sys_user.login = login_or_full_name_like
		or
		dsp_person.full_name like '%' || login_or_full_name_like || '%'
	;
	
end;
$$;

alter function find_employee_carriers(varchar) owner to sa;

