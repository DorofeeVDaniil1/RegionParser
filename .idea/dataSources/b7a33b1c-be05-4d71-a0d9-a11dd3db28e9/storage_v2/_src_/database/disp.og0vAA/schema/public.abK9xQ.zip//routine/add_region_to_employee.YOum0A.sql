create function add_region_to_employee(_employee_id uuid, _region_id uuid) returns void
    language plpgsql
as
$$
begin
	
 	 
	insert into dsp_region_employee_link
	(employee_id,region_id) 
	
	values 
	(_employee_id,_region_id)
	
	ON CONFLICT DO NOTHING;	

end;
$$;

alter function add_region_to_employee(uuid, uuid) owner to sa;

