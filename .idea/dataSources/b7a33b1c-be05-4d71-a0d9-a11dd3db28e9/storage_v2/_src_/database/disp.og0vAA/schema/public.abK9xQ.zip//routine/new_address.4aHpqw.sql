create function new_address(title character varying) returns uuid
    language plpgsql
as
$$
declare

    _u uuid = uuid_generate_v4();

begin

    insert into dsp_address
    (
        id,
        create_ts, created_by,
        delete_ts, deleted_by,
        update_ts, updated_by,
        house_id, locality_id, street_id,
        view_
    )
    values
        (
            _u,
            now()::timestamp, null,
            null, null,
            null, null,
            null, null, null,
            title
        );
    return _u;

end;
$$;

alter function new_address(varchar) owner to sa;

