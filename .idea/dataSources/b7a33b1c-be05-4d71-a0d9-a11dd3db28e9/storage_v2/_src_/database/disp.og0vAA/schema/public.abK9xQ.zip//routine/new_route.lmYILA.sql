create function new_route(_name character varying, _region_id uuid, _company_id uuid) returns uuid
    language plpgsql
as
$$
declare

    _u uuid = uuid_generate_v4();

begin

    insert into dsp_route
    (id, name, region_id, carrier_id, detail_sorting_strategy, create_ts)
    values (_u, _name, _region_id, _company_id, 0, now());

    return _u;

end;
$$;

alter function new_route(varchar, uuid, uuid) owner to sa;

