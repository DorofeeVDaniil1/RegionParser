create function dsp_task_routes_audit_trg() returns trigger
    language plpgsql
as
$$
declare
    task_entity_name constant varchar = 'dsp_Task';
    task_entity_title constant varchar = 'ПЗ';
    task_entity_gender constant audit.gender = 'N';

    route_entity_name constant varchar = 'dsp_Route';
    route_entity_title constant varchar = 'маршрут';
    route_entity_gender constant audit.gender = 'M';
begin
    if not audit.is_audit_enabled() then
        return coalesce(NEW, OLD);
    end if;

    if NEW.task_id is distinct from OLD.task_id
        or NEW.route_id is distinct from OLD.route_id
    then
        --TODO: Get rid of this bloody copy-pastes:
        if OLD.task_id is not null and OLD.route_id is not null then
            call audit.write_instance_audit(task_entity_name, OLD.task_id,
                'DELETE', route_entity_title, route_entity_gender,
                audit.get_route_str(OLD.route_id),
                db_op_type => TG_OP,
                db_field_name => cast(array[
                    concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.task_id'),
                    concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.route_id')
                ] as varchar),
                old_value => cast(array[
                    cast(OLD.task_id as varchar),
                    cast(OLD.route_id as varchar)
                ] as varchar),
                new_value => cast(array[
                    cast(NEW.task_id as varchar),
                    cast(NEW.route_id as varchar)
                ] as varchar)
            );
            call audit.write_instance_audit(route_entity_name, OLD.route_id,
                'DELETE', task_entity_title, task_entity_gender,
                audit.get_task_str(OLD.task_id),
                db_op_type => TG_OP,
                db_field_name => cast(array[
                    concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.task_id'),
                    concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.route_id')
                ] as varchar),
                old_value => cast(array[
                    cast(OLD.task_id as varchar),
                    cast(OLD.route_id as varchar)
                ] as varchar),
                new_value => cast(array[
                    cast(NEW.task_id as varchar),
                    cast(NEW.route_id as varchar)
                ] as varchar)
            );
        end if;
        if NEW.task_id is not null and NEW.route_id is not null then
            call audit.write_instance_audit(task_entity_name, NEW.task_id,
                'INSERT', route_entity_title, route_entity_gender,
                audit.get_route_str(NEW.route_id),
                db_op_type => TG_OP,
                db_field_name => cast(array[
                    concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.task_id'),
                    concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.route_id')
                ] as varchar),
                old_value => cast(array[
                    cast(OLD.task_id as varchar),
                    cast(OLD.route_id as varchar)
                ] as varchar),
                new_value => cast(array[
                    cast(NEW.task_id as varchar),
                    cast(NEW.route_id as varchar)
                ] as varchar)
            );
            call audit.write_instance_audit(route_entity_name, NEW.route_id,
                'INSERT', task_entity_title, task_entity_gender,
                audit.get_task_str(NEW.task_id),
                db_op_type => TG_OP,
                db_field_name => cast(array[
                    concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.task_id'),
                    concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.route_id')
                ] as varchar),
                old_value => cast(array[
                    cast(OLD.task_id as varchar),
                    cast(OLD.route_id as varchar)
                ] as varchar),
                new_value => cast(array[
                    cast(NEW.task_id as varchar),
                    cast(NEW.route_id as varchar)
                ] as varchar)
            );
        end if;
    end if;

    return coalesce(NEW, OLD);
end;
$$;

alter function dsp_task_routes_audit_trg() owner to sa;

