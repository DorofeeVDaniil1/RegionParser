create function create_report_detailing_empty(_report_id uuid, _container_group_id uuid, _empty integer) returns uuid
    language plpgsql
as
$$
declare _id uuid = uuid_generate_v4();
begin
    insert into dsp_report_detailing_empty(
        id, create_ts, amount, volume, container_type_id, container_group_id, report_id
    )
    select
        _id,
        now(),
        _empty,
        dct.volume,
        dct.id,
        dcg.id,
        _report_id
    from dsp_container_group dcg
             join dsp_container_type dct on dcg.container_type_id = dct.id
    where dcg.id = _container_group_id;
    return _id;
end;
$$;

alter function create_report_detailing_empty(uuid, uuid, integer) owner to sa;

