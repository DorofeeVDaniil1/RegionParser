create function new_geo_point(latitude double precision, longitude double precision) returns uuid
    language plpgsql
as
$$
declare 

	_u uuid = uuid_generate_v4();
	
begin

	insert into dsp_geo_point ( id, latitude, longitude ) 
	values ( _u, latitude, longitude );

	return _u;
	
end;
$$;

alter function new_geo_point(double precision, double precision) owner to sa;

