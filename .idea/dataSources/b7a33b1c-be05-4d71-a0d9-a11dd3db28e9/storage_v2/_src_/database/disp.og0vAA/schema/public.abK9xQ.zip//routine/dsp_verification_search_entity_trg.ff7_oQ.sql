create function dsp_verification_search_entity_trg() returns trigger
    language plpgsql
as
$$
declare
    entity_name varchar = 'Verification';
    attribute_name varchar = 'address';

    instance_ids cursor (changed_id uuid) for
        select changed_id as instance_id;
begin
    if(TG_OP = 'INSERT' or (TG_OP = 'UPDATE' and (
        NEW.id is distinct from OLD.id or
        NEW.delete_ts is distinct from OLD.delete_ts or
        NEW.address is distinct from OLD.address
    ))) then
        for r in instance_ids(NEW.id) loop
            insert into dsp_search_entity_index_refresh_request(id, instance_id, entity_name, attribute_name)
            values (uuid_generate_v4(), r.instance_id, entity_name, attribute_name);
        end loop;    
    end if;

    if(TG_OP = 'DELETE' or (TG_OP = 'UPDATE' and (
        NEW.id is distinct from OLD.id
    ))) then
        for r in instance_ids(OLD.id) loop
            insert into dsp_search_entity_index_refresh_request(id, instance_id, entity_name, attribute_name)
            values (uuid_generate_v4(), r.instance_id, entity_name, attribute_name);
        end loop;    
    end if;
    return null;
end;
$$;

alter function dsp_verification_search_entity_trg() owner to sa;

