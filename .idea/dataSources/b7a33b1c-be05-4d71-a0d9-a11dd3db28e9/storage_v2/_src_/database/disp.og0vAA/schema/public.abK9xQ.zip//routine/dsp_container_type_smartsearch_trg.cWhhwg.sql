create function dsp_container_type_smartsearch_trg() returns trigger
    language plpgsql
as
$$
begin
    if(NEW.id is distinct from OLD.id or
        NEW.volume is distinct from OLD.volume
    ) then
        insert into dsp_smartsearch_queue(context_name, key)
        select distinct
            'dsp_ContainerGroup',
            cast(cg.id as varchar)
        from dsp_container_group as cg
        where cg.container_type_id in (NEW.id, OLD.id);

        insert into dsp_smartsearch_queue(context_name, key)
        select distinct
            'dsp_ContainerGroup(taskDetail.task.vehicle)',
            concat(
                cast(l.container_group_id as varchar), ',',
                cast(t.vehicle_id as varchar)
            )
        from dsp_task_detail_container_group_link as l
            join dsp_task_detail as td on l.task_detail_id = td.id
            join dsp_task as t on td.task_id = t.id
            join dsp_container_group as cg on l.container_group_id = cg.id
        where cg.container_type_id in (NEW.id, OLD.id);

        insert into dsp_smartsearch_queue(context_name, key)
        select distinct
            'dsp_Route(routeDetail.group)',
            concat(
                cast(rd.route_id as varchar), ',',
                cast(rd.group_id as varchar)
            )
        from dsp_route_detail as rd
            join dsp_container_group as cg on rd.group_id = cg.id
            join dsp_container_area as ca on cg.container_area_id = ca.id
        where cg.container_type_id in (NEW.id, OLD.id);
    end if;

    return null;
end;
$$;

alter function dsp_container_type_smartsearch_trg() owner to sa;

