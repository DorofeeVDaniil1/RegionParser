create function dsp_geo_point_audit_trg() returns trigger
    language plpgsql
as
$$
declare
    entity_name constant varchar = 'dsp_ContainerArea';

    --The dsp_container_area table has FK on dsp_geo_data table, which in turn has FK on dsp_geo_point table, so no OLD values necessary
    --TODO: Implement audit trigger for the dsp_geo_data table to complete all links between dsp_container_area and dsp_geo_point tables
    new_container_area_ids uuid[];
    container_area_id uuid;
begin
    if not audit.is_audit_enabled() then
        return coalesce(NEW, OLD);
    end if;

    select coalesce(array_agg(ca.id), '{}')
    into new_container_area_ids
    from dsp_geo_data as gd
        join dsp_container_area as ca on ca.geo_data_id = gd.id
    where gd.center_id = NEW.id;

    --TODO: Extend audit API with endpoints accepting arrays of instance ids, not only single ids

    foreach container_area_id in array new_container_area_ids loop
        if (NEW.delete_ts is not null) is distinct from (OLD.delete_ts is not null) then
            call audit.write_attribute_audit(entity_name, container_area_id,
                audit.get_soft_op_type(NEW.delete_ts is not null, OLD.delete_ts is not null),
                'координаты', 'N', audit.get_geo_point_str(OLD.id),
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.delete_ts'),
                old_value => cast(OLD.delete_ts as varchar),
                new_value => cast(NEW.delete_ts as varchar));
        end if;
        if NEW.latitude is distinct from OLD.latitude then
            call audit.write_attribute_audit(entity_name, container_area_id,
                audit.get_op_type(NEW.latitude is null, OLD.latitude is null),
                'широта', 'F', audit.get_double_str(coalesce(NEW.latitude, OLD.latitude)),
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.latitude'),
                old_value => cast(OLD.latitude as varchar),
                new_value => cast(NEW.latitude as varchar));
        end if;                
        if NEW.longitude is distinct from OLD.longitude then
            call audit.write_attribute_audit(entity_name, container_area_id,
                audit.get_op_type(NEW.longitude is null, OLD.longitude is null),
                'долгота', 'F', audit.get_double_str(coalesce(NEW.longitude, OLD.longitude)),
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.longitude'),
                old_value => cast(OLD.longitude as varchar),
                new_value => cast(NEW.longitude as varchar));
        end if;                
    end loop;

    return coalesce(NEW, OLD);
end;
$$;

alter function dsp_geo_point_audit_trg() owner to sa;

