create function dsp_verification_smartsearch_trg() returns trigger
    language plpgsql
as
$$
begin
    if(NEW.id is distinct from OLD.id or
        NEW.delete_ts is distinct from OLD.delete_ts or
        NEW.address is distinct from OLD.address
    ) then
        insert into dsp_smartsearch_queue(context_name, key)
        select distinct
            'dsp_Verification',
            cast(v.id as varchar)
        from (values
                (NEW.id),
                (OLD.id)
            ) as v(id)
        where v.id is not null;
    end if;

    return null;
end;
$$;

alter function dsp_verification_smartsearch_trg() owner to sa;

