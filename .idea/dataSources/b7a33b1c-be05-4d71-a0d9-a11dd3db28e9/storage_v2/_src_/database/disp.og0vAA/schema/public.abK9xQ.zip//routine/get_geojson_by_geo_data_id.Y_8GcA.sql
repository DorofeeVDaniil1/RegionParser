create function get_geojson_by_geo_data_id(_geo_data_id uuid) returns character varying
    language plpgsql
as
$$
begin
    return (
        with region_info as (
            select
                dgd.id as name, latitude, longitude, order_
            from dsp_geo_data dgd
                     left join dsp_geo_point dgp on dgd.id = dgp.geo_data_id
            where dgd.id = _geo_data_id
        ), region_info_geojson as (
            select name, latitude, longitude, order_
            from region_info
            union all
            select
                        first_value(name) over (order by order_) as name,
                        first_value(latitude) over (order by order_) as latitude,
                        first_value(longitude) over (order by order_) as longitude,
                        999999999999999999999999
            from region_info
        )
        select
                                                                                                    '{' || chr(10) ||
                                                                                                    '    "type": "Feature",' || chr(10) ||
                                                                                                    '    "properties": { "name": "' || name || '" },' || chr(10) ||
                                                                                                    '    "geometry": {' || chr(10) ||
                                                                                                    '        "coordinates": [' ||  chr(10) ||
                                                                                                    '             [[' || string_agg( longitude|| ', ' || latitude, '], ['  order by order_) || ']]' ||  chr(10) ||
                                                                                                    '         ],' ||  chr(10) ||
                                                                                                    '        "type": "Polygon"' ||  chr(10) ||
                                                                                                    '    }' ||  chr(10) ||
                                                                                                    '}' as geojson
        from region_info_geojson
        group by name
    );
end;
$$;

alter function get_geojson_by_geo_data_id(uuid) owner to sa;

