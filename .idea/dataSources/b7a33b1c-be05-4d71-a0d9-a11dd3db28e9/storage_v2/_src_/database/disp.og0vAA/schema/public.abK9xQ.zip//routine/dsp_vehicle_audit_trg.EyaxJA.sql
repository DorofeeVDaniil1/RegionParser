create function dsp_vehicle_audit_trg() returns trigger
    language plpgsql
as
$$
declare
    entity_name constant varchar = 'dsp_Vehicle';
    entity_title constant varchar = 'ТС';
    entity_gender constant audit.gender = 'N';
begin
    if not audit.is_audit_enabled() then
        return coalesce(NEW, OLD);
    end if;

    if NEW.id is distinct from OLD.id then
        if NEW.id is not null then
            call audit.write_instance_audit(entity_name, NEW.id,
                'CREATE', entity_title, entity_gender,
                db_op_type => TG_OP,
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.id'),
                old_value => cast(OLD.id as varchar),
                new_value => cast(NEW.id as varchar));
        end if;
        if OLD.id is not null then
            call audit.write_instance_audit(entity_name, OLD.id,
                'DELETE', entity_title, entity_gender,
                db_op_type => TG_OP,
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.id'),
                old_value => cast(OLD.id as varchar),
                new_value => cast(NEW.id as varchar));
        end if;
    end if;
    if NEW.id is not null then
        if (NEW.delete_ts is not null) is distinct from (OLD.delete_ts is not null) then
            call audit.write_instance_audit(entity_name, NEW.id,
                audit.get_soft_op_type(NEW.delete_ts is not null, OLD.delete_ts is not null),
                entity_title, entity_gender,
                db_op_type => TG_OP,
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.delete_ts'),
                old_value => cast(OLD.delete_ts as varchar),
                new_value => cast(NEW.delete_ts as varchar));
        end if;
        if NEW.number_id is distinct from OLD.number_id then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.number_id is null, OLD.number_id is null),
                'госномер', 'M', audit.get_vehicle_number_str(coalesce(NEW.number_id, OLD.number_id)),
                db_op_type => TG_OP,
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.number_id'),
                old_value => cast(OLD.number_id as varchar),
                new_value => cast(NEW.number_id as varchar));
        end if;
        if NEW.status is distinct from OLD.status then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.status is null, OLD.status is null),
                'статус', 'M', audit.get_vehicle_status_str(coalesce(NEW.status, OLD.status)),
                db_op_type => TG_OP,
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.status'),
                old_value => cast(OLD.status as varchar),
                new_value => cast(NEW.status as varchar));
        end if;
        if NEW.brand_id is distinct from OLD.brand_id then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.brand_id is null, OLD.brand_id is null),
                'модель', 'F', audit.get_vehicle_brand_str(coalesce(NEW.brand_id, OLD.brand_id)),
                db_op_type => TG_OP,
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.brand_id'),
                old_value => cast(OLD.brand_id as varchar),
                new_value => cast(NEW.brand_id as varchar));
        end if;
        if NEW.vehicle_garbage_type is distinct from OLD.vehicle_garbage_type then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.vehicle_garbage_type is null, OLD.vehicle_garbage_type is null),
                'тип', 'M', audit.get_vehicle_garbage_type_str(coalesce(NEW.vehicle_garbage_type, OLD.vehicle_garbage_type)),
                db_op_type => TG_OP,
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.vehicle_garbage_type'),
                old_value => cast(OLD.vehicle_garbage_type as varchar),
                new_value => cast(NEW.vehicle_garbage_type as varchar));
        end if;
        if NEW.chassis is distinct from OLD.chassis then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.chassis is null, OLD.chassis is null),
                'шасси', 'N', coalesce(NEW.chassis, OLD.chassis),
                db_op_type => TG_OP,
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.chassis'),
                old_value => cast(OLD.chassis as varchar),
                new_value => cast(NEW.chassis as varchar));
        end if;
        if NEW.load_type_id is distinct from OLD.load_type_id then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.load_type_id is null, OLD.load_type_id is null),
                'погрузка', 'F', audit.get_container_load_type_str(coalesce(NEW.load_type_id, OLD.load_type_id)),
                db_op_type => TG_OP,
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.load_type_id'),
                old_value => cast(OLD.load_type_id as varchar),
                new_value => cast(NEW.load_type_id as varchar));
        end if;
        if NEW.general_carrier_id is distinct from OLD.general_carrier_id then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.general_carrier_id is null, OLD.general_carrier_id is null),
                'генперевозчик', 'M', audit.get_company_str(coalesce(NEW.general_carrier_id, OLD.general_carrier_id)),
                db_op_type => TG_OP,
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.general_carrier_id'),
                old_value => cast(OLD.general_carrier_id as varchar),
                new_value => cast(NEW.general_carrier_id as varchar));
        end if;
        if NEW.owner_id is distinct from OLD.owner_id then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.owner_id is null, OLD.owner_id is null),
                'перевозчик', 'M', audit.get_company_str(coalesce(NEW.owner_id, OLD.owner_id)),
                db_op_type => TG_OP,
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.owner_id'),
                old_value => cast(OLD.owner_id as varchar),
                new_value => cast(NEW.owner_id as varchar));
        end if;
        if NEW.is_second_stage is distinct from OLD.is_second_stage then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.is_second_stage is null, OLD.is_second_stage is null),
                'второе плечо', 'N', audit.get_boolean_str(coalesce(NEW.is_second_stage, OLD.is_second_stage)),
                db_op_type => TG_OP,
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.is_second_stage'),
                old_value => cast(OLD.is_second_stage as varchar),
                new_value => cast(NEW.is_second_stage as varchar));
        end if;
        if NEW.location_id is distinct from OLD.location_id then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.location_id is null, OLD.location_id is null),
                'гараж', 'M', audit.get_vehicle_location_str(coalesce(NEW.location_id, OLD.location_id)),
                db_op_type => TG_OP,
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.location_id'),
                old_value => cast(OLD.location_id as varchar),
                new_value => cast(NEW.location_id as varchar));
        end if;
        if NEW.default_unloading_point_id is distinct from OLD.default_unloading_point_id then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.default_unloading_point_id is null, OLD.default_unloading_point_id is null),
                'место разгрузки', 'N', audit.get_garbage_unloading_point_str(coalesce(NEW.default_unloading_point_id, OLD.default_unloading_point_id)),
                db_op_type => TG_OP,
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.default_unloading_point_id'),
                old_value => cast(OLD.default_unloading_point_id as varchar),
                new_value => cast(NEW.default_unloading_point_id as varchar));
        end if;
        if NEW.body_volume is distinct from OLD.body_volume then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.body_volume is null, OLD.body_volume is null),
                'объем кузова', 'M', audit.get_double_str(coalesce(NEW.body_volume, OLD.body_volume)),
                db_op_type => TG_OP,
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.body_volume'),
                old_value => cast(OLD.body_volume as varchar),
                new_value => cast(NEW.body_volume as varchar));
        end if;
        if NEW.compression_ratio is distinct from OLD.compression_ratio then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.compression_ratio is null, OLD.compression_ratio is null),
                'коэф-т уплотнения', 'M', audit.get_double_str(coalesce(NEW.compression_ratio, OLD.compression_ratio)),
                db_op_type => TG_OP,
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.compression_ratio'),
                old_value => cast(OLD.compression_ratio as varchar),
                new_value => cast(NEW.compression_ratio as varchar));
        end if;
        if NEW.capacity is distinct from OLD.capacity then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.capacity is null, OLD.capacity is null),
                'грузоподъемность', 'F', audit.get_double_str(coalesce(NEW.capacity, OLD.capacity)),
                db_op_type => TG_OP,
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.capacity'),
                old_value => cast(OLD.capacity as varchar),
                new_value => cast(NEW.capacity as varchar));
        end if;
        if NEW.year_of_manufacture is distinct from OLD.year_of_manufacture then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.year_of_manufacture is null, OLD.year_of_manufacture is null),
                'год выпуска', 'M', audit.get_integer_str(coalesce(NEW.year_of_manufacture, OLD.year_of_manufacture)),
                db_op_type => TG_OP,
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.year_of_manufacture'),
                old_value => cast(OLD.year_of_manufacture as varchar),
                new_value => cast(NEW.year_of_manufacture as varchar));
        end if;
        if NEW.vehicle_fuel_type is distinct from OLD.vehicle_fuel_type then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.vehicle_fuel_type is null, OLD.vehicle_fuel_type is null),
                'тип топлива', 'M', audit.get_vehicle_fuel_type_str(coalesce(NEW.vehicle_fuel_type, OLD.vehicle_fuel_type)),
                db_op_type => TG_OP,
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.vehicle_fuel_type'),
                old_value => cast(OLD.vehicle_fuel_type as varchar),
                new_value => cast(NEW.vehicle_fuel_type as varchar));
        end if;
        if NEW.schedule_id is distinct from OLD.schedule_id then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.schedule_id is null, OLD.schedule_id is null),
                'график работы', 'M', audit.get_removal_schedule_str(coalesce(NEW.schedule_id, OLD.schedule_id)),
                db_op_type => TG_OP,
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.schedule_id'),
                old_value => cast(OLD.schedule_id as varchar),
                new_value => cast(NEW.schedule_id as varchar));
        end if;
        if NEW.eco_class is distinct from OLD.eco_class then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.eco_class is null, OLD.eco_class is null),
                'эко класс', 'M', audit.get_vehicle_eco_class_str(coalesce(NEW.eco_class, OLD.eco_class)),
                db_op_type => TG_OP,
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.eco_class'),
                old_value => cast(OLD.eco_class as varchar),
                new_value => cast(NEW.eco_class as varchar));
        end if;
        if NEW.size_category_id is distinct from OLD.size_category_id then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.size_category_id is null, OLD.size_category_id is null),
                'габариты', 'N', audit.get_vehicle_size_category_str(coalesce(NEW.size_category_id, OLD.size_category_id)),
                db_op_type => TG_OP,
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.size_category_id'),
                old_value => cast(OLD.size_category_id as varchar),
                new_value => cast(NEW.size_category_id as varchar));
        end if;
    end if;

    return coalesce(NEW, OLD);
end;
$$;

alter function dsp_vehicle_audit_trg() owner to sa;

