create function dsp_employee_search_entity_trg() returns trigger
    language plpgsql
as
$$
declare
    entity_name_1 varchar = 'Driver';
    attribute_name_1 varchar = 'name';

    entity_name_2 varchar = 'Employee';
    attribute_name_2 varchar = 'name';

    entity_name_3 varchar = 'Employee';
    attribute_name_3 varchar = 'email';

    instance_ids cursor (changed_id uuid) for
        select changed_id as instance_id;
begin
    if(TG_OP = 'INSERT' or (TG_OP = 'UPDATE' and (
        NEW.id is distinct from OLD.id or 
        NEW.delete_ts is distinct from OLD.delete_ts or
        NEW.person_id is distinct from OLD.person_id or
        NEW.user_id is distinct from OLD.user_id
    ))) then
        for r in instance_ids(NEW.id) loop
            insert into dsp_search_entity_index_refresh_request(id, instance_id, entity_name, attribute_name)
            values (uuid_generate_v4(), r.instance_id, entity_name_1, attribute_name_1);
        end loop;    
    end if;
    
    if(TG_OP = 'INSERT' or (TG_OP = 'UPDATE' and (
        NEW.id is distinct from OLD.id or 
        NEW.delete_ts is distinct from OLD.delete_ts or
        NEW.person_id is distinct from OLD.person_id
    ))) then
        for r in instance_ids(NEW.id) loop
            insert into dsp_search_entity_index_refresh_request(id, instance_id, entity_name, attribute_name)
            values (uuid_generate_v4(), r.instance_id, entity_name_2, attribute_name_2);
        end loop;    
    end if;
    
    if(TG_OP = 'INSERT' or (TG_OP = 'UPDATE' and (
        NEW.id is distinct from OLD.id or 
        NEW.delete_ts is distinct from OLD.delete_ts or
        NEW.person_id is distinct from OLD.person_id or
        NEW.email is distinct from OLD.email
    ))) then
        for r in instance_ids(NEW.id) loop
            insert into dsp_search_entity_index_refresh_request(id, instance_id, entity_name, attribute_name)
            values (uuid_generate_v4(), r.instance_id, entity_name_3, attribute_name_3);
        end loop;    
    end if;
    
    if(TG_OP = 'DELETE' or (TG_OP = 'UPDATE' and (
        NEW.id is distinct from OLD.id
    ))) then
        for r in instance_ids(OLD.id) loop
            insert into dsp_search_entity_index_refresh_request(id, instance_id, entity_name, attribute_name)
            values (uuid_generate_v4(), r.instance_id, entity_name_1, attribute_name_1);

            insert into dsp_search_entity_index_refresh_request(id, instance_id, entity_name, attribute_name)
            values (uuid_generate_v4(), r.instance_id, entity_name_2, attribute_name_2);

            insert into dsp_search_entity_index_refresh_request(id, instance_id, entity_name, attribute_name)
            values (uuid_generate_v4(), r.instance_id, entity_name_3, attribute_name_3);
        end loop;    
    end if;
    return null;
end;
$$;

alter function dsp_employee_search_entity_trg() owner to sa;

