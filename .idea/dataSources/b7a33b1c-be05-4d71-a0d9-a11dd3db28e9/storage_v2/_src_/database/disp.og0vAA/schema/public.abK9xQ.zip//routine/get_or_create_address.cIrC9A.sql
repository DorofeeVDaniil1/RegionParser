create function get_or_create_address(title character varying) returns uuid
    language plpgsql
as
$$
begin
    return (
        select
            coalesce (
                    (select id from dsp_address where view_ = title),
                    new_address(title)
            )
    );
end;
$$;

alter function get_or_create_address(varchar) owner to sa;

