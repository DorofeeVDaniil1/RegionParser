create function dsp_vehicle_shift_audit_func() returns trigger
    language plpgsql
as
$$
declare
    entity_name constant varchar = 'dsp_Vehicle';
    vehicle_shift_gender constant audit.gender = 'F';
    vehicle_shift_region_gender constant  audit.gender = 'M';
    vehicle dsp_vehicle;
begin
    if not audit.is_audit_enabled() then
        return coalesce(NEW, OLD);
    end if;

    -- Getting vehicle entity, referenced by vehicle shift
    select * into vehicle from dsp_vehicle
    where id = coalesce(NEW.vehicle_id, OLD.vehicle_id);

    if NEW.id is distinct from OLD.id then

        -- When entity just created
        if NEW.id is not null AND audit.is_auditable_vehicle_shift(NEW) then
            call audit.write_instance_audit(
                entity_name,
                NEW.vehicle_id,
                cast('INSERT' as audit.op_type),
                audit.get_vehicle_shift_str(NEW.number),
                vehicle_shift_gender,
                db_op_type => 'INSERT',
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.id'),
                old_value => cast(OLD.id as varchar),
                new_value => cast(NEW.id as varchar)
                );
        end if;

        -- When entity just deleted
        if OLD.id is not null AND audit.is_auditable_vehicle_shift(OLD) then
            call audit.write_instance_audit(
                entity_name,
                OLD.vehicle_id,
                cast('DELETE' as audit.op_type),
                concat('смена №', cast(OLD.number as varchar)),
                vehicle_shift_gender,
                db_op_type => TG_OP,
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.id'),
                old_value => cast(OLD.id as varchar),
                new_value => cast(NEW.id as varchar)
                );
        end if;
    end if;

    -- When entity updated
    if NEW.id is not null AND OLD.id is not null AND audit.is_auditable_vehicle_shift(NEW) then

        -- When entity soft-deleted or soft-restored
        if (NEW.delete_ts is not null) is distinct from (OLD.delete_ts is not null) then

            call audit.write_instance_audit(
                entity_name,
                NEW.vehicle_id,
                audit.get_soft_op_type(NEW.delete_ts is not null, OLD.delete_ts is not null),
                audit.get_vehicle_shift_str(NEW.number),
                vehicle_shift_gender,
                db_op_type => TG_OP,
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.delete_ts'),
                old_value => cast(OLD.delete_ts as varchar),
                new_value => cast(NEW.delete_ts as varchar)
            );
        end if;

        -- When region_id attribute changed
        if NEW.region_id is distinct from OLD.region_id then
            call audit.write_attribute_audit(
                entity_name,
                NEW.vehicle_id,
                cast('UPDATE' as audit.op_type),
                concat('Участок смены №', NEW.number),
                vehicle_shift_region_gender,
                value_str => audit.get_region_str(NEW.region_id),
                db_op_type => TG_OP,
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.region_id'),
                old_value => cast(OLD.region_id as varchar),
                new_value => cast(NEW.region_id as varchar)
            );
        end if;
    end if;

    return coalesce(NEW, OLD);
end;
$$;

alter function dsp_vehicle_shift_audit_func() owner to sa;

