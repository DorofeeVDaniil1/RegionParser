create function find_kgo(_lk_code character varying) returns uuid
    language plpgsql
as
$$
begin 
	
 	 return dsp_container_group.id
	 from dsp_container_area
	 join dsp_container_group ON dsp_container_group.container_area_id = dsp_container_area.id
	 where lk_code = _lk_code
	 and category = 1
	 limit 1;

end;
$$;

alter function find_kgo(varchar) owner to sa;

