create function find_tasks_by_number(full_number_like character varying)
    returns TABLE(task_id uuid, created_by character varying, created_at timestamp without time zone, start_date timestamp without time zone, vehicle character varying, region character varying, carrier character varying)
    language plpgsql
as
$$
begin   
return query

	select 
		dsp_task.id as task_id, 
		dsp_task.created_by as created_by, 
		dsp_task.create_ts as created_at, 
		dsp_task.start_date, 
		full_ as vehicle, 
		dsp_region.name as region, 
		d1.full_name as carrier
	from dsp_task 
	
	join dsp_vehicle on dsp_task.vehicle_id = dsp_vehicle.id 
	join dsp_vehicle_number ON dsp_vehicle_number.id = dsp_vehicle.number_id
	join dsp_region ON dsp_region.id = dsp_task.region_id
	left join dsp_company d1 ON d1.id = dsp_vehicle.owner_id

	where full_ like '%' || full_number_like || '%'

order by dsp_task.start_date desc;

end;
$$;

alter function find_tasks_by_number(varchar) owner to sa;

