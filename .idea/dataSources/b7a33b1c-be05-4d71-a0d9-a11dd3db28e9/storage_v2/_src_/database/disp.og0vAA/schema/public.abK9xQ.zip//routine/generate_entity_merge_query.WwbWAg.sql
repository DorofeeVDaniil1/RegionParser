create function generate_entity_merge_query(sql_entity_name character varying, old_id uuid, new_id uuid) returns character varying
    language plpgsql
as
$$
begin
    return (
        with constr as (
            select
                table_name as tb,
                column_name as col
            from find_constraints(sql_entity_name)
        ), prepared_statement as (
            select 'update ' || tb || ' set ' || col || ' = ''' || new_id ||
                   ''' where ' || col || ' = ''' || old_id || ''';'
                       as statement
            from constr
        )
        select string_agg(statement, chr(10))
        from prepared_statement
    );
end;
$$;

alter function generate_entity_merge_query(varchar, uuid, uuid) owner to sa;

