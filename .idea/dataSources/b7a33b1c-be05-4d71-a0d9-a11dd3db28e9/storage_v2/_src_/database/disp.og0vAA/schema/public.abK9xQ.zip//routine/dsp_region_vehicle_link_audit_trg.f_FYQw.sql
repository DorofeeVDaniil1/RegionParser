create function dsp_region_vehicle_link_audit_trg() returns trigger
    language plpgsql
as
$$
declare
    vehicle_entity_name constant varchar = 'dsp_Vehicle';

    region_entity_title constant varchar = 'участок вывоза';
    region_entity_gender constant audit.gender = 'M';
begin
    if not audit.is_audit_enabled() then
        return coalesce(NEW, OLD);
    end if;

    if NEW.vehicle_id is distinct from OLD.vehicle_id
        or NEW.region_id is distinct from OLD.region_id
    then
        --TODO: Get rid of this bloody copy-pastes:
        if OLD.vehicle_id is not null and OLD.region_id is not null then
            call audit.write_instance_audit(vehicle_entity_name, OLD.vehicle_id,
                'DELETE', region_entity_title, region_entity_gender,
                audit.get_region_str(OLD.region_id),
                db_op_type => TG_OP,
                db_field_name => cast(array[
                    concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.vehicle_id'),
                    concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.region_id')
                ] as varchar),
                old_value => cast(array[
                    cast(OLD.vehicle_id as varchar),
                    cast(OLD.region_id as varchar)
                ] as varchar),
                new_value => cast(array[
                    cast(NEW.vehicle_id as varchar),
                    cast(NEW.region_id as varchar)
                ] as varchar)
            );
        end if;
        if NEW.vehicle_id is not null and NEW.region_id is not null then
            call audit.write_instance_audit(vehicle_entity_name, NEW.vehicle_id,
                'INSERT', region_entity_title, region_entity_gender,
                audit.get_region_str(NEW.region_id),
                db_op_type => TG_OP,
                db_field_name => cast(array[
                    concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.vehicle_id'),
                    concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.region_id')
                ] as varchar),
                old_value => cast(array[
                    cast(OLD.vehicle_id as varchar),
                    cast(OLD.region_id as varchar)
                ] as varchar),
                new_value => cast(array[
                    cast(NEW.vehicle_id as varchar),
                    cast(NEW.region_id as varchar)
                ] as varchar)
            );
        end if;
    end if;

    return coalesce(NEW, OLD);
end;
$$;

alter function dsp_region_vehicle_link_audit_trg() owner to sa;

