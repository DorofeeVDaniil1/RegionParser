create function new_geo_data_point(latitude double precision, longitude double precision) returns uuid
    language plpgsql
as
$$
declare

    _u uuid = uuid_generate_v4();

begin

    insert into dsp_geo_data ( id, create_ts, created_by, center_id, geometric_figure )
    values ( _u, CURRENT_TIMESTAMP, 'dan.dor', new_geo_point(latitude, longitude), 'POINT' );

    return _u;

end;
$$;

alter function new_geo_data_point(double precision, double precision) owner to sa;

