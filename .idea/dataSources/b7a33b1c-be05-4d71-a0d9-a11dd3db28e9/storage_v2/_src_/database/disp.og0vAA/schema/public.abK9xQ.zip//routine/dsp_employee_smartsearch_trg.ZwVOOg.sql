create function dsp_employee_smartsearch_trg() returns trigger
    language plpgsql
as
$$
begin
    if(NEW.id is distinct from OLD.id or
        NEW.delete_ts is distinct from OLD.delete_ts or
        NEW.person_id is distinct from OLD.person_id or
        NEW.email is distinct from OLD.email or
        NEW.user_id is distinct from OLD.user_id
    ) then
        insert into dsp_smartsearch_queue(context_name, key)
        select distinct
            'dsp_Employee',
            cast(e.id as varchar)
        from (values
                (NEW.id),
                (OLD.id)
            ) as e(id)
        where e.id is not null;
    end if;

    if(NEW.id is distinct from OLD.id or
        NEW.person_id is distinct from OLD.person_id
    ) then
        insert into dsp_smartsearch_queue(context_name, key)
        select distinct
            'dsp_Task',
            cast(t.id as varchar)
        from dsp_task as t
        where t.driver_id in (NEW.id, OLD.id);
    end if;

    return null;
end;
$$;

alter function dsp_employee_smartsearch_trg() owner to sa;

