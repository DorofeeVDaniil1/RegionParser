create function find_container_group(_lk_code character varying, _amount integer, _volume double precision) returns uuid
    language plpgsql
as
$$
begin
	
 	 return dsp_container_group.id
	 from dsp_container_area
	 join dsp_container_group ON dsp_container_group.container_area_id = dsp_container_area.id
	 join dsp_container_type ON dsp_container_type.id = dsp_container_group.container_type_id
	 
	 where lk_code = _lk_code
	 and volume = _volume
	 and amount = _amount
	 
	 limit 1;	 

end;
$$;

alter function find_container_group(varchar, integer, double precision) owner to sa;

