create function array_union_step(s anyarray, n anyarray) returns anyarray
    immutable
    leakproof
    parallel safe
    language sql
as
$$
SELECT s || n;
$$;

alter function array_union_step(anyarray, anyarray) owner to sa;

