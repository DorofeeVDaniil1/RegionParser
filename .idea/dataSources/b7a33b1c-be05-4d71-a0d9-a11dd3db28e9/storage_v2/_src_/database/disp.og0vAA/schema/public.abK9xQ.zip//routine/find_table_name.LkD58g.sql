create function find_table_name(like_pattern character varying)
    returns TABLE(tn information_schema.sql_identifier)
    language plpgsql
as
$$
begin
return query
 
	select table_name as tn from information_schema."tables" where upper(table_name) like '%'||upper(like_pattern)||'%';
	
end;
$$;

alter function find_table_name(varchar) owner to sa;

