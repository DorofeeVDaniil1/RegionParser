create function new_container_area(lk_code_ character varying, address character varying, latitude double precision, longitude double precision, owner_name character varying, note_ character varying) returns uuid
    language plpgsql
as
$$
declare

    _u uuid = uuid_generate_v4();

begin

    insert into dsp_container_area (id, lk_code, geo_data_id, address_id, owner_company_id, note)

    select
        _u,
        lk_code_,
        new_geo_data_point(latitude, longitude),
        get_or_create_address(address),
        get_or_create_company(owner_name),
        note_
    where not exists (select 1 from dsp_container_area a where a.lk_code = lk_code_)
    ;

    return _u;

end;
$$;

alter function new_container_area(varchar, varchar, double precision, double precision, varchar, varchar) owner to sa;

