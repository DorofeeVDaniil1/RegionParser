create procedure link_container_group_to_route(route_name character varying, _lk_code character varying, vol double precision)
    language plpgsql
as
$$
begin  
 
insert into dsp_route_container_group_link (route_id, group_id)

select dsp_route.id, dsp_container_group.id

from 

dsp_route,
dsp_container_area
		join dsp_container_group ON dsp_container_group.container_area_id = dsp_container_area.id
		join dsp_container_type ON dsp_container_type.id = dsp_container_group.container_type_id

where 
	dsp_route.name = route_name
and
	dsp_container_type.volume = vol
and
	lk_code = _lk_code
	
on conflict do nothing;
	
end;
$$;

alter procedure link_container_group_to_route(varchar, varchar, double precision) owner to sa;

