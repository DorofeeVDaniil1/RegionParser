create function dsp_container_area_tags_audit_trg() returns trigger
    language plpgsql
as
$$
declare
    entity_name   constant varchar      = 'dsp_ContainerArea';
    entity_title  constant varchar      = 'метка';
    entity_gender constant audit.gender = 'F';
    tag_name               varchar;
begin
    -- Обработка вставки
    if TG_OP = 'INSERT' then
        if NEW.tag_id is not null then
            tag_name = audit.get_tag_name(NEW.tag_id);
            call audit.write_instance_audit(entity_name, NEW.area_id,
                                            'INSERT', entity_title, entity_gender,tag_name,
                                            db_op_type => TG_OP,
                                            db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.tag_id'),
                                            old_value => cast(null as varchar),
                                            new_value => cast(NEW.tag_id as varchar));
        end if;
    end if;

    -- Обработка удаления
    if TG_OP = 'DELETE' then
        if OLD.tag_id is not null then
            tag_name = audit.get_tag_name(OLD.tag_id);
            call audit.write_instance_audit(entity_name, OLD.area_id,
                                            'DELETE', entity_title, entity_gender,tag_name,
                                            db_op_type => TG_OP,
                                            db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.tag_id'),
                                            old_value => cast(OLD.tag_id as varchar),
                                            new_value => cast(null as varchar));
        end if;
    end if;

    return null;
end
$$;

alter function dsp_container_area_tags_audit_trg() owner to sa;

