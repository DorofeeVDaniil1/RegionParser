create function dsp_report_detailing_audit_trg() returns trigger
    language plpgsql
as
$$
declare
    entity_name constant varchar = 'dsp_ReportFromDriver';
    entity_title constant varchar = 'отчет водителя';
    entity_gender constant audit.gender = 'M';
    attribute_title constant varchar = TG_ARGV[0];
    attribute_gender constant audit.gender = TG_ARGV[1];
begin
    if not audit.is_audit_enabled() then
        return coalesce(NEW, OLD);
    end if;

    if NEW.report_id is distinct from OLD.report_id then
        if NEW.report_id is not null then
            call audit.write_attribute_audit(entity_name, NEW.report_id,
                audit.get_op_type(NEW.amount is null, true),
                attribute_title, attribute_gender,
                audit.get_report_detailing_amount_str(NEW.amount, NEW.container_group_id),
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.report_id'),
                old_value => cast(OLD.report_id as varchar),
                new_value => cast(NEW.report_id as varchar));
        end if;
        if OLD.report_id is not null then
            call audit.write_attribute_audit(entity_name, OLD.report_id,
                audit.get_op_type(true, OLD.amount is null),
                attribute_title, attribute_gender,
                audit.get_report_detailing_amount_str(OLD.amount, OLD.container_group_id),
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.report_id'),
                old_value => cast(OLD.report_id as varchar),
                new_value => cast(NEW.report_id as varchar));
        end if;
    elsif NEW.report_id is not null then
        if NEW.container_group_id is distinct from OLD.container_group_id then
            if NEW.container_group_id is not null then
                call audit.write_attribute_audit(entity_name, NEW.report_id,
                    audit.get_op_type(NEW.amount is null, true),
                    attribute_title, attribute_gender, 
                    audit.get_report_detailing_amount_str(NEW.amount, NEW.container_group_id),
                    db_op_type => TG_OP, 
                    db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.container_group_id'),
                    old_value => cast(OLD.container_group_id as varchar),
                    new_value => cast(NEW.container_group_id as varchar));
            end if;
            if OLD.container_group_id is not null then
                call audit.write_attribute_audit(entity_name, NEW.report_id,
                    audit.get_op_type(true, OLD.amount is null),
                    attribute_title, attribute_gender, 
                    audit.get_report_detailing_amount_str(OLD.amount, OLD.container_group_id),
                    db_op_type => TG_OP, 
                    db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.container_group_id'),
                    old_value => cast(OLD.container_group_id as varchar),
                    new_value => cast(NEW.container_group_id as varchar));
            end if;
        else
            if NEW.amount is distinct from OLD.amount then
                call audit.write_attribute_audit(entity_name, NEW.report_id,
                    audit.get_op_type(NEW.amount is null, OLD.amount is null),
                    attribute_title, attribute_gender, 
                    audit.get_report_detailing_amount_str(coalesce(NEW.amount, OLD.amount), NEW.container_group_id),
                    db_op_type => TG_OP, 
                    db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.amount'),
                    old_value => cast(OLD.amount as varchar),
                    new_value => cast(NEW.amount as varchar));
            end if;
        end if;            
    end if;

    return coalesce(NEW, OLD);
end;
$$;

alter function dsp_report_detailing_audit_trg() owner to sa;

