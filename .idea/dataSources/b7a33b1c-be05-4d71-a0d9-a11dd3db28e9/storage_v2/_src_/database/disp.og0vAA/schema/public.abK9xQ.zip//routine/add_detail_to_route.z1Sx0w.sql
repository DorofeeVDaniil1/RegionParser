create procedure add_detail_to_route(_route_id uuid, _group_id uuid, _schedule_id uuid)
    language plpgsql
as
$$
begin 
 
insert into dsp_route_detail (id, route_id, group_id, schedule_id)

select uuid_generate_v4(), _route_id, _group_id, _schedule_id;
	
end;
$$;

alter procedure add_detail_to_route(uuid, uuid, uuid) owner to sa;

