create function new_assembly(_name character varying, _container_id uuid, _model_id uuid) returns uuid
    language plpgsql
as
$$
declare

	_u uuid = uuid_generate_v4(); 
	
begin

	insert into dsp_vehicle_assembly
	( id, create_ts, created_by, delete_ts, deleted_by, update_ts, updated_by, 
	 name, container_id, dimensions_id, model_id )
	values
	( _u, now()::timestamp, null, null, null, null, null, _name, _container_id, null, _model_id );

	return _u;
	
end;
$$;

alter function new_assembly(varchar, uuid, uuid) owner to sa;

