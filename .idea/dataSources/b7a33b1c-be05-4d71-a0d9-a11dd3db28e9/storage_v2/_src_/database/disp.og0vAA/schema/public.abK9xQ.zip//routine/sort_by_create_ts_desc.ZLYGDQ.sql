create function sort_by_create_ts_desc(a timestamp without time zone, b timestamp without time zone) returns integer
    language plpgsql
as
$$
BEGIN
    IF a < b THEN
        RETURN 1;
    ELSEIF a > b THEN
        RETURN -1;
    ELSE
        RETURN 0;
    END IF;
END;
$$;

alter function sort_by_create_ts_desc(timestamp, timestamp) owner to sa;

