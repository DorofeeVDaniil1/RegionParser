create procedure grant_admin(login_ character varying)
    language plpgsql
as
$$
begin
    insert into sys_user_authority
    select id, 'ROLE_SYSTEM_ADMIN' from sys_user where login = login_;
end;
$$;

alter procedure grant_admin(varchar) owner to sa;

