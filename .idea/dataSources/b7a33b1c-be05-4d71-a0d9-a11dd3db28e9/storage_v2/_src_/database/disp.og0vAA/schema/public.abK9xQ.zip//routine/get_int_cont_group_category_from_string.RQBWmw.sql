create function get_int_cont_group_category_from_string(category character varying) returns integer
    language plpgsql
as
$$
DECLARE
    result integer;
BEGIN
    CASE upper(trim(category))
        WHEN NULL THEN return NULL;
        WHEN 'ТКО' THEN result := 0;
        WHEN 'TKO' THEN result := 0;
        WHEN 'KGO' THEN result := 1;
        WHEN 'КГО' THEN result := 1;
        WHEN 'РСО' THEN result := 2;
        WHEN 'PCO' THEN result := 2;
        WHEN 'МЕШКИ' THEN result := 3;
        WHEN 'BAG' THEN result := 3;
        ELSE RAISE EXCEPTION 'Invalid status';
        END CASE;

    RETURN result;
END;
$$;

alter function get_int_cont_group_category_from_string(varchar) owner to sa;

