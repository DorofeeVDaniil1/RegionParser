create function dsp_inventorization_detail_smartsearch_trg() returns trigger
    language plpgsql
as
$$
begin
    if(NEW.verification_id is distinct from OLD.verification_id or
        NEW.inventorization_id is distinct from OLD.inventorization_id
    ) then
        insert into dsp_smartsearch_queue(context_name, key)
        select distinct
            'dsp_Verification',
            cast(v.id as varchar)
        from (values
                (NEW.verification_id),
                (OLD.verification_id)
            ) as v(id)
        where v.id is not null;
    end if;

    return null;
end;
$$;

alter function dsp_inventorization_detail_smartsearch_trg() owner to sa;

