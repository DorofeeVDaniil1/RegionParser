create function create_task_detail(_task_id uuid, _container_group_id uuid) returns uuid
    language plpgsql
as
$$
declare _id uuid = uuid_generate_v4();
begin
    insert into dsp_task_detail(
        id,
        create_ts,
        containers_amount_plan,
        containers_volume_plan,
        order_,
        container_area_id,
        task_id
    )
    select
        _id,
        now(),
        0,
        0,
        0,
        dca.id,
        _task_id
    from dsp_container_area dca
             join dsp_container_group dcg on dca.id = dcg.container_area_id
    where dcg.id = _container_group_id;

    insert into dsp_task_detail_container_group_link(task_detail_id, container_group_id)
    values (_id, _container_group_id);

    return _id;
end;
$$;

alter function create_task_detail(uuid, uuid) owner to sa;

