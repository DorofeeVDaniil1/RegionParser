create function dsp_task_detail_audit_trg() returns trigger
    language plpgsql
as
$$
declare
    task_entity_name constant varchar = 'dsp_Task';
    task_entity_title constant varchar = 'ПЗ';
    task_entity_gender constant audit.gender = 'N';

    task_verification_request constant varchar = 'заявка на верификацию';

    cg_entity_name constant varchar = 'dsp_ContainerGroup';
    cg_entity_title constant varchar = 'КГ';
    cg_entity_gender constant audit.gender = 'F';

    ca_entity_name constant varchar = 'dsp_ContainerArea';
    ca_entity_title constant varchar = 'КП';
    ca_entity_gender constant audit.gender = 'F';

    ca_kgo_entity_title constant varchar = 'КП КГО';
    ca_kgo_entity_gender constant audit.gender = 'F';

    new_container_group_ids uuid[];
    old_container_group_ids uuid[];
    add_container_group_ids uuid[];
    del_container_group_ids uuid[];
    container_group_id uuid;

    soft_op_type audit.op_type;
begin
    if not audit.is_audit_enabled() then
        return coalesce(NEW, OLD);
    end if;

    --TODO: Review audit API method signatures, maybe put 'OLD' args in front of 'NEW' ones?
    --      Then review all triggers and put 'INSERT's before 'DELETE's

    select coalesce(array_agg(l.container_group_id), '{}')
    into new_container_group_ids
    from dsp_task_detail_container_group_link as l
    where l.task_detail_id = NEW.id and l.container_group_id is not null;

    select coalesce(array_agg(l.container_group_id), '{}')
    into old_container_group_ids
    from dsp_task_detail_container_group_link as l
    where l.task_detail_id = OLD.id and l.container_group_id is not null;

    select coalesce(audit.array_minus(new_container_group_ids, old_container_group_ids), '{}'),
           coalesce(audit.array_minus(old_container_group_ids, new_container_group_ids), '{}')
    into add_container_group_ids, del_container_group_ids;

    if NEW.task_id is distinct from OLD.task_id then
        if OLD.task_id is not null and NEW.task_id is not null
            and OLD.id is not distinct from NEW.id
        then
            --TODO: Extend audit API with move operation suport and then review the code below:
            foreach container_group_id in array new_container_group_ids loop
                    call audit.write_audit(
                        task_entity_name,
                        OLD.task_id,
                        audit.capitalize(
                            concat_ws(' ',
                                      'перенесена', cg_entity_title,
                                      concat('"', audit.get_container_group_str(container_group_id), '"'),
                                      'в', task_entity_title,
                                      audit.get_task_str(NEW.task_id)
                            )
                        ),
                        op_type => 'MOVE',
                        db_op_type => TG_OP,
                        db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.task_id'),
                        old_value => cast(OLD.task_id as varchar),
                        new_value => cast(NEW.task_id as varchar)
                         );
                    call audit.write_audit(
                        task_entity_name,
                        NEW.task_id,
                        audit.capitalize(
                            concat_ws(' ',
                                      'перенесена', cg_entity_title,
                                      concat('"', audit.get_container_group_str(container_group_id), '"'),
                                      'из', task_entity_title,
                                      audit.get_task_str(OLD.task_id)
                            )
                        ),
                        op_type => 'MOVE',
                        db_op_type => TG_OP,
                        db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.task_id'),
                        old_value => cast(OLD.task_id as varchar),
                        new_value => cast(NEW.task_id as varchar)
                         );
                end loop;
        else
            if OLD.task_id is not null then
                foreach container_group_id in array old_container_group_ids loop
                        call audit.write_instance_audit(task_entity_name, OLD.task_id,
                                                        'DELETE', cg_entity_title, cg_entity_gender,
                                                        audit.get_container_group_str(container_group_id),
                                                        db_op_type => TG_OP,
                                                        db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.task_id'),
                                                        old_value => cast(OLD.task_id as varchar),
                                                        new_value => cast(NEW.task_id as varchar));
                        call audit.write_instance_audit(cg_entity_name, container_group_id,
                                                        'DELETE', task_entity_title, task_entity_gender,
                                                        audit.get_task_str(OLD.task_id),
                                                        db_op_type => TG_OP,
                                                        db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.task_id'),
                                                        old_value => cast(OLD.task_id as varchar),
                                                        new_value => cast(NEW.task_id as varchar));
                    end loop;
            end if;
            if NEW.task_id is not null then
                foreach container_group_id in array new_container_group_ids loop
                        call audit.write_instance_audit(task_entity_name, NEW.task_id,
                                                        'INSERT', cg_entity_title, cg_entity_gender,
                                                        audit.get_container_group_str(container_group_id),
                                                        db_op_type => TG_OP,
                                                        db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.task_id'),
                                                        old_value => cast(OLD.task_id as varchar),
                                                        new_value => cast(NEW.task_id as varchar));
                        call audit.write_instance_audit(cg_entity_name, container_group_id,
                                                        'INSERT', task_entity_title, task_entity_gender,
                                                        audit.get_task_str(NEW.task_id),
                                                        db_op_type => TG_OP,
                                                        db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.task_id'),
                                                        old_value => cast(OLD.task_id as varchar),
                                                        new_value => cast(NEW.task_id as varchar));
                    end loop;
            end if;
        end if;
        if OLD.task_id is not null and NEW.task_id is not null
            and OLD.removal_only_kgo and NEW.removal_only_kgo
        then
            --TODO: Extend audit API with move operation suport and then review the code below:
            call audit.write_audit(
                task_entity_name,
                OLD.task_id,
                audit.capitalize(
                    concat_ws(' ',
                              'перенесена', ca_kgo_entity_title,
                        --TODO: Test if OLD.id is valid for get_task_detail_str within trigger when state is intermediate
                              concat('"', audit.get_task_detail_str(OLD.id), '"'),
                              'в', task_entity_title,
                              audit.get_task_str(NEW.task_id)
                    )
                ),
                op_type => 'MOVE',
                db_op_type => TG_OP,
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.task_id'),
                old_value => cast(OLD.task_id as varchar),
                new_value => cast(NEW.task_id as varchar)
                 );
            call audit.write_audit(
                task_entity_name,
                NEW.task_id,
                audit.capitalize(
                    concat_ws(' ',
                              'перенесена', ca_kgo_entity_title,
                        --TODO: Test if NEW.id is valid for get_task_detail_str within trigger when state is intermediate
                              concat('"', audit.get_task_detail_str(NEW.id), '"'),
                              'из', task_entity_title,
                              audit.get_task_str(OLD.task_id)
                    )
                ),
                op_type => 'MOVE',
                db_op_type => TG_OP,
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.task_id'),
                old_value => cast(OLD.task_id as varchar),
                new_value => cast(NEW.task_id as varchar)
                 );
        else
            if OLD.task_id is not null then
                if OLD.removal_only_kgo then
                    call audit.write_instance_audit(task_entity_name, OLD.task_id,
                                                    'DELETE', ca_kgo_entity_title, ca_kgo_entity_gender,
                                                    audit.get_task_detail_str(OLD.id),
                                                    db_op_type => TG_OP,
                                                    db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.task_id'),
                                                    old_value => cast(OLD.task_id as varchar),
                                                    new_value => cast(NEW.task_id as varchar));
                end if;
            end if;
            if NEW.task_id is not null then
                if NEW.removal_only_kgo then
                    call audit.write_instance_audit(task_entity_name, NEW.task_id,
                                                    'INSERT', ca_kgo_entity_title, ca_kgo_entity_gender,
                                                    audit.get_task_detail_str(NEW.id),
                                                    db_op_type => TG_OP,
                                                    db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.task_id'),
                                                    old_value => cast(OLD.task_id as varchar),
                                                    new_value => cast(NEW.task_id as varchar));
                end if;
            end if;
        end if;
    elsif NEW.task_id is not null then
        -- For the extremely rare case when record id has been changed.
        --TODO: Get rid of this bloody copy-pastes:
        foreach container_group_id in array del_container_group_ids loop
                call audit.write_instance_audit(task_entity_name, NEW.task_id,
                                                'DELETE', cg_entity_title, cg_entity_gender,
                                                audit.get_container_group_str(container_group_id),
                                                db_op_type => TG_OP,
                    -- id influences implicitly on (add|del)_container_group_ids:
                                                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.id'),
                                                old_value => cast(OLD.id as varchar),
                                                new_value => cast(NEW.id as varchar)
                     );
                call audit.write_instance_audit(cg_entity_name, container_group_id,
                                                'DELETE', task_entity_title, task_entity_gender,
                                                audit.get_task_str(NEW.task_id),
                                                db_op_type => TG_OP,
                    -- id influences implicitly on (add|del)_container_group_ids:
                                                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.id'),
                                                old_value => cast(OLD.id as varchar),
                                                new_value => cast(NEW.id as varchar)
                     );
            end loop;
        foreach container_group_id in array add_container_group_ids loop
                call audit.write_instance_audit(task_entity_name, NEW.task_id,
                                                'INSERT', cg_entity_title, cg_entity_gender,
                                                audit.get_container_group_str(container_group_id),
                                                db_op_type => TG_OP,
                    -- id influences implicitly on (add|del)_container_group_ids:
                                                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.id'),
                                                old_value => cast(OLD.id as varchar),
                                                new_value => cast(NEW.id as varchar)
                     );
                call audit.write_instance_audit(cg_entity_name, container_group_id,
                                                'INSERT', task_entity_title, task_entity_gender,
                                                audit.get_task_str(NEW.task_id),
                                                db_op_type => TG_OP,
                    -- id influences implicitly on (add|del)_container_group_ids:
                                                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.id'),
                                                old_value => cast(OLD.id as varchar),
                                                new_value => cast(NEW.id as varchar)
                     );
            end loop;
        --
        if NEW.verification_request_id is distinct from OLD.verification_request_id then
            if NEW.verification_request_id is not null then
                call audit.write_instance_audit(task_entity_name, NEW.task_id, 'INSERT', task_verification_request,
                                                'F',
                                                audit.get_address(NEW.id),
                                                db_op_type => TG_OP,
                                                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME,
                                                                        '.verification_request_id'),
                                                old_value => cast(OLD.verification_request_id as varchar),
                                                new_value => cast(NEW.verification_request_id as varchar));
            end if;
        end if;
        --
        if NEW.removal_only_kgo is distinct from OLD.removal_only_kgo then
            call audit.write_attribute_audit(task_entity_name, NEW.task_id,
                                             audit.get_op_type(NEW.removal_only_kgo is null, OLD.removal_only_kgo is null),
                                             concat(' ', 'Признак КГО', concat('"', audit.get_task_detail_str(NEW.id), '"')), 'N',
                                             audit.get_boolean_str(coalesce(NEW.removal_only_kgo, OLD.removal_only_kgo)),
                                             db_op_type => TG_OP,
                                             db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.removal_only_kgo'),
                                             old_value => cast(OLD.removal_only_kgo as varchar),
                                             new_value => cast(NEW.removal_only_kgo as varchar));
        end if;
    end if;

    if NEW.container_area_id is distinct from OLD.container_area_id then
        if OLD.container_area_id is not null and OLD.task_id is not null then
            call audit.write_instance_audit(ca_entity_name, OLD.container_area_id,
                                            'DELETE', task_entity_title, task_entity_gender,
                                            audit.get_task_str(OLD.task_id),
                                            db_op_type => TG_OP,
                                            db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.container_area_id'),
                                            old_value => cast(OLD.container_area_id as varchar),
                                            new_value => cast(NEW.container_area_id as varchar));
        end if;
        if NEW.container_area_id is not null and NEW.task_id is not null then
            call audit.write_instance_audit(ca_entity_name, NEW.container_area_id,
                                            'INSERT', task_entity_title, task_entity_gender,
                                            audit.get_task_str(NEW.task_id),
                                            db_op_type => TG_OP,
                                            db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.container_area_id'),
                                            old_value => cast(OLD.container_area_id as varchar),
                                            new_value => cast(NEW.container_area_id as varchar));
        end if;
    elsif NEW.container_area_id is not null
        and NEW.task_id is distinct from OLD.task_id
    then
        if OLD.verification_request_id is not null then
            call audit.write_instance_audit(task_entity_name, OLD.task_id, 'DELETE', task_verification_request,
                                            'F',
                                            audit.get_address(NEW.id),
                                            db_op_type => TG_OP,
                                            db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME,
                                                                    '.verification_request_id'),
                                            old_value => cast(OLD.verification_request_id as varchar),
                                            new_value => cast(NEW.verification_request_id as varchar));
        end if;
        if OLD.task_id is not null then
            call audit.write_instance_audit(ca_entity_name, NEW.container_area_id,
                                            'DELETE', task_entity_title, task_entity_gender,
                                            audit.get_task_str(OLD.task_id),
                                            db_op_type => TG_OP,
                                            db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.task_id'),
                                            old_value => cast(OLD.task_id as varchar),
                                            new_value => cast(NEW.task_id as varchar));
        end if;
        if NEW.task_id is not null then
            call audit.write_instance_audit(ca_entity_name, NEW.container_area_id,
                                            'INSERT', task_entity_title, task_entity_gender,
                                            audit.get_task_str(NEW.task_id),
                                            db_op_type => TG_OP,
                                            db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.task_id'),
                                            old_value => cast(OLD.task_id as varchar),
                                            new_value => cast(NEW.task_id as varchar));
        end if;
    end if;

    if NEW.task_id is not null then
        soft_op_type = audit.get_soft_op_type(NEW.delete_ts is not null, OLD.delete_ts is not null);
        if soft_op_type is not null then
            foreach container_group_id in array new_container_group_ids loop
                    call audit.write_instance_audit(task_entity_name, NEW.task_id,
                                                    soft_op_type, cg_entity_title, cg_entity_gender,
                                                    audit.get_container_group_str(container_group_id),
                                                    db_op_type => TG_OP,
                                                    db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.delete_ts'),
                                                    old_value => cast(OLD.delete_ts as varchar),
                                                    new_value => cast(NEW.delete_ts as varchar));

                    call audit.write_instance_audit(cg_entity_name, container_group_id,
                                                    soft_op_type, task_entity_title, task_entity_gender,
                                                    audit.get_task_str(NEW.task_id),
                                                    db_op_type => TG_OP,
                                                    db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.delete_ts'),
                                                    old_value => cast(OLD.delete_ts as varchar),
                                                    new_value => cast(NEW.delete_ts as varchar));
                end loop;
            if NEW.container_area_id is not null then
                call audit.write_instance_audit(ca_entity_name, NEW.container_area_id,
                                                soft_op_type, task_entity_title, task_entity_gender,
                                                audit.get_task_str(NEW.task_id),
                                                db_op_type => TG_OP,
                                                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.delete_ts'),
                                                old_value => cast(OLD.delete_ts as varchar),
                                                new_value => cast(NEW.delete_ts as varchar));
            end if;
        end if;
    end if;

    return coalesce(NEW, OLD);
end;
$$;

alter function dsp_task_detail_audit_trg() owner to sa;

