create function dsp_person_smartsearch_trg() returns trigger
    language plpgsql
as
$$
begin
    if(NEW.id is distinct from OLD.id or
        NEW.full_name is distinct from OLD.full_name
    ) then
        insert into dsp_smartsearch_queue(context_name, key)
        select distinct
            'dsp_Employee',
            cast(e.id as varchar)
        from dsp_employee as e
        where e.person_id in (NEW.id, OLD.id);

        insert into dsp_smartsearch_queue(context_name, key)
        select distinct
            'dsp_Task',
            cast(t.id as varchar)
        from dsp_task as t
            join dsp_employee as e on t.driver_id = e.id
        where e.person_id in (NEW.id, OLD.id);
    end if;

    return null;
end;
$$;

alter function dsp_person_smartsearch_trg() owner to sa;

