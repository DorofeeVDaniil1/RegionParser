create function create_vehicle(_assembly_name character varying, _compression_coefficient double precision, _vehicle_container_name character varying, _volume double precision, _volume_compressed double precision, _load_type_keyword character varying, _carrying double precision, _fuel_tank_volume double precision, _garb_vol_max double precision, _garb_vol_min double precision, _model_name character varying, _fuel_cons double precision, _brand_name character varying, _region character varying, _no_region character varying) returns uuid
    language plpgsql
as
$$
begin 

	return new_vehicle 
	( 
		new_assembly
		(
			_assembly_name, -- PARAM
			new_vehicle_container
			(
				_compression_coefficient, -- PARAM
				_vehicle_container_name, -- PARAM
				_volume, -- PARAM
				_volume_compressed, -- PARAM
				get_load_type(
					_load_type_keyword -- PARAM
				)			
			),
			new_model
			(
				_carrying, -- PARAM
				_fuel_tank_volume, -- PARAM
				_garb_vol_max, -- PARAM
				_garb_vol_min, -- PARAM
				_model_name, -- PARAM
				_fuel_cons, -- PARAM
				new_brand
				(
					_brand_name -- PARAM
				)
			)
		),
		new_vehicle_number
		(
			_region, -- PARAM
			_no_region -- PARAM
		)
	);
	
end;
$$;

alter function create_vehicle(varchar, double precision, varchar, double precision, double precision, varchar, double precision, double precision, double precision, double precision, varchar, double precision, varchar, varchar, varchar) owner to sa;

