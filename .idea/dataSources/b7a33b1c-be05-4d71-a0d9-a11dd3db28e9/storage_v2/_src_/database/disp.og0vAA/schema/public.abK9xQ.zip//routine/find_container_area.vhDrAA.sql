create function find_container_area(lat double precision, lon double precision, l integer)
    returns TABLE(start_date timestamp without time zone, lk_code character varying, address character varying, company character varying, num character varying, region character varying, has_report boolean)
    language plpgsql
as
$$
begin  
return query

	select 

	dsp_task.start_date, 
	dsp_container_area.lk_code as lk_code,
	dsp_address.view_ as address, 
	dsp_company.full_name as company, 
	dsp_vehicle_number.full_ as num, 
	dsp_region.name as region, 
	dsp_report_from_driver.id is not null as has_report

	from dsp_task

	join dsp_company ON dsp_company.id = dsp_task.carrier_id
	join dsp_vehicle ON dsp_vehicle.id = dsp_task.vehicle_id
	join dsp_vehicle_number ON dsp_vehicle_number.id = dsp_vehicle.number_id

	join dsp_task_detail ON dsp_task_detail.task_id = dsp_task.id
	join dsp_container_area ON dsp_container_area.id = dsp_task_detail.container_area_id
	join dsp_address ON dsp_address.id = dsp_container_area.address_id
	join dsp_region ON dsp_region.id = dsp_task.region_id

	join dsp_geo_data ON dsp_geo_data.id = dsp_container_area.geo_data_id
	join dsp_geo_point ON dsp_geo_point.geo_data_id = dsp_geo_data.id

	left join dsp_report_from_driver ON dsp_report_from_driver.id = dsp_task_detail.report_id

	where 

		sqrt( (lat - latitude) * (lat - latitude) + (lon - longitude) * (lon - longitude)) < (l::double precision / 1000)

	order by start_date desc, view_ ;

end;
$$;

alter function find_container_area(double precision, double precision, integer) owner to sa;

