create procedure reassign_region(_from uuid, _to uuid)
    language plpgsql
as
$$
begin
update dsp_region_employee_link
	set region_id = _to
	where region_id = _from
	and (employee_id, _to) not in
	(select  * from dsp_region_employee_link);

update dsp_region_container_area_link
	set region_id = _to
	where region_id = _from
	and (container_area_id, _to) not in
	(select  * from dsp_region_container_area_link);

update dsp_region_vehicle_link
	set region_id = _to
	where region_id = _from
	and (vehicle_id, _to) not in
	(select  * from dsp_region_vehicle_link);
	
update dsp_inventorization
	set region_id = _to
	where region_id = _from;
	
update dsp_task
	set region_id = _to
	where region_id = _from;
	
update dsp_region
	set parent_id = _to
	where parent_id = _from;
	
delete from dsp_region_employee_link
	where region_id = _from;
	
delete from dsp_region_container_area_link
	where region_id = _from;
	
delete from dsp_region_vehicle_link
	where region_id = _from;
	
end;
$$;

alter procedure reassign_region(uuid, uuid) owner to sa;

