create function prepare_view(_table character varying)
    returns TABLE(_rows text)
    language plpgsql
as
$$
begin  
return query

	select 

	table_name || '.' || column_name || ' as ' ||
	lower(
		substring(
			array_to_string(
				array(
					select array_agg(initcap(x)) 
					from unnest(regexp_split_to_array(
						(
							substring(table_name, 5) || '_' || column_name 
						), 
						E'_')) as x
				),
				''
			) from 1 for 1
		)
    ) 
	||
	substring(
		array_to_string(
			array(
				select array_agg(initcap(x)) 
				from unnest(regexp_split_to_array(
					(
						substring(table_name, 5) || '_' || column_name 
					), 
					E'_')) as x
			),
			''
		),
		2
	)
	|| ','
	
	from information_schema.columns 
	where table_name = _table
	and column_name not in ('create_ts', 'created_by', 'update_ts', 'updated_by', 'delete_ts', 'deleted_by');
	 
end;
$$;

alter function prepare_view(varchar) owner to sa;

