create function new_zero_region(_name character varying, _geo_data_id uuid) returns uuid
    language plpgsql
as
$$
declare

	_u uuid = uuid_generate_v4();
	
begin

	insert into
	dsp_region
	(
		id, 
		create_ts,
		level_,
		name
	)
	values
	(
		_u, 
		now()::timestamp,
		0,
		_name
	);

	return _u;
	
end;
$$;

alter function new_zero_region(varchar, uuid) owner to sa;

