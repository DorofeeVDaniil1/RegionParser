create function new_vehicle_container(_compression_coefficient double precision, _name character varying, _volume double precision, _volume_compressed double precision, _load_type_id uuid) returns uuid
    language plpgsql
as
$$
declare
 
	_u uuid = uuid_generate_v4();
	
begin

	insert into dsp_vehicle_garbage_container
	( id, create_ts, created_by, delete_ts, deleted_by, update_ts, updated_by, 
	 compression_coefficient, name, volume, volume_compressed, load_type_id )
	values
	( _u, now()::timestamp, null, null, null, null, null,
	  _compression_coefficient, _name, _volume, _volume_compressed, _load_type_id);

	return _u;
	
end;
$$;

alter function new_vehicle_container(double precision, varchar, double precision, double precision, uuid) owner to sa;

