create function new_vehicle(_assembly_id uuid, __number_id uuid) returns uuid
    language plpgsql
as
$$
declare
 
	_u uuid = uuid_generate_v4();
	
begin

	insert into dsp_vehicle
	( 
		id, create_ts, created_by, delete_ts, deleted_by, update_ts, updated_by, 
		enterprise1c_id, assembly_id, gps_device_id, location_id, number_id, owner_id
	)
	values
	( 
		_u, now()::timestamp, null, null, null, null, null, 
	 	null, _assembly_id, null, null, __number_id, null
	);
	return _u;
	
end;
$$;

alter function new_vehicle(uuid, uuid) owner to sa;

