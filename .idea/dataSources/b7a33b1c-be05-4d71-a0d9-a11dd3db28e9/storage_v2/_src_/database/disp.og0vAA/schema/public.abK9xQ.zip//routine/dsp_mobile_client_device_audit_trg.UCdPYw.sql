create function dsp_mobile_client_device_audit_trg() returns trigger
    language plpgsql
as
$$
declare
    entity_name constant varchar = 'dsp_MobileClientDevice';
    entity_title constant varchar = 'планшет';
    entity_gender constant audit.gender = 'M';
begin
    if not audit.is_audit_enabled() then
        return coalesce(NEW, OLD);
    end if;

    if NEW.id is distinct from OLD.id then
        if NEW.id is not null then
            call audit.write_instance_audit(entity_name, NEW.id,
                'CREATE', entity_title, entity_gender,
                db_op_type => TG_OP,
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.id'),
                old_value => cast(OLD.id as varchar),
                new_value => cast(NEW.id as varchar));
        end if;
        if OLD.id is not null then
            call audit.write_instance_audit(entity_name, OLD.id,
                'DELETE', entity_title, entity_gender,
                db_op_type => TG_OP,
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.id'),
                old_value => cast(OLD.id as varchar),
                new_value => cast(NEW.id as varchar));
        end if;
    end if;
    if NEW.id is not null then
        if (NEW.delete_ts is not null) is distinct from (OLD.delete_ts is not null) then
            call audit.write_instance_audit(entity_name, NEW.id,
                audit.get_soft_op_type(NEW.delete_ts is not null, OLD.delete_ts is not null),
                entity_title, entity_gender,
                db_op_type => TG_OP,
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.delete_ts'),
                old_value => cast(OLD.delete_ts as varchar),
                new_value => cast(NEW.delete_ts as varchar));
        end if;
        if NEW.dev_uuid is distinct from OLD.dev_uuid then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.dev_uuid is null, OLD.dev_uuid is null),
                --TODO: Use utility get_..._str function for this:
                'код', 'M', substring(coalesce(NEW.dev_uuid, OLD.dev_uuid) from '[^-]*?$'),
                db_op_type => TG_OP,
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.dev_uuid'),
                old_value => cast(OLD.dev_uuid as varchar),
                new_value => cast(NEW.dev_uuid as varchar));
        end if;
        if NEW.owner_id is distinct from OLD.owner_id then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.owner_id is null, OLD.owner_id is null),
                'перевозчик', 'M', audit.get_company_str(coalesce(NEW.owner_id, OLD.owner_id)),
                db_op_type => TG_OP,
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.owner_id'),
                old_value => cast(OLD.owner_id as varchar),
                new_value => cast(NEW.owner_id as varchar));
        end if;
        if NEW.status is distinct from OLD.status then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.status is null, OLD.status is null),
                'статус', 'M', coalesce(NEW.status, OLD.status),
                db_op_type => TG_OP,
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.status'),
                old_value => cast(OLD.status as varchar),
                new_value => cast(NEW.status as varchar));
        end if;
        if NEW.inventorization_mode is distinct from OLD.inventorization_mode then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.inventorization_mode is null, OLD.inventorization_mode is null),
                'назначено на инвентаризацию', 'N', audit.get_boolean_str(coalesce(NEW.inventorization_mode, OLD.inventorization_mode)),
                db_op_type => TG_OP,
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.inventorization_mode'),
                old_value => cast(OLD.inventorization_mode as varchar),
                new_value => cast(NEW.inventorization_mode as varchar));
        end if;
        if NEW.approved_by is distinct from OLD.approved_by then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.approved_by is null, OLD.approved_by is null),
                'кем подтверждено', 'N', coalesce(NEW.approved_by, OLD.approved_by),
                db_op_type => TG_OP,
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.approved_by'),
                old_value => cast(OLD.approved_by as varchar),
                new_value => cast(NEW.approved_by as varchar));
        end if;
    end if;

    return coalesce(NEW, OLD);
end;
$$;

alter function dsp_mobile_client_device_audit_trg() owner to sa;

