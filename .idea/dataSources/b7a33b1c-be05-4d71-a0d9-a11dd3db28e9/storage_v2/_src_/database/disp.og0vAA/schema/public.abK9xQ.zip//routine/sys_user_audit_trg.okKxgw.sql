create function sys_user_audit_trg() returns trigger
    language plpgsql
as
$$
declare
    entity_name constant varchar = 'sys_user';
    entity_title constant varchar = 'пользователь';
    entity_gender constant audit.gender = 'M';

    employee_entity_name constant varchar = 'dsp_Employee';
    employee_entity_title constant varchar = 'сотрудник';
    employee_entity_gender constant audit.gender = 'M';

    --The dsp_employee table has unique constraint on user_id and FK on sys_user table, so neither array nor OLD value necessary
    new_employee_id uuid;
begin
    if not audit.is_audit_enabled() then
        return coalesce(NEW, OLD);
    end if;

    if NEW.id is distinct from OLD.id then
        if NEW.id is not null then
            call audit.write_instance_audit(entity_name, NEW.id,
                'CREATE', entity_title, entity_gender,
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.id'),
                old_value => cast(OLD.id as varchar),
                new_value => cast(NEW.id as varchar));
        end if;
        if OLD.id is not null then
            call audit.write_instance_audit(entity_name, OLD.id,
                'DELETE', entity_title, entity_gender,
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.id'),
                old_value => cast(OLD.id as varchar),
                new_value => cast(NEW.id as varchar));
        end if;
    end if;
    if NEW.id is not null then
        if (NEW.delete_ts is not null) is distinct from (OLD.delete_ts is not null) then
            call audit.write_instance_audit(entity_name, NEW.id,
                audit.get_soft_op_type(NEW.delete_ts is not null, OLD.delete_ts is not null),
                entity_title, entity_gender,
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.delete_ts'),
                old_value => cast(OLD.delete_ts as varchar),
                new_value => cast(NEW.delete-ts as varchar));
        end if;
        if NEW.login is distinct from OLD.login then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.login is null, OLD.login is null),
                'логин', 'M', coalesce(NEW.login, OLD.login),
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.login'),
                old_value => cast(OLD.login as varchar),
                new_value => cast(NEW.login as varchar));
        end if;                
        if NEW.first_name is distinct from OLD.first_name then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.first_name is null, OLD.first_name is null),
                'фамилия', 'N', coalesce(NEW.first_name, OLD.first_name),
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.first_name'),
                old_value => cast(OLD.first_name as varchar),
                new_value => cast(NEW.first_name as varchar));
        end if;                
        if NEW.last_name is distinct from OLD.last_name then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.last_name is null, OLD.last_name is null),
                'имя', 'F', coalesce(NEW.last_name, OLD.last_name),
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.last_name'),
                old_value => cast(OLD.last_name as varchar),
                new_value => cast(NEW.last_name as varchar));
        end if;                
        if NEW.email is distinct from OLD.email then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.email is null, OLD.email is null),
                'e-mail', 'M', coalesce(NEW.email, OLD.email),
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.email'),
                old_value => cast(OLD.email as varchar),
                new_value => cast(NEW.email as varchar));
        end if;                
        if NEW.activated is distinct from OLD.activated then
            call audit.write_attribute_audit(entity_name, NEW.id,
                audit.get_op_type(NEW.activated is null, OLD.activated is null),
                'признак активности', 'N', audit.get_boolean_str(coalesce(NEW.activated, OLD.activated)),
                db_op_type => TG_OP, 
                db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.activated'),
                old_value => cast(OLD.activated as varchar),
                new_value => cast(NEW.activated as varchar));
        end if;

        select e.id into new_employee_id
        from dsp_employee as e where e.user_id = NEW.id;

	if new_employee_id is not null then
            if NEW.login is distinct from OLD.login then
                call audit.write_attribute_audit(employee_entity_name, new_employee_id,
                    audit.get_op_type(NEW.login is null, OLD.login is null),
                    'логин', 'M', coalesce(NEW.login, OLD.login),
                    db_op_type => TG_OP, 
                    db_field_name => concat(TG_TABLE_SCHEMA, '.', TG_TABLE_NAME, '.login'),
                    old_value => cast(OLD.login as varchar),
                    new_value => cast(NEW.login as varchar));
            end if;                
        end if;
    end if;

    return coalesce(NEW, OLD);
end;
$$;

alter function sys_user_audit_trg() owner to sa;

