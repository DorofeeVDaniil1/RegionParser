create function dsp_route_smartsearch_trg() returns trigger
    language plpgsql
as
$$
begin
    if(NEW.id is distinct from OLD.id or
        NEW.delete_ts is distinct from OLD.delete_ts or
        NEW.name is distinct from OLD.name or
        NEW.carrier_id is distinct from OLD.carrier_id or
        NEW.region_id is distinct from OLD.region_id
    ) then
        insert into dsp_smartsearch_queue(context_name, key)
        select distinct
            'dsp_Route',
            cast(r.id as varchar)
        from (values
                (NEW.id),
                (OLD.id)
            ) as r(id)
        where r.id is not null;

        insert into dsp_smartsearch_queue(context_name, key)
        select distinct
            'dsp_Route(routeDetail.group)',
            concat(
                cast(rd.route_id as varchar), ',',
                cast(rd.group_id as varchar)
            )
        from dsp_route_detail as rd
            join dsp_container_group as cg on rd.group_id = cg.id
            join dsp_container_area as ca on cg.container_area_id = ca.id
        where rd.route_id in (NEW.id, OLD.id);
    end if;

    return null;
end;
$$;

alter function dsp_route_smartsearch_trg() owner to sa;

