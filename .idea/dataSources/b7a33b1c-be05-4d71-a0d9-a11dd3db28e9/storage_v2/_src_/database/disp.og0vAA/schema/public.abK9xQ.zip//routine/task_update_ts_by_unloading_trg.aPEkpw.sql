create function task_update_ts_by_unloading_trg() returns trigger
    language plpgsql
as
$$
begin
    if OLD.task_id is not null and NEW.task_id is not null
        and OLD.id is not distinct from NEW.id
    then
        update dsp_task
        set update_ts  = new.update_ts,
            updated_by = new.updated_by
        where id = new.task_id
           or id = old.task_id;
    elsif OLD.task_id is not null then
        update dsp_task
        set update_ts  = old.update_ts,
            updated_by = old.updated_by
        where id = old.task_id;
    elsif NEW.task_id is not null then
        update dsp_task
        set update_ts  = new.update_ts,
            updated_by = new.updated_by
        where id = new.task_id;
    end if;
    RETURN NEW;
end;
$$;

alter function task_update_ts_by_unloading_trg() owner to sa;

