create function create_task_detail_detailing_plan(_task_detail_id uuid, _container_group_id uuid) returns uuid
    language plpgsql
as
$$
declare _id uuid = uuid_generate_v4();
begin
    insert into dsp_task_detail_detailing_plan(
        id, create_ts, amount, volume, container_type_id, container_group_id, task_detail_id
    )
    select
        _id,
        now(),
        dcg.amount,
        dct.volume,
        dct.id,
        dcg.id,
        _task_detail_id
    from dsp_container_group dcg
             join dsp_container_type dct on dcg.container_type_id = dct.id
    where dcg.id = _container_group_id;
    return _id;
end;
$$;

alter function create_task_detail_detailing_plan(uuid, uuid) owner to sa;

