create function get_task_id(_start_date date, _vehicle_number_like character varying) returns uuid
    language plpgsql
as
$$
begin
    return (
        select dt.id
        from dsp_task dt
        join dsp_vehicle dv on dt.vehicle_id = dv.id
        join dsp_vehicle_number dvn on dv.number_id = dvn.id
        where start_date = _start_date
        and full_ like '%' || _vehicle_number_like || '%'
    );

end;
$$;

alter function get_task_id(date, varchar) owner to sa;

